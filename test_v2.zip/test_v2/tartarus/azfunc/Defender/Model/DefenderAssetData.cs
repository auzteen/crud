using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Tartarus.Defender.Model
{
    public class DefenderAssetData
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("attributes")]
        public Assets attributes { get; set; }
    }

    public class Assets
    {
        public List<Asset> assetList { get; set; }
    }

    public class Asset
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

#nullable enable
        [JsonPropertyName("mergedIntoMachineId")]
        public string? MergedIntoMachineId { get; set; }
#nullable disable

        [JsonPropertyName("isPotentialDuplication")]
        public string IsPotentialDuplication { get; set; }

        [JsonPropertyName("computerDnsName")]
        public string ComputerDnsName { get; set; }

        [JsonPropertyName("firstSeen")]
        public string FirstSeen { get; set; }

        [JsonPropertyName("lastSeen")]
        public string LastSeen { get; set; }

        [JsonPropertyName("OS")]
        public string OS { get; set; }

        [JsonPropertyName("osPlatform")]
        public string OsPlatform { get; set; }

#nullable enable
        [JsonPropertyName("osVersion")]
        public string? OsVersion { get; set; }
#nullable disable

        [JsonPropertyName("osProcessor")]
        public string OsProcessor { get; set; }

        [JsonPropertyName("version")]
        public string Version { get; set; }

        [JsonPropertyName("lastIpAddress")]
        public string LastIpAddress { get; set; }

        [JsonPropertyName("lastExternalIpAddress")]
        public string LastExternalIpAddress { get; set; }

        [JsonPropertyName("agentVersion")]
        public string AgentVersion { get; set; }

        [JsonPropertyName("osBuild")]
        public string OsBuild { get; set; }

        [JsonPropertyName("healthStatus")]
        public string HealthStatus { get; set; }

        [JsonPropertyName("deviceValue")]
        public string DeviceValue { get; set; }

        [JsonPropertyName("rbacGroupId")]
        public string RbacGroupId { get; set; }

#nullable enable
        [JsonPropertyName("rbacGroupName")]
        public string? RbacGroupName { get; set; }
#nullable disable

        [JsonPropertyName("riskScore")]
        public string RiskScore { get; set; }

        [JsonPropertyName("exposureLevel")]
        public string ExposureLevel { get; set; }

        [JsonPropertyName("isAadJoined")]
        public string IsAadJoined { get; set; }

        [JsonPropertyName("aadDeviceId")]
        public string AadDeviceId { get; set; }

        [JsonPropertyName("machineTags")]
        public string[] MachineTags { get; set; }

        [JsonPropertyName("defenderAvStatus")]
        public string DefenderAvStatus { get; set; }

        [JsonPropertyName("onboardingStatus")]
        public string OnboardingStatus { get; set; }

        [JsonPropertyName("osArchitecture")]
        public string OsArchitecture { get; set; }

        [JsonPropertyName("managedBy")]
        public string ManagedBy { get; set; }

        [JsonPropertyName("managedByStatus")]
        public string ManagedByStatus { get; set; }

        [JsonPropertyName("ipAddresses")]
        public List<IPAddress> IpAddresses { get; set; }

#nullable enable
        [JsonPropertyName("vmMetadata")]
        public string? VmMetadata { get; set; }
#nullable disable
    }

    public class IPAddress
    {
        [JsonPropertyName("ipAddress")]
        public string IpAddress { get; set; }

        [JsonPropertyName("macAddress")]
        public string MacAddress { get; set; }

        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("operationalStatus")]
        public string OperationalStatus { get; set; }
    }
}