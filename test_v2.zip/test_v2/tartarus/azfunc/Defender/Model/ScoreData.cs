using Newtonsoft.Json;

namespace Tartarus.Defender.Model
{
    public class ScoreData
    {
        [JsonProperty("time")]
        public string Time { get; set; }
        [JsonProperty("score")]
        public string Score { get; set; }
    }
}