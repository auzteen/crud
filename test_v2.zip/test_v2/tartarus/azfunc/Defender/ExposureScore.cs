﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Tartarus.Shared;
using System.Text.Json;
using Tartarus.Defender.Model;

namespace Tartarus.Defender
{
    public class DeviceScore
    {
        private static HttpClient httpClient = new HttpClient();
        private readonly ILogger<DeviceScore> _logger;
        private readonly IDefenderService _dService;
        public DeviceScore(ILogger<DeviceScore> log, IDefenderService dService)
        {
            _logger = log;
            _dService = dService;
        }
        [FunctionName(Constant.DEVICE_SCORE)]
        public async Task<OkObjectResult> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = Constant.EXPOSURE_SCORE_ROUTE)] HttpRequest req)
        {
            _logger.LogInformation($"Function 'Score' Entered: {DateTime.Now}");

            try
            {

                List<Dictionary<string, string>> customers = _dService.GetCustomers();
                customers.Add(new Dictionary<string, string>()
                {
                    { "name", "open" }
                });

                // To Do:
                // This needs to be refactored is, as and when we get proper access to customer tenant data

                List<ScoreData> scoreDataList = new List<ScoreData>();

                var request = new HttpRequestMessage(HttpMethod.Get, Constant.GET_DEFENDER_SCORE_URI);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _dService.GetToken(customers[0]));
                var response = httpClient.SendAsync(request).GetAwaiter().GetResult();
                var result = await response.Content.ReadAsStringAsync();
                var responseData = JsonConvert.DeserializeObject<ScoreData>(result);

                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    throw new UnauthorizedAccessException("Invalid bearer token for Defender");
                }
                scoreDataList.Add(responseData);

                // Response
                DataMessage<string, List<ScoreData>> dataMessage = new DataMessage<string, List<ScoreData>>();
                dataMessage.data = null;
                dataMessage.meta = new Meta<List<ScoreData>>();
                dataMessage.meta.result = scoreDataList;

                return new OkObjectResult(System.Text.Json.JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch (BadRequestException e)
            {
                _logger.LogError(e.Message);
                return new OkObjectResult(Common.ReturnErrorResponse(e.Message, "400"));
            }
            catch (KeyNotFoundException e)
            {
                _logger.LogError(e.Message);
                return new OkObjectResult(Common.ReturnErrorResponse(e.Message, "400"));
            }
            catch (Newtonsoft.Json.JsonException e)
            {
                _logger.LogError(e.Message);
                return new OkObjectResult(Common.ReturnErrorResponse("Invalid JSON request", "400"));
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return new OkObjectResult(Common.ReturnErrorResponse(e.Message, "500"));
            }
        }
    }
}
