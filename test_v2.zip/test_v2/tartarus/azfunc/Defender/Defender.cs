﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net.Http;
using DModel = Tartarus.Defender.Model;
using Tartarus.Shared;

namespace Tartarus.Defender
{
    public class Defender
    {
        private readonly ILogger<Defender> _logger;
        private static HttpClient httpClient = new HttpClient();
        private readonly IDefenderService _dService;
        public Defender(ILogger<Defender> log, IDefenderService dService)
        {
            _logger = log;
            _dService = dService;
        }

        [FunctionName(Constant.DEFENDER)]
        public void Run([TimerTrigger("0 3 * * *")] TimerInfo myTimer)
        {
            _logger.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

            try
            {
                List<Dictionary<string, string>> customers = _dService.GetCustomers();
                customers.Add(new Dictionary<string, string>()
                {
                    { "name", "open" }
                });

                foreach (var customer in customers)
                {

                    // Data
                    List<DModel.Asset> defenderAssets = new List<DModel.Asset>();
                    List<DModel.Vulnerability> defenderVulnerabilities = new List<DModel.Vulnerability>();

                    // Assets / Customer
                    defenderAssets = _dService.GetAssets(Constant.GET_MACHINE_URL, customer);


                    // Vulnerabilities / Customer
                    defenderVulnerabilities = _dService.GetVulnerabilities(Constant.GET_VULNERABILITY_URL, customer);

                    // Map
                    var vulnerabilities = _dService.MapToModel(defenderAssets, defenderVulnerabilities, customer);

                    // Vulnerability Data
                    var vulnerabilityData = _dService.GetVulnerabilityData(vulnerabilities);

                    // Post
                    HttpResponseMessage response = _dService.PostVulnerabilityData(vulnerabilityData, customer);
                }
            }
            catch (DefenderAssetScanException e)
            {
                _logger.LogError(e.Message);
            }
            catch (DefenderVulnerabilityScanException e)
            {
                _logger.LogError(e.Message);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
            }
        }
    }
}