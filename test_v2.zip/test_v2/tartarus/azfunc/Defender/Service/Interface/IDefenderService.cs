using System.Collections.Generic;
using System.Net.Http;
using DModel = Tartarus.Defender.Model;
using VModel = Tartarus.Vulnerability.Model;

namespace Tartarus.Defender
{
    public interface IDefenderService
    {
        // Customer
        public List<Dictionary<string, string>> GetCustomers();

        // Token
        public string GetToken(Dictionary<string, string> customer);

        // Asset
        public List<DModel.Asset> GetAssets(string url, Dictionary<string, string> customer);

        // Vulnerability
        public List<DModel.Vulnerability> GetVulnerabilities(string url, Dictionary<string, string> customer);
        public VModel.Vulnerabilities MapToModel(List<DModel.Asset> defenderAssets, List<DModel.Vulnerability> defenderVulnerabilities, Dictionary<string, string> customer);
        public VModel.VulnerabilityData GetVulnerabilityData(VModel.Vulnerabilities vulnerabilities);
        public HttpResponseMessage PostVulnerabilityData(VModel.VulnerabilityData vulnerabilityData, Dictionary<string, string> customer);
    }
}