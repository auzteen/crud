using System;
using Microsoft.Identity.Client;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Text.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Text;
using System.Net;
using DModel = Tartarus.Defender.Model;
using VModel = Tartarus.Vulnerability.Model;
using Tartarus.Shared;
using Azure.Security.KeyVault.Secrets;

namespace Tartarus.Defender
{
    public class DefenderService : IDefenderService
    {

        private readonly ILogger<IDefenderService> _logger;

        public DefenderService(ILogger<IDefenderService> log)
        {
            _logger = log;
        }

        // Customers
        public List<Dictionary<string, string>> GetCustomers()
        {
            // To Do: Fetch...
            return new List<Dictionary<string, string>>();
        }

        // Assets
        public List<DModel.Asset> GetAssets(string url, Dictionary<string, string> customer)
        {
            try
            {
                var token = GetToken(customer);
                return GetAssetData(url, token);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw new DefenderAssetScanException($"Defender asset scan failed: {DateTime.Now}");
            }
        }

        private List<DModel.Asset> GetAssetData(string url, string token)
        {
            // Asset Data
            List<DModel.Asset> defenderAssets = new List<DModel.Asset>();

            // Client
            var client = new HttpClient();

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("Authorization", $"bearer {token}");

            // Reponse
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = client.SendAsync(request).Result;

                // Content
                var content = response.Content.ReadAsStringAsync().Result;

                // Assets
                var jObject = JObject.Parse(content);
                var jToken = jObject.SelectToken("value");
                var jArray = JArray.Parse(jToken.ToString());
                var assets = JsonConvert.DeserializeObject<List<DModel.Asset>>(jArray.ToString());

                // Asset Data
                defenderAssets = assets;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            return defenderAssets;
        }

        // Vulnerabilities
        public List<DModel.Vulnerability> GetVulnerabilities(string url, Dictionary<string, string> customer)
        {
            try
            {
                var token = GetToken(customer);
                return GetVulnerabilityData(url, token);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw new DefenderVulnerabilityScanException($"Defender vulnerability scan failed: {DateTime.Now}");
            }
        }

        private List<DModel.Vulnerability> GetVulnerabilityData(string url, string token)
        {
            // Asset Data
            List<DModel.Vulnerability> defenderVulnerabilities = new List<DModel.Vulnerability>();

            // Client
            var client = new HttpClient();

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("Authorization", $"bearer {token}");

            // Reponse
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = client.SendAsync(request).Result;

                // Content
                var content = response.Content.ReadAsStringAsync().Result;

                // Assets
                var jObject = JObject.Parse(content);
                var jToken = jObject.SelectToken("value");
                var jArray = JArray.Parse(jToken.ToString());
                var vulnerabilities = JsonConvert.DeserializeObject<List<DModel.Vulnerability>>(jArray.ToString());

                // Asset Data
                defenderVulnerabilities = vulnerabilities;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            return defenderVulnerabilities;
        }

        public VModel.Vulnerabilities MapToModel(List<DModel.Asset> defenderAssets, List<DModel.Vulnerability> defenderVulnerabilities, Dictionary<string, string> customer)
        {
            // Model: Vulnerablitlies
            VModel.Vulnerabilities vulnerabilities = new VModel.Vulnerabilities();
            // Model: Vulnerability List
            List<VModel.Vulnerability> vulnerabilityList = new List<VModel.Vulnerability>();

            foreach (var dVuln in defenderVulnerabilities)
            {
                VModel.Vulnerability vulnerability = new VModel.Vulnerability();
                var dAsset = defenderAssets.Find(e => e.Id == dVuln.MachineId);

                vulnerability.AssetName = dAsset.ComputerDnsName;
                vulnerability.AssetType = "*** Unknown: Defender Scan ***";
                vulnerability.CompanyShortName = customer["name"];
                vulnerability.Source = "MDE";
                vulnerability.SourceId = dVuln.MachineId;
                vulnerability.CVEID = dVuln.CVEID;
                vulnerability.IPAddress = dAsset.LastIpAddress;
                vulnerability.OS = dAsset.OsPlatform;
                vulnerability.VendorName = dVuln.ProductVendor;
                vulnerability.ProductName = dVuln.ProductName;
                vulnerability.ProductVersion = dVuln.ProductVersion;
                vulnerability.Severity = dVuln.Severity;

                vulnerabilityList.Add(vulnerability);

            }
            vulnerabilities.vulnerabilityList = vulnerabilityList;
            return vulnerabilities;
        }

        public VModel.VulnerabilityData GetVulnerabilityData(VModel.Vulnerabilities vulnerabilities)
        {
            // Model
            VModel.VulnerabilityData vulnerabilityData = new VModel.VulnerabilityData();

            vulnerabilityData.Type = "MDE";
            vulnerabilityData.Id = Guid.NewGuid().ToString();
            vulnerabilityData.attributes = vulnerabilities;

            //_logger.LogInformation(System.Text.Json.JsonSerializer.Serialize(vulnerabilityData, new JsonSerializerOptions {WriteIndented = true}));
            return vulnerabilityData;
        }

        public HttpResponseMessage PostVulnerabilityData(VModel.VulnerabilityData vulnerabilityData, Dictionary<string, string> customer)
        {
            // Token
            var token = GetToken(customer);

            // Message
            DataMessage<VModel.VulnerabilityData, string> dataMessage = new DataMessage<VModel.VulnerabilityData, string>();
            dataMessage.data = new List<VModel.VulnerabilityData>();
            dataMessage.data.Add(vulnerabilityData);
            _logger.LogInformation(System.Text.Json.JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true }));

            // Client
            var client = new HttpClient();

            // Request
            // NB: Customer id (CShort) is hard coded to 'open' in both URL and HEADER
            var postUrl = $"{Environment.GetEnvironmentVariable("TARTARUS_BASE_URI")}{Constant.VERSION_PATH}/{Constant.TYPE_CUSTOMERS}/open/{Constant.TYPE_VULNERABILITIES}/";
            var request = new HttpRequestMessage(HttpMethod.Post, postUrl);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("X-Company-Short", $"{customer["name"]}");
            request.Headers.Add("Authorization", $"bearer {token}");
            request.Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true }), Encoding.UTF8, "application/json");

            // Response
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = client.SendAsync(request).Result;

                // Content
                var content = response.Content.ReadAsStringAsync().Result;

                if (response.IsSuccessStatusCode)
                {
                    return new HttpResponseMessage(HttpStatusCode.OK);
                }
                else
                {
                    throw new DefenderAssetScanException("Unable to post defender vulnerabilities to the database.");
                }
            }
            catch (DefenderAssetScanException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
        }

        // Tokens
        // Need to get a token from each env
        // Pass Tenant Id for each tenant get token
        public string GetToken(Dictionary<string, string> customer)
        {
            // var client = new SecretClient(new Uri(Environment.GetEnvironmentVariable("VAULT_URI")), new DefaultAzureCredential());

            string tenantId = Environment.GetEnvironmentVariable("TENANT_ID");
            string appId = Environment.GetEnvironmentVariable("CLIENT_ID");
            string appSecret = Environment.GetEnvironmentVariable("DEFENDER_SECRET");

            const string authority = Constant.DEFENDER_AUTHORITY;
            const string audience = Constant.DEFENDER_AUDIENCE;

            IConfidentialClientApplication myApp = ConfidentialClientApplicationBuilder.Create(appId).WithClientSecret(appSecret).WithAuthority($"{authority}/{tenantId}").Build();
            List<string> scopes = new List<string>() { $"{audience}/.default" };
            AuthenticationResult authResult = myApp.AcquireTokenForClient(scopes).ExecuteAsync().GetAwaiter().GetResult();
            return authResult.AccessToken;
        }
    }
}