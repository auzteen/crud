﻿using System;
using System.Threading;
using System.Threading.Tasks;
using tartarus.Model.Mitigation;

namespace tartarus.Repository
{

    /// <summary>
    /// 
    /// </summary>
    public interface IMitigationActionRepository
    {
        /// <summary>
        /// Create a new reord to MitigationAction table
        /// </summary>
        /// <param name="mitigationAction"></param>
        /// <param name="cancellationToken"</param>
        /// <returns></returns>
        Task CreateMitigationActionAsync(MitigationAction mitigationAction, CancellationToken cancellationToken);

    }
}

