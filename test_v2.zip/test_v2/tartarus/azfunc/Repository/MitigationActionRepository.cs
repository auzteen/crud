﻿using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using tartarus.Common.Extensions;
using tartarus.Model.Mitigation;

namespace tartarus.Repository
{

    public class MitigationActionRepository : IMitigationActionRepository
    {

        private readonly SqlConnection _sqlConnection;

        public MitigationActionRepository(SqlConnection sqlConnection)
        {
            _sqlConnection = sqlConnection;
        }

        public Task CreateMitigationActionAsync(MitigationAction mitigationAction, CancellationToken cancellationToken = default)
        {

            var sqlCommand = @"INSERT INTO MitigationAction
                              (
                                MitigationId,
                                Status,
                                Assignee,
                                ActionDescription,
                                CreatedUTC,
                                ModifiedUTC
                              )
                              VALUES
                              (
                                @MitigationId,
                                @Status,
                                @Assignee,
                                @ActionDescription,
                                @CreatedUTC,
                                @ModifiedUTC
                              )";

            return _sqlConnection.ExecuteSqlCommandAsync(sqlCommand: sqlCommand,
                parameters: mitigationAction,
                cancellationToken: cancellationToken);
        }

    }
}

