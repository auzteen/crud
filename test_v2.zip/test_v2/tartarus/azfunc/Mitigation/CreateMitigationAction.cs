﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using tartarus.Model.Mitigation;
using tartarus.Services.Interface;
using tartarus.Shared.Extensions;
using Tartarus.Shared;

namespace tartarus.Functions
{
    public class CreateMitigationAction
    {

        private readonly IMitigationActionService _mitigationActionService;

        public CreateMitigationAction(IMitigationActionService mitigationActionService)
        {
            _mitigationActionService = mitigationActionService;
        }


        [FunctionName(nameof(CreateMitigationAction))]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = Constant.MITIGATION_ACTION_ROUTE)] HttpRequest req,
            int mitigationId,
            ILogger log,
            CancellationToken cancellationToken)
        {

            try
            {
                //TODO: Should be refactored if we need validate bearer token.
                await Tartarus.Shared.Common.ValidateBearertokenAsync(req.Headers["Authorization"]).ConfigureAwait(false);

                var requestBody = await new StreamReader(req.Body).ReadToEndAsync().ConfigureAwait(false);
                var mitigationAction = JsonConvert.DeserializeObject<MitigationAction>(requestBody);

                mitigationAction.MitigationId = mitigationId;
                mitigationAction.CompanyShortName = req.Headers["X-Company-Short"];

                await _mitigationActionService.CreateMitigationActionAsync(mitigationAction: mitigationAction, cancellationToken: cancellationToken).ConfigureAwait(false);

                return new OkResult();

            }
            catch (Exception ex)
            {
                log.LogError(ex, $"Encountered error while executing function: {ex.Message}");
                return ex.ToActionResult();
            }

        }

    }
}

