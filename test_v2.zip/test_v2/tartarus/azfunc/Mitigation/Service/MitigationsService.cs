using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using Tartarus.Shared;
using System.Dynamic;
using System.Text.Json;
using Microsoft.AspNetCore.Http.Extensions;
using MModel = Tartarus.Mitigation.Model;

namespace Tartarus.Mitigation
{
    public class MitigationsService : IMitigationsService
    {
        private readonly ILogger<IMitigationsService> _logger;
        private readonly IDatabaseService _dbservice;

        public MitigationsService(ILogger<IMitigationsService> log, IDatabaseService dbservice)
        {
            _logger = log;
            _dbservice = dbservice;
        }

        /*
         *
         * Core Functions
         *
         * GET
        */
        public ObjectResult ManageGetRequest(HttpRequest req)
        {
            // Company Short
            var companyShortName = req.Headers["X-Company-Short"];

            // Response Data
            List<MModel.MitigationData> mitigationDataList = new List<MModel.MitigationData>();
            Dictionary<string, int> counts = new Dictionary<string, int>();

            //Pagination
            string pageLimit = req.Query["page[limit]"];
            string pageOffset = req.Query["page[offset]"];
            string url = req.Path;

            pageLimit = pageLimit == null ? Constant.DEFAULT_VULNERABILITY_PAGE_SIZE : pageLimit;
            pageOffset = pageOffset == null ? Constant.DEFAULT_VULNERABILITY_PAGE_OFFSET : pageOffset;
            int calculatedOffset = (Int32.Parse(pageOffset) - 1) * (Int32.Parse(pageLimit));

            GetMitigationPageMetaData(companyShortName, Int32.Parse(pageLimit), out int totalRecords, out int totalPageCount);

            // SQL
            SqlConnection conn = _dbservice.GetSqlConnection();

            SqlCommand comm = new SqlCommand(Constant.GET_OFFSET_PAGE_MITIGATION, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@PageLimit", SqlDbType.Int));
            comm.Parameters["@PageLimit"].Direction = ParameterDirection.Input;
            comm.Parameters["@PageLimit"].Value = Int32.Parse(pageLimit);

            comm.Parameters.Add(new SqlParameter("@PageOffset", SqlDbType.Int));
            comm.Parameters["@PageOffset"].Direction = ParameterDirection.Input;
            comm.Parameters["@PageOffset"].Value = calculatedOffset;

            comm.Parameters.Add(new SqlParameter("@CompanyShortName", SqlDbType.NVarChar, 15));
            comm.Parameters["@CompanyShortName"].Direction = ParameterDirection.Input;
            comm.Parameters["@CompanyShortName"].Value = companyShortName.ToString();

            // Containers
            MModel.Mitigations mitigations = new MModel.Mitigations();
            List<MModel.Mitigation> mitigationList = new List<MModel.Mitigation>();

            bool emptyMitigation = true;
            MModel.MitigationData mitigationData;

            // Go
            try
            {
                conn.Open();
                using (SqlDataReader reader = comm.ExecuteReader())
                {
                    if (!reader.HasRows)
                        throw new NoRecordsFoundException("No mitigations found for customer");
                    else
                    {
                        mitigationData = CreateNewMitigationDataObject();
                        mitigationData.PageCount = totalPageCount;
                        mitigationData.TotalRecords = totalRecords;
                    }
                    while (reader.Read())
                    {
                        if (!emptyMitigation)
                        {
                            mitigationData.attributes = mitigations;
                            mitigationData.PageCount = totalPageCount;
                            mitigationData.TotalRecords = totalRecords;
                            mitigationDataList.Add(mitigationData);
                            mitigationData = CreateNewMitigationDataObject();
                        }
                        mitigations = new MModel.Mitigations();
                        mitigationList = new List<MModel.Mitigation>();

                        // Vulerability
                        MModel.Mitigation mitigation = new MModel.Mitigation();

                        // Load
                        for (var i = 0; i < reader.FieldCount; i++)
                        {
                            var fieldName = reader.GetName(i);

                            switch (fieldName)
                            {
                                case "MID":
                                    mitigation.MID = (int)reader[i];
                                    break;
                                case "Status":
                                    mitigation.Status = (string)reader[i];
                                    break;
                                case "InCisa":
                                    mitigation.InCisa = (bool)reader[i];
                                    break;
                                case "InMisp":
                                    mitigation.InMisp = (bool)reader[i];
                                    break;
                                case "Assignee":
                                    mitigation.Assignee = (string)reader[i];
                                    break;
                                case "AssetName":
                                    mitigation.AssetName = (string)reader[i];
                                    break;
                                case "AssetType":
                                    mitigation.AssetType = (string)reader[i];
                                    break;
                                case "CompanyShortName":
                                    mitigation.CompanyShortName = (string)reader[i];
                                    break;
                                case "OS":
                                    mitigation.OS = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "VendorName":
                                    mitigation.VendorName = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "ProductName":
                                    mitigation.ProductName = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "ProductVersion":
                                    mitigation.ProductVersion = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "CVEID":
                                    mitigation.CVEID = (string)reader[i];
                                    break;
                                case "IPAddress":
                                    mitigation.IPAddress = (string)reader[i];
                                    break;
                                case "FQDN":
                                    mitigation.FQDN = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "Severity":
                                    mitigation.Severity = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "Immutability":
                                    mitigation.Immutability = (bool)reader[i];
                                    break;
                                case "Created":
                                    mitigation.Created = (DateTime)reader[i];
                                    break;
                                case "Modified":
                                    mitigation.Modified = (DateTime)reader[i];
                                    break;
                                default:
                                    break;
                            }
                        }

                        // Append
                        mitigationList.Add(mitigation);
                        mitigations.mitigationList = mitigationList;
                        emptyMitigation = false;

                    }
                    // Append
                    mitigationData.attributes = mitigations;
                    mitigationDataList.Add(mitigationData);
                }
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogInformation(e.Message + $" -- customer {companyShortName}");
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }

            // Response
            DataMessage<MModel.MitigationData, Dictionary<string, int>> responseMessage = new DataMessage<MModel.MitigationData, Dictionary<string, int>>();

            // Mitigation List
            responseMessage.data = mitigationDataList;

            // Links
            Links links = BuildMitigationLinks(req, Int32.Parse(pageLimit), Int32.Parse(pageOffset), responseMessage.data[0].PageCount, responseMessage.data[0].TotalRecords);
            responseMessage.links = links;

            // Counts
            counts["Page Count"] = responseMessage.data[0].PageCount;
            counts["Total Records"] = responseMessage.data[0].TotalRecords;

            // Results
            Meta<Dictionary<string, int>> meta = new Meta<Dictionary<string, int>>();
            responseMessage.meta = meta;
            responseMessage.meta.result = new Dictionary<string, int>();
            responseMessage.meta.result = counts;

            return Common.ReturnResponse(JsonSerializer.Serialize(responseMessage, new JsonSerializerOptions { WriteIndented = true }), 200, false);
        }

        /*
         * PATCH
        */
        public ObjectResult ManagePatchRequest(HttpRequest req)
        {
            // Invalid Updates
            List<ExpandoObject> invalidUpdatesList = new List<ExpandoObject>();

            // Request
            var responseBody = GetRequestBody(req);
            var dataMessage = GetMitigationUpdateDataMessage(responseBody.Result);

            // Process Volunerabilities
            foreach (var message in dataMessage.data)
            {
                foreach (var update in message.attributes.updateList)
                {
                    try
                    {
                        UpdateMitigation(update);
                    }
                    catch (Exception e)
                    {
                        _logger.LogError(e.Message);
                        throw;
                    }
                }
            }

            // Reponse Message
            DataMessage<string, List<ExpandoObject>> responseMessage = new DataMessage<string, List<ExpandoObject>>();
            responseMessage.data = null;
            responseMessage.links = null;
            responseMessage.jsonApi = null;
            responseMessage.meta = new Meta<List<ExpandoObject>>();

            if (invalidUpdatesList.Count == 0)
            {
                var invalidUpdateList = new List<string>();
                ExpandoObject ex = new ExpandoObject();
                string msg = "All updates successfully applied";
                ex.TryAdd("Message", msg);
                invalidUpdatesList.Add(ex);
                responseMessage.meta.result = invalidUpdatesList;
                return Common.ReturnResponse(JsonSerializer.Serialize(responseMessage, new JsonSerializerOptions { WriteIndented = true }), 200, false);
            }
            else
            {
                responseMessage.meta.result = invalidUpdatesList;
                return Common.ReturnResponse(JsonSerializer.Serialize(responseMessage, new JsonSerializerOptions { WriteIndented = true }), 202, false);
            }
        }

        /*
         * Helper Functions
        */
        public async Task<string> GetRequestBody(HttpRequest req)
        {
            try
            {
                using (StreamReader streamReader = new StreamReader(req.Body))
                {
                    return await streamReader.ReadToEndAsync();
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
        }

        public DataMessage<MModel.MitigationData, List<ExpandoObject>> GetMitigationDataMessage(string responseBody)
        {
            try
            {
                return System.Text.Json.JsonSerializer.Deserialize<DataMessage<MModel.MitigationData, List<ExpandoObject>>>(responseBody);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
        }

        public void UpdateMitigation(MModel.MitigationUpdate update)
        {
            var conn = _dbservice.GetSqlConnection();
            SqlCommand comm = new SqlCommand(Constant.UPDATE_MITIGATION, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@MID", SqlDbType.NVarChar, 10));
            comm.Parameters["@MID"].Direction = ParameterDirection.Input;
            comm.Parameters["@MID"].Value = update.MID;

            comm.Parameters.Add(new SqlParameter("@Status", SqlDbType.NVarChar, 20));
            comm.Parameters["@Status"].Direction = ParameterDirection.Input;
            comm.Parameters["@Status"].Value = update.Status;

            comm.Parameters.Add(new SqlParameter("@Assignee", SqlDbType.NVarChar, 20));
            comm.Parameters["@Assignee"].Direction = ParameterDirection.Input;
            comm.Parameters["@Assignee"].Value = update.Assignee;

            comm.Parameters.Add(new SqlParameter("@Actions", SqlDbType.NVarChar, 20));
            comm.Parameters["@Actions"].Direction = ParameterDirection.Input;
            comm.Parameters["@Actions"].Value = update.Actions;

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public DataMessage<MModel.MitigationUpdateData, List<ExpandoObject>> GetMitigationUpdateDataMessage(string responseBody)
        {
            try
            {
                return System.Text.Json.JsonSerializer.Deserialize<DataMessage<MModel.MitigationUpdateData, List<ExpandoObject>>>(responseBody);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
        }

        private void GetMitigationPageMetaData(string companyShortName, int pageSize, out int totalRecords, out int totalPageCount)
        {
            string sqlQuery = $"SELECT COUNT(*) FROM vwMitigation WHERE CompanyShortName = '{companyShortName}'";
            totalRecords = _dbservice.GetScalarValueFromQuery(sqlQuery);
            if (pageSize == 0)
                totalPageCount = 1;
            if ((totalRecords % pageSize) == 0)
                totalPageCount = (totalRecords / pageSize);
            else
                totalPageCount = ((totalRecords / pageSize) + 1);
        }

        private int GetNextPageCount(string companyShortName, string pageSize, string cursorVal)
        {
            return GetCursorPageCount(companyShortName, pageSize, cursorVal, "dbo.spGetNextPageMitigationCount");
        }

        private int GetPrevPageCount(string companyShortName, string pageSize, string cursorVal)
        {
            return GetCursorPageCount(companyShortName, pageSize, cursorVal, "dbo.spGetPrevPageMitigationCount");
        }

        private int GetCursorPageCount(string companyShortName, string pageSize, string cursorVal, string spName)
        {
            SqlConnection conn = _dbservice.GetSqlConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand(spName, conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("Limit", pageSize);
            cmd.Parameters.AddWithValue("CursorVal", cursorVal);
            cmd.Parameters.AddWithValue("CompanyShortName", companyShortName);
            var returnVal = cmd.Parameters.Add("@returnVal", SqlDbType.Int);
            returnVal.Direction = ParameterDirection.ReturnValue;
            cmd.ExecuteNonQuery();
            var result = returnVal.Value;
            conn.Close();
            return (int)result;
        }

        private MModel.MitigationData CreateNewMitigationDataObject()
        {
            MModel.MitigationData MitigationData = new MModel.MitigationData();
            MitigationData.id = Guid.NewGuid().ToString();
            return MitigationData;
        }

        private Links BuildMitigationLinks(HttpRequest req, int pageLimit, int pageOffset, int pageCount, int totalRecords)
        {
            string url = req.Path;
            string displayUrl = req.GetDisplayUrl();
            string[] urlArray = displayUrl.Split(Constant.VERSION_PATH);

            Links links = new Links();
            links.self = $"/{Constant.VERSION_PATH}{urlArray[1]}";
            links.first = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]=1" : null;
            links.prev = pageOffset > 1 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset - 1}" : null;
            links.next = pageOffset < pageCount ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset + 1}" : null;
            links.last = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageCount}" : null;

            return links;
        }
    }
}