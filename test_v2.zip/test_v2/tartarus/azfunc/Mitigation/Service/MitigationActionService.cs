﻿using System.Threading;
using System.Threading.Tasks;
using FluentValidation;
using tartarus.Model.Mitigation;
using tartarus.Repository;
using tartarus.Services.Interface;

namespace tartarus.Services
{
    public class MitigationActionService : IMitigationActionService
    {

        private readonly IMitigationActionRepository _mitigationActionRepository;
        private readonly IValidator<MitigationAction> _validator;

        public MitigationActionService(IMitigationActionRepository mitigationActionRepository,
            IValidator<MitigationAction> validator)
        {
            _mitigationActionRepository = mitigationActionRepository;
            _validator = validator;
        }

        public async Task CreateMitigationActionAsync(MitigationAction mitigationAction, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();

            await _validator.ValidateAndThrowAsync(instance: mitigationAction, cancellationToken: cancellationToken).ConfigureAwait(false);

            await _mitigationActionRepository.CreateMitigationActionAsync(mitigationAction: mitigationAction, cancellationToken: cancellationToken).ConfigureAwait(false);
        }

    }
}

