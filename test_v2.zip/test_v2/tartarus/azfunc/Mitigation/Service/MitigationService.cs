using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using MModel = Tartarus.Mitigation.Model;
using Tartarus.Shared;

namespace Tartarus.Mitigation
{
    public class MitigationService : IMitigationService
    {
        private readonly ILogger<IMitigationService> _logger;
        private readonly IDatabaseService _dbservice;

        public MitigationService(ILogger<IMitigationService> log, IDatabaseService dbservice)
        {
            _logger = log;
            _dbservice = dbservice;
        }

        public Task<MModel.Mitigation> GetMitigationAsync(string mid)
        {
            SqlConnection conn = _dbservice.GetSqlConnection();

            SqlCommand comm = new SqlCommand(Constant.GET_MITIGATION, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@MID", SqlDbType.Int));
            comm.Parameters["@MID"].Direction = ParameterDirection.Input;
            comm.Parameters["@MID"].Value = mid;

            comm.Parameters.Add(new SqlParameter("@Msg", SqlDbType.Int));
            comm.Parameters["@Msg"].Direction = ParameterDirection.Output;

            // Our Mitigation
            var mitigation = new MModel.Mitigation();

            // Go
            try
            {
                conn.Open();
                using (var reader = comm.ExecuteReader())
                {
                    if (!reader.HasRows)
                    {
                        throw new NoRecordsFoundException($"Record with MID number: {mid} does not exist.");
                    }

                    // A single record is being returned.
                    while (reader.Read())
                    {
                        for (var i = 0; i < reader.FieldCount; i++)
                        {
                            var fieldName = reader.GetName(i);

                            switch (fieldName)
                            {
                                case "MID":
                                    mitigation.MID = (int)reader[i];
                                    break;
                                case "Status":
                                    mitigation.Status = (string)reader[i];
                                    break;
                                case "InCisa":
                                    mitigation.InCisa = (bool)reader[i];
                                    break;
                                case "InMisp":
                                    mitigation.InMisp = (bool)reader[i];
                                    break;
                                case "Assignee":
                                    mitigation.Assignee = (string)reader[i];
                                    break;
                                case "AssetName":
                                    mitigation.AssetName = (string)reader[i];
                                    break;
                                case "AssetType":
                                    mitigation.AssetType = (string)reader[i];
                                    break;
                                case "CompanyShortName":
                                    mitigation.CompanyShortName = (string)reader[i];
                                    break;
                                case "Source":
                                    mitigation.Source = (string)reader[i];
                                    break;
                                case "SourceId":
                                    mitigation.SourceId = (string)reader[i];
                                    break;
                                case "OS":
                                    mitigation.OS = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "VendorName":
                                    mitigation.VendorName = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "ProductName":
                                    mitigation.ProductName = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "ProductVersion":
                                    mitigation.ProductVersion = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "CVEID":
                                    mitigation.CVEID = (string)reader[i];
                                    break;
                                case "IPAddress":
                                    mitigation.IPAddress = (string)reader[i];
                                    break;
                                case "FQDN":
                                    mitigation.FQDN = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "Severity":
                                    mitigation.Severity = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "Immutability":
                                    mitigation.Immutability = (bool)reader[i];
                                    break;
                                case "Created":
                                    mitigation.Created = (DateTime)reader[i];
                                    break;
                                case "Modified":
                                    mitigation.Modified = (DateTime)reader[i];
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                return Task.FromResult(mitigation);
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogInformation(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}