using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using Tartarus.Shared;
using MModel = Tartarus.Mitigation.Model;
using System.Dynamic;
using System.Text.Json;
using Microsoft.AspNetCore.Http.Extensions;

namespace Tartarus.Mitigation
{
    public class MitigationArchiveService : IMitigationArchiveService
    {
        private readonly ILogger<IMitigationArchiveService> _logger;
        private readonly IDatabaseService _dbservice;

        public MitigationArchiveService(ILogger<IMitigationArchiveService> log, IDatabaseService dbservice)
        {
            _logger = log;
            _dbservice = dbservice;
        }

        /*
         *
         * Core Functions
         *
         * GET
        */
        public ObjectResult ManageGetRequest(HttpRequest req)
        {
            // Company Short
            var companyShortName = req.Headers["X-Company-Short"];

            // Response Data
            List<MModel.MitigationArchiveData> mitigationArchiveDataList = new List<MModel.MitigationArchiveData>();
            Dictionary<string, int> counts = new Dictionary<string, int>();

            //Pagination
            string pageLimit = req.Query["page[limit]"];
            string pageOffset = req.Query["page[offset]"];
            string url = req.Path;

            pageLimit = pageLimit == null ? Constant.DEFAULT_VULNERABILITY_PAGE_SIZE : pageLimit;
            pageOffset = pageOffset == null ? Constant.DEFAULT_VULNERABILITY_PAGE_OFFSET : pageOffset;
            int calculatedOffset = (Int32.Parse(pageOffset) - 1) * (Int32.Parse(pageLimit));

            GetMitigationArchivePageMetaData(companyShortName, Int32.Parse(pageLimit), out int totalRecords, out int totalPageCount);

            // SQL
            SqlConnection conn = _dbservice.GetSqlConnection();

            SqlCommand comm = new SqlCommand(Constant.GET_OFFSET_PAGE_MITIGATION_ARCHIVE, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@PageLimit", SqlDbType.Int));
            comm.Parameters["@PageLimit"].Direction = ParameterDirection.Input;
            comm.Parameters["@PageLimit"].Value = Int32.Parse(pageLimit);

            comm.Parameters.Add(new SqlParameter("@PageOffset", SqlDbType.Int));
            comm.Parameters["@PageOffset"].Direction = ParameterDirection.Input;
            comm.Parameters["@PageOffset"].Value = calculatedOffset;

            comm.Parameters.Add(new SqlParameter("@CompanyShortName", SqlDbType.NVarChar, 15));
            comm.Parameters["@CompanyShortName"].Direction = ParameterDirection.Input;
            comm.Parameters["@CompanyShortName"].Value = companyShortName.ToString();

            // Containers
            MModel.MitigationArchives mitigationArchives = new MModel.MitigationArchives();
            List<MModel.MitigationArchive> mitigationArchiveList = new List<MModel.MitigationArchive>();

            bool emptyMitigationArchive = true;
            MModel.MitigationArchiveData mitigationArchiveData;

            // Go
            try
            {
                conn.Open();
                using (SqlDataReader reader = comm.ExecuteReader())
                {
                    if (!reader.HasRows)
                        throw new NoRecordsFoundException("No mitigations archives found for customer");
                    else
                    {
                        mitigationArchiveData = CreateNewMitigationArchiveDataObject();
                        mitigationArchiveData.PageCount = totalPageCount;
                        mitigationArchiveData.TotalRecords = totalRecords;
                    }
                    while (reader.Read())
                    {
                        if (!emptyMitigationArchive)
                        {
                            mitigationArchiveData.attributes = mitigationArchives;
                            mitigationArchiveData.PageCount = totalPageCount;
                            mitigationArchiveData.TotalRecords = totalRecords;
                            mitigationArchiveDataList.Add(mitigationArchiveData);
                            mitigationArchiveData = CreateNewMitigationArchiveDataObject();
                        }
                        mitigationArchives = new MModel.MitigationArchives();
                        mitigationArchiveList = new List<MModel.MitigationArchive>();

                        // Vulerability
                        MModel.MitigationArchive mitigationArchive = new MModel.MitigationArchive();

                        // Load
                        for (var i = 0; i < reader.FieldCount; i++)
                        {
                            var fieldName = reader.GetName(i);

                            switch (fieldName)
                            {
                                case "MID":
                                    mitigationArchive.MID = (int)reader[i];
                                    break;
                                case "Status":
                                    mitigationArchive.Status = (string)reader[i];
                                    break;
                                case "InCisa":
                                    mitigationArchive.InCisa = (bool)reader[i];
                                    break;
                                case "InMisp":
                                    mitigationArchive.InMisp = (bool)reader[i];
                                    break;
                                case "Assignee":
                                    mitigationArchive.Assignee = (string)reader[i];
                                    break;
                                case "AssetName":
                                    mitigationArchive.AssetName = (string)reader[i];
                                    break;
                                case "AssetType":
                                    mitigationArchive.AssetType = (string)reader[i];
                                    break;
                                case "CompanyShortName":
                                    mitigationArchive.CompanyShortName = (string)reader[i];
                                    break;
                                case "OS":
                                    mitigationArchive.OS = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "VendorName":
                                    mitigationArchive.VendorName = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "ProductName":
                                    mitigationArchive.ProductName = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "ProductVersion":
                                    mitigationArchive.ProductVersion = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "CVEID":
                                    mitigationArchive.CVEID = (string)reader[i];
                                    break;
                                case "IPAddress":
                                    mitigationArchive.IPAddress = (string)reader[i];
                                    break;
                                case "FQDN":
                                    mitigationArchive.FQDN = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "Severity":
                                    mitigationArchive.Severity = reader.IsDBNull(i) ? null : (string)reader[i];
                                    break;
                                case "Immutability":
                                    mitigationArchive.Immutability = (bool)reader[i];
                                    break;
                                case "Created":
                                    mitigationArchive.Created = (DateTime)reader[i];
                                    break;
                                default:
                                    break;
                            }
                        }

                        // Append
                        mitigationArchiveList.Add(mitigationArchive);
                        mitigationArchives.mitigationArchiveList = mitigationArchiveList;
                        emptyMitigationArchive = false;

                    }
                    // Append
                    mitigationArchiveData.attributes = mitigationArchives;
                    mitigationArchiveDataList.Add(mitigationArchiveData);
                }
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogInformation(e.Message + $" -- customer {companyShortName}");
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }

            // Response
            DataMessage<MModel.MitigationArchiveData, Dictionary<string, int>> responseMessage = new DataMessage<MModel.MitigationArchiveData, Dictionary<string, int>>();

            // Mitigation List
            responseMessage.data = mitigationArchiveDataList;

            // Links
            Links links = BuildMitigationLinks(req, Int32.Parse(pageLimit), Int32.Parse(pageOffset), responseMessage.data[0].PageCount, responseMessage.data[0].TotalRecords);
            responseMessage.links = links;

            // Counts
            counts["Page Count"] = responseMessage.data[0].PageCount;
            counts["Total Records"] = responseMessage.data[0].TotalRecords;

            // Results
            Meta<Dictionary<string, int>> meta = new Meta<Dictionary<string, int>>();
            responseMessage.meta = meta;
            responseMessage.meta.result = new Dictionary<string, int>();
            responseMessage.meta.result = counts;

            return Common.ReturnResponse(JsonSerializer.Serialize(responseMessage, new JsonSerializerOptions { WriteIndented = true }), 200, false);
        }

        /*
         * Helper Functions
        */
        public async Task<string> GetRequestBody(HttpRequest req)
        {
            try
            {
                using (StreamReader streamReader = new StreamReader(req.Body))
                {
                    return await streamReader.ReadToEndAsync();
                }
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
        }

        public DataMessage<MModel.MitigationArchiveData, List<ExpandoObject>> GetMitigationArchiveDataMessage(string responseBody)
        {
            try
            {
                return System.Text.Json.JsonSerializer.Deserialize<DataMessage<MModel.MitigationArchiveData, List<ExpandoObject>>>(responseBody);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
        }

        private void GetMitigationArchivePageMetaData(string companyShortName, int pageSize, out int totalRecords, out int totalPageCount)
        {
            string sqlQuery = $"SELECT COUNT(*) FROM vwMitigationArchive WHERE CompanyShortName = '{companyShortName}'";
            totalRecords = _dbservice.GetScalarValueFromQuery(sqlQuery);
            if (pageSize == 0)
                totalPageCount = 1;
            if ((totalRecords % pageSize) == 0)
                totalPageCount = (totalRecords / pageSize);
            else
                totalPageCount = ((totalRecords / pageSize) + 1);
        }

        private int GetNextPageCount(string companyShortName, string pageSize, string cursorVal)
        {
            return GetCursorPageCount(companyShortName, pageSize, cursorVal, "dbo.spGetNextPageMitigationArchiveCount");
        }

        private int GetPrevPageCount(string companyShortName, string pageSize, string cursorVal)
        {
            return GetCursorPageCount(companyShortName, pageSize, cursorVal, "dbo.spGetPrevPageMitigationArchiveCount");
        }

        private int GetCursorPageCount(string companyShortName, string pageSize, string cursorVal, string spName)
        {
            SqlConnection conn = _dbservice.GetSqlConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand(spName, conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("Limit", pageSize);
            cmd.Parameters.AddWithValue("CursorVal", cursorVal);
            cmd.Parameters.AddWithValue("CompanyShortName", companyShortName);
            var returnVal = cmd.Parameters.Add("@returnVal", SqlDbType.Int);
            returnVal.Direction = ParameterDirection.ReturnValue;
            cmd.ExecuteNonQuery();
            var result = returnVal.Value;
            conn.Close();
            return (int)result;
        }

        private MModel.MitigationArchiveData CreateNewMitigationArchiveDataObject()
        {
            MModel.MitigationArchiveData mitigationArchiveData = new MModel.MitigationArchiveData();
            mitigationArchiveData.id = Guid.NewGuid().ToString();
            return mitigationArchiveData;
        }

        private Links BuildMitigationLinks(HttpRequest req, int pageLimit, int pageOffset, int pageCount, int totalRecords)
        {
            string url = req.Path;
            string displayUrl = req.GetDisplayUrl();
            string[] urlArray = displayUrl.Split(Constant.VERSION_PATH);

            Links links = new Links();
            links.self = $"/{Constant.VERSION_PATH}{urlArray[1]}";
            links.first = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]=1" : null;
            links.prev = pageOffset > 1 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset - 1}" : null;
            links.next = pageOffset < pageCount ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset + 1}" : null;
            links.last = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageCount}" : null;

            return links;
        }
    }
}