using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using MModel = Tartarus.Mitigation.Model;

namespace Tartarus.Mitigation
{
    public interface IMitigationService
    {
        public Task<MModel.Mitigation> GetMitigationAsync(string vid);
    }
}