﻿using System;
using System.Threading;
using System.Threading.Tasks;
using tartarus.Model.Mitigation;

namespace tartarus.Services.Interface
{
    public interface IMitigationActionService
    {
        /// <summary>
        /// Create a new MitigationAction for a specific Mitigation
        /// </summary>
        /// <param name="mitigationAction"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        Task CreateMitigationActionAsync(MitigationAction mitigationAction, CancellationToken cancellationToken);

    }
}

