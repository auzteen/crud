using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace Tartarus.Mitigation
{
    public interface IMitigationsService
    {
        // Main Vulnerability Functions
        public ObjectResult ManageGetRequest(HttpRequest req);
        public ObjectResult ManagePatchRequest(HttpRequest req);
    }
}