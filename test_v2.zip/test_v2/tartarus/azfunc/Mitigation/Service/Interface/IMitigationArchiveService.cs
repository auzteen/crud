using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace Tartarus.Mitigation
{
    public interface IMitigationArchiveService
    {
        // Main Mitigation Archive Functions
        public ObjectResult ManageGetRequest(HttpRequest req);
    }
}