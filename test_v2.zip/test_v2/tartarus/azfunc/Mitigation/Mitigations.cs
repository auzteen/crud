using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Data.SqlClient;
using Tartarus.Shared;

namespace Tartarus.Mitigation
{
    public class Mitigations
    {
        private readonly ILogger<Mitigations> _logger;
        private readonly IMitigationsService _mService;
        public Mitigations(ILogger<Mitigations> log, IMitigationsService mService)
        {
            _logger = log;
            _mService = mService;
        }

        [FunctionName(Constant.MITIGATIONS)]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "patch", Route = Constant.MITIGATIONS_ROUTE)] HttpRequest req,
            ILogger log, string id)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string companyShortName = req.Headers["X-Company-Short"];

            string token = req.Headers["Authorization"];
            if (token == null)
                throw new UnauthorizedAccessException("Unauthorized access");
            else
                await Task.Run(() => Common.ValidateBearertokenAsync(token));

            if (companyShortName == null || companyShortName != id)
                throw new BadRequestException("Bad Request - Missing id (company short)");

            try
            {
                switch (req.Method)
                {
                    case "GET":
                        return await Task.Run(() => _mService.ManageGetRequest(req));
                    case "PATCH":
                        return await Task.Run(() => _mService.ManagePatchRequest(req));
                    default:
                        return new ObjectResult("Houston, we have a problem");
                }
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogInformation(e.Message);
                return Common.ReturnResponse(e.Message, 200, true);
            }
            catch (System.Text.Json.JsonException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse("Invalid JSON request", "400");
            }
            catch (BadRequestException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "400");
            }
            catch (InvalidTokenException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "401");
            }
            catch (UnauthorizedAccessException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "401");
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "500");
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "500");
            }
        }
    }
}
