using System;
using Tartarus.Shared;
using DModel = Tartarus.Mitigation.Model;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Data.SqlClient;
using System.Text.Json;

namespace Tartarus.Mitigation
{
    public class Mitigation
    {
        private readonly ILogger<Mitigation> _logger;
        private readonly IMitigationService _mService;
        public Mitigation(ILogger<Mitigation> log, IMitigationService mService)
        {
            _logger = log;
            _mService = mService;
        }

        [FunctionName(Constant.MITIGATION)]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "patch", Route = Constant.MITIGATION_ROUTE)] HttpRequest req, string mid)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string token = req.Headers["Authorization"];
            if (token == null)
                throw new UnauthorizedAccessException("Unauthorized access");
            else
                await Task.Run(() => Common.ValidateBearertokenAsync(token));

            try
            {
                var mitigation = await Task.Run(() => _mService.GetMitigationAsync(mid).GetAwaiter().GetResult());

                // Message
                DataMessage<string, DModel.Mitigation> dataMessage = new DataMessage<string, DModel.Mitigation>();
                dataMessage.data = null;
                dataMessage.links = null;
                dataMessage.jsonApi = null;
                dataMessage.meta = new Meta<DModel.Mitigation>();
                dataMessage.meta.result = new DModel.Mitigation();
                dataMessage.meta.result = mitigation;

                return new ObjectResult(JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogInformation(e.Message);
                return Common.ReturnResponse(e.Message, 200, true);
            }
            catch (BadRequestException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "400");
            }
            catch (InvalidTokenException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "401");
            }
            catch (UnauthorizedAccessException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "401");
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "500");
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "500");
            }
        }
    }
}
