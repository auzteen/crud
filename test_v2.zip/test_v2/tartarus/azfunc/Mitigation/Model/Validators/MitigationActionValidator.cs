﻿using FluentValidation;
using tartarus.Mitigation.Model;
using tartarus.Model.Mitigation;

namespace tartarus.Validators
{
    public class MitigationActionValidator : AbstractValidator<MitigationAction>
    {
        public MitigationActionValidator()
        {
            RuleFor(x => x.MitigationId).NotNull().GreaterThan(0);
            RuleFor(x => x.ActionDescription).NotNull().NotEmpty();
            RuleFor(x => x.Assignee).NotNull().NotEmpty();
            RuleFor(x => x.CompanyShortName).NotNull().NotEmpty();
            RuleFor(x => x.Status).IsEnumName(typeof(MitigationStatus));

            //TODO: We may validate MitigationId against CompanyShortName
        }
    }
}

