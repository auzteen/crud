using System.Text.Json.Serialization;
using System.Collections.Generic;
using Tartarus.Shared;
using System;

namespace Tartarus.Mitigation.Model
{
    public class MitigationData
    {
        public string id { get; set; }
        public Mitigations attributes { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public Links links { get; set; }

        [JsonIgnore]
        public int PageCount { get; set; }

        [JsonIgnore]
        public int TotalRecords { get; set; }
    }

    public class Mitigations
    {
        public List<Mitigation> mitigationList { get; set; }
    }

    public class Mitigation
    {
        [JsonPropertyName("MID")]
        public int MID { get; set; }

        [JsonPropertyName("Status")]
        public string Status { get; set; }

        [JsonPropertyName("InCisa")]
        public bool InCisa { get; set; }

        [JsonPropertyName("InMisp")]
        public bool InMisp { get; set; }

        [JsonPropertyName("Assignee")]
        public string Assignee { get; set; }

        [JsonPropertyName("Actions")]
        public string Actions { get; set; }

        [JsonPropertyName("AssetName")]
        public string AssetName { get; set; }

        [JsonPropertyName("AssetType")]
        public string AssetType { get; set; }

        [JsonPropertyName("CompanyShortName")]
        public string CompanyShortName { get; set; }

        [JsonPropertyName("Source")]
        public string Source { get; set; }

        [JsonPropertyName("SourceId")]
        public string SourceId { get; set; }
#nullable enable
        [JsonPropertyName("OS")]
        public string? OS { get; set; }

        [JsonPropertyName("VendorName")]
        public string? VendorName { get; set; }

        [JsonPropertyName("ProductName")]
        public string? ProductName { get; set; }

        [JsonPropertyName("ProductVersion")]
        public string? ProductVersion { get; set; }
#nullable disable

        [JsonPropertyName("CVEID")]
        public string CVEID { get; set; }

        [JsonPropertyName("IPAddress")]
        public string IPAddress { get; set; }

#nullable enable
        [JsonPropertyName("FQDN")]
        public string? FQDN { get; set; }

        [JsonPropertyName("Severity")]
        public string? Severity { get; set; }
#nullable disable

        [JsonPropertyName("Immutability")]
        public bool Immutability { get; set; }

        [JsonPropertyName("Created")]
        public DateTime Created { get; set; }

        [JsonPropertyName("Modified")]
        public DateTime Modified { get; set; }
    }
}