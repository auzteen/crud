﻿using System;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;
using tartarus.Mitigation.Model;

namespace tartarus.Model.Mitigation
{
    public class MitigationAction
    {
        public int MitigationId { get; set; }

        public string CompanyShortName { get; set; }

        public string Assignee { get; set; }

        public string ActionDescription { get; set; }

        public string Status { get; set; }

        public DateTime CreatedUTC { get; set; } = DateTime.UtcNow;

        public DateTime ModifiedUTC { get; set; } = DateTime.UtcNow;
    }
}

