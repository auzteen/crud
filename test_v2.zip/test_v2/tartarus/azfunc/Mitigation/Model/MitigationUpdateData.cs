using System.Text.Json.Serialization;
using System.Collections.Generic;

namespace Tartarus.Mitigation.Model
{
    public class MitigationUpdateData
    {
        public string id { get; set; }
        public MitigationUpdates attributes { get; set; }
    }

    public class MitigationUpdates
    {
        public List<MitigationUpdate> updateList { get; set; }
    }

    public class MitigationUpdate
    {
        [JsonPropertyName("MID")]
        public string MID { get; set; }

        [JsonPropertyName("Status")]
        public string Status { get; set; }

        [JsonPropertyName("Assignee")]
        public string Assignee { get; set; }

        [JsonPropertyName("Actions")]
        public string Actions { get; set; }
    }
}