﻿using System;
using Newtonsoft.Json.Linq;
using System.Runtime.Serialization;

namespace tartarus.Mitigation.Model
{
    public enum MitigationStatus
    {
        InProgress,
        Completed,
        Cancelled
    }
}

