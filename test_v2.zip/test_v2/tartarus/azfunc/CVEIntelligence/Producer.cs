using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Tartarus.CVEIntelligence.Model.Nist;
using Tartarus.CVEIntelligence.Service;
using Tartarus.Shared;

namespace Tartarus.CVEIntelligence
{
    public class Producer
    {
        private readonly ILogger _logger;
        public readonly IUtilityService _utilityService;
        private readonly ICisaService _cisaService;
        private readonly IMispService _mispService;
        private readonly IMitreService _mitreService;
        private readonly INistService _nistService;
        private readonly IRedHatService _redHatService;
        private readonly ICirclService _circlService;

        public Producer(
                ILogger<Producer> log,
                IUtilityService utilityService,
                ICisaService cisaService,
                IMispService mispService,
                IMitreService mitreService,
                INistService nistService,
                IRedHatService redHatService,
                ICirclService circlService
        )
        {
            _logger = log;
            _utilityService = utilityService;
            _cisaService = cisaService;
            _mispService = mispService;
            _mitreService = mitreService;
            _nistService = nistService;
            _redHatService = redHatService;
            _circlService = circlService;
        }

        [FunctionName(Constant.DURABLE)]
        public async Task<List<ExpandoObject>> RunOrchestrator([OrchestrationTrigger] IDurableOrchestrationContext context)
        {
            // The big list
            var outputs = new List<ExpandoObject>();

            // The context where the cveid resides.
            var cveid = context.GetInput<UtilityService.CVEID>()?.Id;

            try
            {
                // Cisa
                outputs.Add(await context.CallActivityAsync<ExpandoObject>(nameof(_cisaService.CisaActivity), cveid));

                // Misp (Metasploit)
                outputs.Add(await context.CallActivityAsync<ExpandoObject>(nameof(_mispService.MispActivity), cveid));

                // Mitre
                outputs.Add(await context.CallActivityAsync<ExpandoObject>(nameof(_mitreService.MitreActivity), cveid));

                // NIST
                outputs.Add(await context.CallActivityAsync<ExpandoObject>(nameof(_nistService.NistActivity), cveid));

                // RedHat
                outputs.Add(await context.CallActivityAsync<ExpandoObject>(nameof(_redHatService.RedHatActivity), cveid));

                // Circl
                outputs.Add(await context.CallActivityAsync<ExpandoObject>(nameof(_circlService.CirclActivity), cveid));

                // Metasploit
            }
            catch (Exception e)
            {
                _logger.LogInformation(e.Message);
            }

            // Return
            return outputs;
        }

        [FunctionName(Constant.PRODUCER)]
        public async Task<HttpResponseMessage> HttpStart(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = Constant.PRODUCER_ROUTE)] HttpRequestMessage req,
            [DurableClient] IDurableOrchestrationClient starter,
            string id)
        {
            _logger.LogInformation($"Producer Stated: {DateTime.Now}");
            string instanceId = String.Empty;
            try
            {
                instanceId = await starter.StartNewAsync(Constant.DURABLE, new UtilityService.CVEID { Id = id });

            }
            catch (Exception e)
            {
                _logger.LogInformation(e.Message);
            }
            return starter.CreateCheckStatusResponse(req, instanceId);
        }
    }
}