using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using Tartarus.CVEIntelligence.Service;
using Tartarus.Shared;
using System.Dynamic;
using System.Collections.Generic;

namespace Tartarus.CVEIntelligence
{
    public class Consumer
    {
        private readonly ILogger _logger;
        private readonly IUtilityService _uService;

        public Consumer(ILogger<Consumer> log, IUtilityService uService)
        {
            _logger = log;
            _uService = uService;
        }

        [FunctionName(Constant.CONSUMER)]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = Constant.CONSUMER_ROUTE)] HttpRequest req, string id)
        {
            _logger.LogInformation($"Consumer Started: {DateTime.Now}");

            var response = new List<ExpandoObject>();
            try
            {
                // Trigger the Producer (Durable)
                var getUrl = await Task.Run(() => _uService.Trigger(id));
                _logger.LogWarning($"getUrl {getUrl}");

                // Consume the Durable
                response = await Task.Run(() => _uService.Consume(getUrl, id));
            }
            catch (TriggerDurableError e)
            {
                _logger.LogError(e.Message);
            }
            catch (ConsumeDurableError e)
            {
                _logger.LogError(e.Message);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
            }

            // Message
            DataMessage<string, List<ExpandoObject>> dataMessage = new DataMessage<string, List<ExpandoObject>>();
            dataMessage.data = null;
            dataMessage.jsonApi = null;
            dataMessage.links = null;
            dataMessage.meta = new Meta<List<ExpandoObject>>();
            dataMessage.meta.result = new List<ExpandoObject>();
            dataMessage.meta.result = response;

            return new ObjectResult(JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true }));
        }
    }
}
