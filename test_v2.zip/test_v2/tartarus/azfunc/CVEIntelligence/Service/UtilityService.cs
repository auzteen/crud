using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Tartarus.CVEIntelligence.Model.Durable;
using Tartarus.CVEIntelligence.Model.Mitre;
using Tartarus.CVEIntelligence.Model.Nist;
using Tartarus.CVEIntelligence.Model.RedHat;
using Tartarus.CVEIntelligence.Model.Circl;
using CModel = Tartarus.CVEIntelligence.Model.Cisa;
using Tartarus.Shared;

namespace Tartarus.CVEIntelligence.Service
{
    public class UtilityService : IUtilityService
    {
        private readonly ILogger<UtilityService> _logger;
        private readonly IHttpClientFactory _factory;
        public UtilityService(ILogger<UtilityService> log, IHttpClientFactory factory)
        {
            _logger = log;
            _factory = factory;
        }

        // Consumer Methods
        public async Task<string> Trigger(string id)
        {
            var durableResponse = String.Empty;
            String url = String.Empty;
            try
            {
                // Producer (Durable)
                var client = _factory.CreateClient();
                var getUrl = Environment.GetEnvironmentVariable("TARTARUS_BASE_URI") + Constant.VERSION_PATH + "/" + Constant.PRODUCER + "/" + id;
                _logger.LogWarning($"Trigger: getUrl: {getUrl}");

                // Request
                var request = new HttpRequestMessage(HttpMethod.Get, getUrl);
                _logger.LogWarning($"Trigger: request: {request}");

                // Response
                var response = await client.SendAsync(request);
                _logger.LogWarning($"Trigger: request: {response}");

                if (response.IsSuccessStatusCode)
                {

                    _logger.LogWarning($"Success Status Code: {response.StatusCode}");
                    // Content
                    var content = response.Content.ReadAsStringAsync().Result;

                    // Deserialize
                    var durableData = JsonSerializer.Deserialize<DurableResponseData>(content.ToString());

                    durableResponse = durableData.statusQueryGetUri;
                }
                else
                {
                    throw new TriggerDurableError("Could not trigger the producer");
                }
            }
            catch (TriggerDurableError e)
            {
                _logger.LogInformation(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogInformation(e.Message);
                throw;
            }
            _logger.LogWarning($"Trigger: {durableResponse}");
            return durableResponse;
        }

        public async Task<List<ExpandoObject>> Consume(string url, string id)
        {
            var durableResponse = new List<ExpandoObject>();
            try
            {
                // Consumer (Durable Client)
                var client = _factory.CreateClient();

                // Request
                //var request = new HttpRequestMessage(HttpMethod.Get, url);

                // Loop until completed
                string content = string.Empty;
                var response = new HttpResponseMessage();
                var statusQueryGetUriResponseData = new DurableStatusQueryGetUriResponseData();

                do
                {
                    // (New) Response
                    response = await client.SendAsync(new HttpRequestMessage(HttpMethod.Get, url));
                    _logger.LogError($"Consume: response: {response}");

                    // Content
                    content = response.Content.ReadAsStringAsync().Result;
                    _logger.LogError($"Consume: content: {content}");

                    // StatusQueryGetUriResponseData
                    statusQueryGetUriResponseData = JsonSerializer.Deserialize<DurableStatusQueryGetUriResponseData>(content);
                    _logger.LogError($"Consume: statusQueryGetUriResponseData: {statusQueryGetUriResponseData}");

                    // New Client
                    client = _factory.CreateClient();

                    // Slow Down
                    Thread.Sleep(10);

                } while (statusQueryGetUriResponseData.runtimeStatus != "Completed");

                if (response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Consume: IsSuccessStatusCode: {response.StatusCode}");
                    durableResponse.Add(JsonSerializer.Deserialize<ExpandoObject>(content));
                }
                else
                {
                    throw new TriggerDurableError("Could not trigger the producer");
                }
            }
            catch (ConsumeDurableError e)
            {
                _logger.LogInformation(e.Message, "Could not consume durable results.");
                throw;
            }
            catch (Exception e)
            {
                _logger.LogInformation(e.Message);
                throw;
            }
            _logger.LogError($"Consume: durableResponse: {durableResponse}");
            return durableResponse;
        }

        // CISA Methods
        public CModel.Vulnerability GetCisaRecordData(string cveid)
        {
            // Client
            var client = _factory.CreateClient();

            // Get Url
            var getUrl = Constant.CISA_ROUTE;

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, getUrl);

            // Response
            var response = new HttpResponseMessage();

            try
            {
                response = client.SendAsync(request).Result;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            var content = response.Content.ReadAsStringAsync().Result;

            var cisaRecordData = JsonSerializer.Deserialize<CModel.CisaRecordData>(content);

            var vulnerability = cisaRecordData.vulnerabilities.Find(x => x.cveID == cveid);

            return vulnerability;

        }

        // Metasploit Methods
        public bool IsMisp(string cveid)
        {
            // Client
            var client = _factory.CreateClient();

            // Get Url
            var getUrl = Constant.MISP_HOME;

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, getUrl);

            // Response
            var response = new HttpResponseMessage();

            try
            {
                response = client.SendAsync(request).Result;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            var content = response.Content.ReadAsStringAsync().Result;

            if (content.Contains(cveid))
            {
                return true;
            }
            return false;

        }

        // Mitre Methods
        public MitreRecordData GetMitreRecordData(string id)
        {
            // Mitre record Data
            var mitreRecordData = new MitreRecordData();

            // Client
            var client = _factory.CreateClient();

            // Get Url
            var getUrl = Constant.MITRE_HOME + $"{id}";

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, getUrl);

            // Response
            var response = new HttpResponseMessage();

            try
            {
                response = client.SendAsync(request).Result;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            var content = response.Content.ReadAsStringAsync();

            mitreRecordData = JsonSerializer.Deserialize<MitreRecordData>(content.Result);

            return mitreRecordData;
        }

        // NIST Methods
        public NistRecordData GetNistRecordData(string id)
        {
            // Mitre record Data
            var nistRecordData = new NistRecordData();

            // Client
            var client = _factory.CreateClient();

            // Get Url
            var getUrl = Constant.NIST_HOME + $"{id}";

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, getUrl);

            // Response
            var response = new HttpResponseMessage();

            try
            {
                response = client.SendAsync(request).Result;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            var content = response.Content.ReadAsStringAsync();

            nistRecordData = JsonSerializer.Deserialize<NistRecordData>(content.Result);

            return nistRecordData;
        }

        // Red Hat Methods
        public List<RedHatData> GetRedHatRecordData(string cveid)
        {
            // Mitre record Data
            var matchList = new List<RedHatData>();

            // Client
            var client = _factory.CreateClient();

            // Get Url
            var getUrl = Constant.REDHAT_HOME;

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, getUrl);

            // Response
            var response = new HttpResponseMessage();

            try
            {
                response = client.SendAsync(request).Result;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            var content = response.Content.ReadAsStringAsync().Result;
            var redHatDataList = JsonSerializer.Deserialize<List<RedHatData>>(content);
            matchList = redHatDataList.FindAll(x => x.CVEs.Contains(cveid));

            return matchList;
        }

        // circl Methods
        public CirclRecordData GetCirclRecordData(string cveid)
        {
            // Mitre record Data
            var matchList = new List<RedHatData>();

            // Client
            var client = _factory.CreateClient();

            // Get Url
            var getUrl = Constant.CIRCL_HOME + cveid;

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, getUrl);

            // Response
            var response = new HttpResponseMessage();

            try
            {
                response = client.SendAsync(request).Result;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            var content = response.Content.ReadAsStringAsync().Result;
            return JsonSerializer.Deserialize<CirclRecordData>(content);
        }

        // Miscellaneous Classes
        public class CVEID
        {
            public string Id { get; set; }
        }
    }
}