using System;
using System.Collections.Generic;
using System.Dynamic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Extensions.Logging;
using Tartarus.CVEIntelligence.Service;

namespace Tartarus
{
    public class CisaService : ICisaService
    {
        private readonly ILogger<CisaService> _logger;
        private readonly IUtilityService _utilityService;
        public CisaService(ILogger<CisaService> log, IUtilityService utilityService)
        {
            _logger = log;
            _utilityService = utilityService;
        }

        [FunctionName(nameof(CisaActivity))]
        public ExpandoObject CisaActivity([ActivityTrigger] string cveid)
        {
            _logger.LogInformation($"Red Hat Activity Service: {DateTime.Now}");

            ExpandoObject _cisaResponse = new ExpandoObject();

            var cisaVResponse = _utilityService.GetCisaRecordData(cveid);

            _cisaResponse.TryAdd("Cisa", cisaVResponse);

            return _cisaResponse;
        }

    }
}