using System;
using System.Collections.Generic;
using System.Dynamic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Extensions.Logging;
using Tartarus.CVEIntelligence.Service;

namespace Tartarus
{
    public class MitreService : IMitreService
    {
        private readonly ILogger<MitreService> _logger;
        private readonly IUtilityService _utilityService;
        public MitreService(ILogger<MitreService> log, IUtilityService utilityService)
        {
            _logger = log;
            _utilityService = utilityService;
        }

        [FunctionName(nameof(MitreActivity))]
        public ExpandoObject MitreActivity([ActivityTrigger] string cveid)
        {
            _logger.LogInformation($"Mitre Activity Service: {DateTime.Now}");

            ExpandoObject _mitreResponse = new ExpandoObject();

            var mitreRecordData = _utilityService.GetMitreRecordData(cveid);

            _mitreResponse.TryAdd("Mitre", mitreRecordData);

            return _mitreResponse;
        }

    }
}