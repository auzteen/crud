using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Text.Json;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Extensions.Logging;
using Tartarus.CVEIntelligence.Service;

namespace Tartarus
{
    public class NistService : INistService
    {
        private readonly ILogger<NistService> _logger;
        private readonly IUtilityService _utilityService;
        public NistService(ILogger<NistService> log, IUtilityService utilityService)
        {
            _logger = log;
            _utilityService = utilityService;
        }

        [FunctionName(nameof(NistActivity))]
        public ExpandoObject NistActivity([ActivityTrigger] string cveid)
        {
            _logger.LogInformation($"Nist Activity Service: {DateTime.Now}");

            ExpandoObject _nistResponse = new ExpandoObject();

            var nistRecordData = _utilityService.GetNistRecordData(cveid);

            _nistResponse.TryAdd("Nist", nistRecordData);

            return _nistResponse;
        }

    }
}