using System;
using System.Collections.Generic;
using System.Dynamic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Extensions.Logging;
using Tartarus.CVEIntelligence.Service;

namespace Tartarus
{
    public class RedHatService : IRedHatService
    {
        private readonly ILogger<NistService> _logger;
        private readonly IUtilityService _utilityService;
        public RedHatService(ILogger<NistService> log, IUtilityService utilityService)
        {
            _logger = log;
            _utilityService = utilityService;
        }

        [FunctionName(nameof(RedHatActivity))]
        public ExpandoObject RedHatActivity([ActivityTrigger] string cveid)
        {
            _logger.LogInformation($"Red Hat Activity Service: {DateTime.Now}");

            ExpandoObject _redHatResponse = new ExpandoObject();

            var redHatRecordData = _utilityService.GetRedHatRecordData(cveid);

            _redHatResponse.TryAdd("RedHat", redHatRecordData);

            return _redHatResponse;
        }

    }
}