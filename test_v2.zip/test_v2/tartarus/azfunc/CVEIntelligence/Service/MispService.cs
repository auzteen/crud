using System;
using System.Collections.Generic;
using System.Dynamic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Extensions.Logging;
using Tartarus.CVEIntelligence.Service;

namespace Tartarus
{
    public class MispService : IMispService
    {
        private readonly ILogger<MispService> _logger;
        private readonly IUtilityService _utilityService;
        public MispService(ILogger<MispService> log, IUtilityService utilityService)
        {
            _logger = log;
            _utilityService = utilityService;
        }

        [FunctionName(nameof(MispActivity))]
        public ExpandoObject MispActivity([ActivityTrigger] string cveid)
        {
            _logger.LogInformation($"Misp Activity Service: {DateTime.Now}");

            ExpandoObject _mispResponse = new ExpandoObject();

            var isMisp = _utilityService.IsMisp(cveid);
            _mispResponse.TryAdd("Misp", isMisp);

            return _mispResponse;
        }

    }
}