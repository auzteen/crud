using System;
using System.Collections.Generic;
using System.Dynamic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Extensions.Logging;
using Tartarus.CVEIntelligence.Service;

namespace Tartarus
{
    public class CirclService : ICirclService
    {
        private readonly ILogger<CirclService> _logger;
        private readonly IUtilityService _utilityService;
        public CirclService(ILogger<CirclService> log, IUtilityService utilityService)
        {
            _logger = log;
            _utilityService = utilityService;
        }

        [FunctionName(nameof(CirclActivity))]
        public ExpandoObject CirclActivity([ActivityTrigger] string cveid)
        {
            _logger.LogInformation($"Circl Activity Service: {DateTime.Now}");

            ExpandoObject _circlResponse = new ExpandoObject();

            var redHatRecordData = _utilityService.GetCirclRecordData(cveid);

            _circlResponse.TryAdd("Circl", redHatRecordData);

            return _circlResponse;
        }

    }
}