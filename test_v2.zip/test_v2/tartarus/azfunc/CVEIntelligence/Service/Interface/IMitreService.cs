using System.Dynamic;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;

namespace Tartarus.CVEIntelligence.Service
{
    public interface IMitreService
    {
        public ExpandoObject MitreActivity([ActivityTrigger] string cveid);
    }
}