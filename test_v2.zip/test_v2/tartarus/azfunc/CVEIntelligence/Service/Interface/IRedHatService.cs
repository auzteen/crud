using System.Dynamic;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;

namespace Tartarus.CVEIntelligence.Service
{
    public interface IRedHatService
    {
        public ExpandoObject RedHatActivity([ActivityTrigger] string cveid);
    }
}