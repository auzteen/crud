using System.Dynamic;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;

namespace Tartarus.CVEIntelligence.Service
{
    public interface IMispService
    {
        public ExpandoObject MispActivity([ActivityTrigger] string cveid);
    }
}