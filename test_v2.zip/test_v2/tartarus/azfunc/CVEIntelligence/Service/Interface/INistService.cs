using System.Dynamic;
using System.Net.Http;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;

namespace Tartarus.CVEIntelligence.Service
{
    public interface INistService
    {
        public ExpandoObject NistActivity([ActivityTrigger] string cveid);
    }
}