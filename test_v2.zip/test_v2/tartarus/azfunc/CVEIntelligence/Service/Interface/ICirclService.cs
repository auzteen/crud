using System.Dynamic;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;

namespace Tartarus.CVEIntelligence.Service
{
    public interface ICirclService
    {
        public ExpandoObject CirclActivity([ActivityTrigger] string cveid);
    }
}