using System.Dynamic;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;

namespace Tartarus.CVEIntelligence.Service
{
    public interface ICisaService
    {
        public ExpandoObject CisaActivity([ActivityTrigger] string cveid);
    }
}