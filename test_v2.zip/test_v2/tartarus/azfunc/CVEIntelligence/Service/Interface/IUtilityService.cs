using System.Collections.Generic;
using System.Dynamic;
using System.Threading.Tasks;
using Tartarus.CVEIntelligence.Model.Mitre;
using Tartarus.CVEIntelligence.Model.Nist;
using Tartarus.CVEIntelligence.Model.RedHat;
using Tartarus.CVEIntelligence.Model.Circl;
using CModel = Tartarus.CVEIntelligence.Model.Cisa;

namespace Tartarus.CVEIntelligence.Service
{
    public interface IUtilityService
    {

        // Durble Methods
        public Task<string> Trigger(string id);
        public Task<List<ExpandoObject>> Consume(string url, string id);

        // Cisa Methods
        public CModel.Vulnerability GetCisaRecordData(string cveid);

        // Metasploit Methods
        public bool IsMisp(string cveid);

        // Mitre Methods
        public MitreRecordData GetMitreRecordData(string id);

        // Nist Methods
        public NistRecordData GetNistRecordData(string id);

        // Red Hat Methods
        public List<RedHatData> GetRedHatRecordData(string cveid);

        // Circl Methods
        public CirclRecordData GetCirclRecordData(string cveid);
    }
}