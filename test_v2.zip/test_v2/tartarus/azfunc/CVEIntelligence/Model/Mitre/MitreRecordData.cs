using System.Collections.Generic;

namespace Tartarus.CVEIntelligence.Model.Mitre
{
    public class MitreRecordData
    {
        public Containers containers { get; set; }
        public CveMetaData cveMetadata { get; set; }
        public string dataType { get; set; }
        public string dataVersion { get; set; }
    }

    public class Containers
    {
        public Cna cna { get; set; }
    }

    public class Cna
    {
        public List<Affected> affected { get; set; }
        public List<CnaDescription> descriptions { get; set; }
        public List<ProblemTypes> problemTypes { get; set; }
        public ProviderMetadata providerMetadata { get; set; }
        public List<References> references { get; set; }
    }

    public class Affected
    {
        public string vendor { get; set; }
        public string product { get; set; }
        public List<Version> versions { get; set; }
    }

    public class Version
    {
        public string version { get; set; }
        public string status { get; set; }
    }

    public class CnaDescription
    {
        public string lang { get; set; }
        public string value { get; set; }
    }

    public class ProblemTypes
    {
        public List<PtDescription> descriptions { get; set; }
    }

    public class PtDescription
    {
        public string description { get; set; }
        public string lang { get; set; }
        public string type { get; set; }
    }

    public class ProviderMetadata
    {
        public string orgId { get; set; }
        public string shortName { get; set; }
        public string dateUpdated { get; set; }
    }

    public class References
    {
        public string name { get; set; }
        public string[] tags { get; set; }
        public string url { get; set; }
    }

    public class CveMetaData
    {
        public string assignerOrgId { get; set; }
        public string cveId { get; set; }
        public string state { get; set; }
        public string assignerShortName { get; set; }
        public string requesterUserId { get; set; }
        public string dateReserved { get; set; }
        public string datePublished { get; set; }
    }
}