using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Tartarus.CVEIntelligence.Model.Circl
{
    public class CirclRecordData
    {
        public string modified { get; set; }
        public string published { get; set; }
        public Access access { get; set; }
        public string assigner { get; set; }
        public List<Capec> capec { get; set; }
        public double cvss { get; set; }

        [JsonPropertyName("cvss-time")]
        public string cvssTime { get; set; }

        [JsonPropertyName("cvss-vector")]
        public string cvssVector { get; set; }
        public string cwe { get; set; }
        public string id { get; set; }
        public Impact impact { get; set; }

        [JsonPropertyName("last-modified")]
        public string lastModified { get; set; }
        public List<MsBulletin> msBulletin { get; set; }
        public List<Oval> oval { get; set; }
        public string[] references { get; set; }
        public RefMap refmap { get; set; }
        public List<Saint> saint { get; set; }
        public string summary { get; set; }
        public List<Vulnerable_Configuration> vulnerable_configuration { get; set; }
        public string[] vulnerable_configuration_cpe_2_2 { get; set; }
        public string[] vulnerable_product { get; set; }
    }

    public class Access
    {
        public string authentication { get; set; }
        public string complexity { get; set; }
        public string vector { get; set; }
    }

    public class Capec
    {
        public string id { get; set; }
        public string name { get; set; }
        public string prerequisites { get; set; }
        public string[] related_weakness { get; set; }
        public string solutions { get; set; }
        public string summary { get; set; }
    }

    public class Impact
    {
        public string availability { get; set; }
        public string confidentiality { get; set; }
        public string integrity { get; set; }
    }

    public class MsBulletin
    {
        public string bulletin_id { get; set; }
        public string bulletin_url { get; set; }
        public string date { get; set; }
        public string impact { get; set; }
        public string knowledgebase_id { get; set; }
        public string severity { get; set; }
        public string title { get; set; }
    }

    public class Oval
    {
        public string accepted { get; set; }

        [JsonPropertyName("class")]
        public string cls { get; set; }
        public List<Contributors> contributors { get; set; }
        public List<Definition_Extensions> definition_extensions { get; set; }
        public string description { get; set; }
        public string family { get; set; }
        public string id { get; set; }
        public string status { get; set; }
        public string submitted { get; set; }
        public string title { get; set; }
        public string version { get; set; }
    }

    public class Contributors
    {
        public string name { get; set; }
        public string organization { get; set; }
    }

    public class Definition_Extensions
    {
        public string comment { get; set; }
        public string oval { get; set; }
    }

    public class RefMap
    {
        public string[] bid { get; set; }
        public string[] cert { get; set; }
        public string[] idefense { get; set; }
        public string[] sectrack { get; set; }
        public string[] secunia { get; set; }
        public string[] sreason { get; set; }
        public string[] vupen { get; set; }
    }

    public class Saint
    {
        public string bid { get; set; }
        public string description { get; set; }
        public string id { get; set; }
        public string osvdb { get; set; }
        public string title { get; set; }
        public string type { get; set; }
    }

    public class Vulnerable_Configuration
    {
        public string id { get; set; }
        public string title { get; set; }
    }
}