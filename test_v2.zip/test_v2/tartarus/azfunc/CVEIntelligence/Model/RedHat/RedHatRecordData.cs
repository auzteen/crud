using System.Collections.Generic;

namespace Tartarus.CVEIntelligence.Model.RedHat
{

    public class RedHatRecordData
    {
        public List<RedHatData> redHatDataList { get; set; }
    }

    public class RedHatData
    {
        public string RHSA { get; set; }
        public string severity { get; set; }
        public string released_on { get; set; }
        public string[] CVEs { get; set; }
        public string[] bugzillas { get; set; }
        public string[] released_packages { get; set; }
        public Oval oval { get; set; }
        public string resource_url { get; set; }
    }

    public class Oval
    {
        public bool has_oval { get; set; }
        public string resource_url { get; set; }
    }
}