using System.Collections.Generic;
using System.Dynamic;

namespace Tartarus.CVEIntelligence.Model.Durable
{
    public class DurableStatusQueryGetUriResponseData
    {
        public string name { get; set; }
        public string instanceId { get; set; }
        public string runtimeStatus { get; set; }
        public Input input { get; set; }
        public string customStatus { get; set; }
        public List<Output> outputs { get; set; }
        public string createdTime { get; set; }
        public string lasUpdatedTime { get; set; }
    }

    public class Input
    {
        public string Id { get; set; }
    }

    public class Output
    {
        public List<ExpandoObject> results { get; set; }
    }
}