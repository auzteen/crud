using System.Collections.Generic;

namespace Tartarus.CVEIntelligence.Model.Cisa
{
    public class CisaRecordData
    {
        public string title { get; set; }
        public string catalogVersion { get; set; }
        public string dateReleased { get; set; }
        public int count { get; set; }
        public List<Vulnerability> vulnerabilities { get; set; }
    }

    public class Vulnerability
    {
        public string cveID { get; set; }
        public string vendorProject { get; set; }
        public string product { get; set; }
        public string dateAdded { get; set; }
        public string shortDescription { get; set; }
        public string requiredAction { get; set; }
        public string dueDate { get; set; }
        public string notes { get; set; }
    }
}