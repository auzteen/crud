
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Tartarus.CVEIntelligence.Model.Nist
{
    public class NistRecordData
    {
        public int resultsPerPage { get; set; }
        public int startIndex { get; set; }
        public int totalResults { get; set; }
        public string format { get; set; }
        public string version { get; set; }
        public string timestamp { get; set; }
        public List<Vulnerabilities> vulnerabilities { get; set; }
    }

    public class Vulnerabilities
    {
        public Cve cve { get; set; }
    }

    public class Cve
    {
        public string id { get; set; }
        public string sourceIdentifier { get; set; }
        public string published { get; set; }
        public string vulnStatus { get; set; }
        public List<Descriptions> descriptions { get; set; }
        public Metrics metrics { get; set; }
        public List<Weeknesses> weeknesses { get; set; }
        public List<Configurations> configurations { get; set; }
        public List<References> references { get; set; }
    }

    public class Descriptions
    {
        public string lang { get; set; }
        public string value { get; set; }
    }

    public class Metrics
    {
        public List<CvssMetricV31> cvssMetricV31 { get; set; }
        public List<CvssMetricV2> cvssMetricV2 { get; set; }
    }

    public class CvssMetricV31
    {
        public string source { get; set; }
        public string type { get; set; }
        public CvssDataV31 cvssData { get; set; }
        public double exploitabilityScore { get; set; }
        public double impactScore { get; set; }
    }

    public class CvssDataV31
    {
        public string version { get; set; }
        public string vectorString { get; set; }
        public string attackVector { get; set; }
        public string attackComplexity { get; set; }
        public string privilegesRequired { get; set; }
        public string userInteraction { get; set; }
        public string scope { get; set; }
        public string confidentialityImpact { get; set; }
        public string integrityImpact { get; set; }
        public string availabilityImpact { get; set; }
        public double baseScore { get; set; }
        public string baseSeverity { get; set; }
    }

    public class CvssMetricV2
    {
        public string source { get; set; }
        public string type { get; set; }
        public CvssDataV2 cvssData { get; set; }
        public string baseSeverity { get; set; }
        public double exploitabilityScore { get; set; }
        public double impactScore { get; set; }
        public bool acInsufInfo { get; set; }
        public bool obtainAllPrivilege { get; set; }
        public bool obtainUserPrivilege { get; set; }
        public bool obtainOtherPrivilege { get; set; }
        public bool userInteractionRequired { get; set; }
    }

    public class CvssDataV2
    {
        public string version { get; set; }
        public string vectorString { get; set; }
        public string accessVector { get; set; }
        public string accessComplexity { get; set; }
        public string authentication { get; set; }
        public string confidentialityImpact { get; set; }
        public string integrityImpact { get; set; }
        public string availabilityImpact { get; set; }
        public double baseScore { get; set; }
    }

    public class Weeknesses
    {
        public string source { get; set; }
        public string type { get; set; }
        public List<Descriptions> description { get; set; }
    }

    public class Description
    {
        public string lang { get; set; }
        public string value { get; set; }
    }

    public class Configurations
    {
        public List<Nodes> nodes { get; set; }
    }

    public class Nodes
    {
        [JsonPropertyName("operator")]
        public string op { get; set; }
        public bool negate { get; set; }
        public List<CpeMatch> cpeMatch { get; set; }
    }

    public class CpeMatch
    {
        public bool vulnerable { get; set; }
        public string criteria { get; set; }
        public string versionEndIncluding { get; set; }
        public string matchCriteriaId { get; set; }
    }

    public class References
    {
        public string url { get; set; }
        public string source { get; set; }
        public string[] tags { get; set; }
    }
}