using System.Data.SqlClient;

namespace Tartarus.Shared
{
    public interface IDatabaseService
    {
        public SqlConnection GetSqlConnection();
        public int GetScalarValueFromQuery(string sqlQuery);
    }
}