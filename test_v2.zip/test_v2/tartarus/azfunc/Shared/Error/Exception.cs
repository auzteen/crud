using System;
namespace Tartarus.Shared
{
    public class ExistingAssetsException : Exception
    {
        public ExistingAssetsException()
        {

        }
        public ExistingAssetsException(string message) : base(message)
        {

        }

        public ExistingAssetsException(string message, Exception inner) : base(message, inner)
        {

        }
    }
    public class ExistingCustomerException : Exception
    {
        public ExistingCustomerException()
        {

        }
        public ExistingCustomerException(string message) : base(message)
        {

        }

        public ExistingCustomerException(string message, Exception inner) : base(message, inner)
        {

        }
    }

    public class RangePaginationException : Exception
    {
        public RangePaginationException()
        {

        }

        public RangePaginationException(string message) : base(message)
        {

        }
    }

    public class NoRecordsFoundException : Exception
    {
        public NoRecordsFoundException()
        {

        }

        public NoRecordsFoundException(string message) : base(message)
        {

        }
    }

    public class BadRequestException : Exception
    {
        public BadRequestException()
        {

        }

        public BadRequestException(string message) : base(message)
        {

        }
    }
    public class AssetUpdateException : Exception
    {
        public AssetUpdateException()
        {

        }

        public AssetUpdateException(string message) : base(message)
        {

        }
    }

    public class FailedToUpdateAssetException : Exception
    {
        public FailedToUpdateAssetException()
        {

        }

        public FailedToUpdateAssetException(string message) : base(message)
        {

        }
    }

    public class InvalidTokenException : Exception
    {
        public InvalidTokenException()
        {

        }

        public InvalidTokenException(string message) : base(message)
        {

        }
    }

    public class DefenderAssetScanException : Exception
    {
        public DefenderAssetScanException()
        {

        }

        public DefenderAssetScanException(string message) : base(message)
        {

        }
    }

    public class DefenderVulnerabilityScanException : Exception
    {
        public DefenderVulnerabilityScanException()
        {

        }

        public DefenderVulnerabilityScanException(string message) : base(message)
        {

        }
    }

    public class CISADataCollectionException : Exception
    {
        public CISADataCollectionException()
        {

        }

        public CISADataCollectionException(string message) : base(message)
        {

        }
    }

    public class MISPDataCollectionException : Exception
    {
        public MISPDataCollectionException()
        {

        }

        public MISPDataCollectionException(string message) : base(message)
        {

        }
    }

    public class TriggerDurableError : Exception
    {
        public TriggerDurableError()
        {

        }
        public TriggerDurableError(string message) : base(message)
        {

        }

        public TriggerDurableError(string message, Exception inner) : base(message, inner)
        {

        }
    }

    public class ConsumeDurableError : Exception
    {
        public ConsumeDurableError()
        {

        }
        public ConsumeDurableError(string message) : base(message)
        {

        }

        public ConsumeDurableError(string message, Exception inner) : base(message, inner)
        {

        }
    }
}
