namespace Tartarus.Shared
{
    public class ErrorMessage
    {
        public string statusCode { get; set; }
        public string message { get; set; }
    }
}