using System;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using System.Net.Http;
using System.Net;

namespace Tartarus.Shared
{
    public class Common
    {
        public static ErrorMessage GetErrorResponse(string message, string statusCode)
        {
            ErrorMessage error = new ErrorMessage()
            {
                statusCode = statusCode,
                message = message
            };
            return error;

        }

        public static HttpResponseMessage GetHttpResponse(string message, string statusCode)
        {
            HttpResponseMessage response;
            switch (statusCode)
            {
                case "204":
                    response = new HttpResponseMessage() { StatusCode = HttpStatusCode.NoContent };
                    break;
                default:
                    response = new HttpResponseMessage() { StatusCode = HttpStatusCode.NonAuthoritativeInformation };
                    break;
            }
            return response;

        }

        public static ObjectResult ReturnErrorResponse(string message, string statusCode)
        {
            ErrorMessage error;
            ObjectResult returnObj;
            switch (statusCode)
            {
                case "400":
                    error = Common.GetErrorResponse(message, statusCode);
                    returnObj = new ObjectResult(JsonSerializer.Serialize(error)) { StatusCode = StatusCodes.Status400BadRequest };
                    break;
                case "401":
                    error = Common.GetErrorResponse(message, statusCode);
                    returnObj = new ObjectResult(JsonSerializer.Serialize(error)) { StatusCode = StatusCodes.Status401Unauthorized };
                    break;
                case "403":
                    error = Common.GetErrorResponse(message, statusCode);
                    returnObj = new ObjectResult(JsonSerializer.Serialize(error)) { StatusCode = StatusCodes.Status403Forbidden };
                    break;
                case "404":
                    error = Common.GetErrorResponse(message, statusCode);
                    returnObj = new ObjectResult(JsonSerializer.Serialize(error)) { StatusCode = StatusCodes.Status404NotFound };
                    break;
                case "409":
                    error = Common.GetErrorResponse(message, statusCode);
                    returnObj = new ObjectResult(JsonSerializer.Serialize(error)) { StatusCode = StatusCodes.Status409Conflict };
                    break;
                case "429":
                    error = Common.GetErrorResponse(message, statusCode);
                    returnObj = new ObjectResult(JsonSerializer.Serialize(error)) { StatusCode = StatusCodes.Status429TooManyRequests };
                    break;
                default:
                    error = Common.GetErrorResponse(message, statusCode);
                    returnObj = new ObjectResult(JsonSerializer.Serialize(error)) { StatusCode = StatusCodes.Status500InternalServerError };
                    break;
            }
            return returnObj;
        }

        public static ObjectResult ReturnResponse(string message, int statusCode, bool convert)
        {
            string response = String.Empty;

            if (convert)
            {
                response = GetDataMessage(message);
            }
            else
            {
                response = message;
            }

            switch (statusCode)
            {
                case 200:
                    return new ObjectResult(response)
                    {
                        StatusCode = StatusCodes.Status200OK
                    };
                case 201:
                    return new ObjectResult(response)
                    {
                        StatusCode = StatusCodes.Status201Created
                    };
                case 202:
                    return new ObjectResult(response)
                    {
                        StatusCode = StatusCodes.Status202Accepted
                    };
                case 204:
                    return new ObjectResult(response)
                    {
                        StatusCode = StatusCodes.Status204NoContent
                    };
                default:
                    return new ObjectResult(response)
                    {
                        StatusCode = StatusCodes.Status203NonAuthoritative
                    };
            }
        }

        public static string GetDataMessage(string message)
        {
            DataMessage<string, string> dataMessage = new DataMessage<string, string>();

            dataMessage.data = null;
            dataMessage.links = null;
            dataMessage.jsonApi = null;
            dataMessage.meta = new Meta<string>();
            dataMessage.meta.result = new String(message);

            return JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true });
        }

        public static async Task<bool> ValidateBearertokenAsync(string token)
        {
            token = token.Remove(0, 7);

            var issuer = Environment.GetEnvironmentVariable("CERTIFICATE_ISSUER");
            var audience = Environment.GetEnvironmentVariable("CERTIFICATE_AUDIENCE");

            var discoveryEndpoint = String.Format("{0}.well-known/openid-configuration", issuer);
            System.Threading.CancellationToken cancellationToken = new System.Threading.CancellationToken();
            OpenIdConnectConfiguration config = await OpenIdConnectConfigurationRetriever.GetAsync(discoveryEndpoint, cancellationToken);
            var tokenHandler = new JwtSecurityTokenHandler();

            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = issuer,
                    ValidAudience = audience,
                    IssuerSigningKeys = config.SigningKeys
                }, out SecurityToken validatedToken);
            }
            catch (Exception)
            {
                throw;
            }
            return true;
        }
    }
}