namespace Tartarus.Shared
{
    public class Constant
    {
        // Pagination
        public const string DEFAULT_VULNERABILITY_PAGE_SIZE = "10";
        public const string DEFAULT_VULNERABILITY_PAGE_OFFSET = "1";
        public const string DEFAULT_MITIGATION_PAGE_SIZE = "10";
        public const string DEFAULT_MITIGATION_PAGE_OFFSET = "0";
        public const string DEFAULT_MITIGATION_ARCHIVE_PAGE_SIZE = "10";
        public const string DEFAULT_MITIGATION_ARCHIVE_PAGE_OFFSET = "0";

        //Version
        public const string VERSION_PATH = "v1";

        // Function Names
        public const string VULNERABILITY = "Vulnerability";
        public const string VULNERABILITIES = "Vulnerabilities";
        public const string MITIGATION = "Mitigation";
        public const string MITIGATIONS = "Mitigations";
        public const string MITIGATION_ARCHIVE = "MitigationArchive";
        public const string DEFENDER = "Defender";
        public const string CISA_GET_TIMER = "CisaGetTimer";
        public const string CISA_SYNC_TIMER = "CisaSyncTimer";
        public const string CISA = "Cisa";
        public const string DURABLE = "Durable";
        public const string PRODUCER = "Producer";
        public const string CONSUMER = "Consumer";
        public const string CALCULATOR = "Calulator";
        public const string MISP_TIMER = "MispTimer";
        public const string MISP = "Misp";
        public const string MISP_DELETE = "MispDelete";

        // Routes
        public const string VULNERABILITY_ROUTE = VERSION_PATH + "/" + TYPE_CUSTOMERS + "/" + TYPE_VULNERABILITY + "/{vid}";
        public const string VULNERABILITIES_ROUTE = VERSION_PATH + "/" + TYPE_CUSTOMERS + "/{id?}/" + TYPE_VULNERABILITIES + "/";
        public const string MITIGATION_ROUTE = VERSION_PATH + "/" + TYPE_CUSTOMERS + "/" + TYPE_MITIGATION + "/{mid}";
        public const string MITIGATIONS_ROUTE = VERSION_PATH + "/" + TYPE_CUSTOMERS + "/{id?}/" + TYPE_MITIGATIONS + "/";
        public const string MITIGATION_ACTION_ROUTE = $"{VERSION_PATH}/{TYPE_CUSTOMERS}/{{id?}}/{TYPE_MITIGATIONS}/{{mitigationId}}/actions";
        public const string MITIGATION_ARCHIVE_ROUTE = VERSION_PATH + "/" + TYPE_CUSTOMERS + "/{id?}/" + TYPE_MITIGATIONS + "/archives";
        public const string EXPOSURE_SCORE_ROUTE = VERSION_PATH + "/" + TYPE_CUSTOMERS + "/{id?}/" + TYPE_SCORE + "/";
        public const string CISA_ROUTE = VERSION_PATH + "/" + TYPE_CISA + "/" + TYPE_VULNERABILITY + "/{cveid?}";
        public const string CISA_PUT_ROUTE = VERSION_PATH + "/" + TYPE_CISA + "/" + TYPE_VULNERABILITY + "/";
        public const string PRODUCER_ROUTE = VERSION_PATH + "/" + PRODUCER + "/{id}";
        public const string CONSUMER_ROUTE = VERSION_PATH + "/" + TYPE_CVE + "/{id}";
        public const string MISP_ROUTE = VERSION_PATH + "/" + TYPE_MISP + "/" + TYPE_VULNERABILITY + "/{cveid?}";
        public const string MISP_PUT_ROUTE = VERSION_PATH + "/" + TYPE_MISP + "/" + TYPE_VULNERABILITY + "/";

        // Types
        public const string TYPE_CUSTOMERS = "customers";
        public const string TYPE_VULNERABILITY = "vulnerability";
        public const string TYPE_VULNERABILITIES = "vulnerabilities";
        public const string TYPE_DEFENDER_VULNERABILITY = "defender_vulnerabilities";
        public const string TYPE_MITIGATION = "mitigation";
        public const string TYPE_MITIGATIONS = "mitigations";
        public const string TYPE_SCORE = "score";
        public const string TYPE_CISA = "cisa";
        public const string TYPE_CVE = "cve";
        public const string TYPE_MISP = "misp";


        // Stored Procedures
        // Records Exists SPs
        public const string ASSET_RECORD_EXISTS = "dbo.spAssetRecordExists";
        public const string VULNERABILITY_RECORD_EXISTS = "dbo.spVulnerabilityRecordExists";
        public const string MITIGATION_RECORD_EXISTS = "dbo.spMitigationRecordExists";
        public const string CISA_VULNERABILITY_RECORD_EXISTS = "dbo.spCisaVulnerabilityRecordExists";

        // Vulnerability SPs
        public const string INSERT_VULNERABILITY_RECORD = "dbo.spInsertNewVulnerabilityRecord";
        public const string DELETE_FROM_VULNERABILITY_TABLE = "dbo.spDeleteFromVulnerabilityTable";
        public const string UPDATE_VULNERABILITY_INSERT_MITIGATION = "dbo.spUpdateVulnerabilityInsertMitigation";
        public const string MANAGE_FOUND_ACTIVE_MITIGATION = "dbo.spManageFoundActiveMitigation";
        public const string GET_VULNERABILITY = "dbo.spGetVulnerability";

        // Cisa Vulnerability SPs
        public const string DELETE_CISA_VULNERABILITIES = "spDeleteCisaVulnerabilityRecords";
        public const string DELETE_CISA_VULNERABILITY = "spDeleteCisaVulnerabilityRecord";
        public const string CREATE_CISA_VULNERABILITY_RECORD = "spCreateCisaVulnerabilityRecord";
        public const string GET_CISA_VULNERABILITY_RECORD = "spGetCisaVulnerabilityRecord";
        public const string GET_CISA_VULNERABILITY_RECORDS = "spGetCisaVulnerabilityRecords";
        public const string UPDATE_CISA_VULNERABILITY_RECORD = "spUpdateCisaVulnerabilityRecord";

        // Misp Vulnerability SPs
        public const string DELETE_MISP_VULNERABILITIES = "spDeleteMispVulnerabilityRecords";
        public const string DELETE_MISP_VULNERABILITY = "spDeleteMispVulnerabilityRecord";
        public const string CREATE_MISP_VULNERABILITY_RECORD = "spCreateMispVulnerabilityRecord";

        // Mitigation SPs
        public const string INSERT_MITIGATION_RECORD = "dbo.spInsertNewMitigationRecord";
        public const string UPDATE_MITIGATION = "dbo.spUpdateMitigation";
        public const string INSERT_NEW_MITIGATOIN_ARCHIVE_RECORD = "dbo.spInsertNewMitigationArchiveRecord";
        public const string GET_MITIGATION = "dbo.spGetMitigation";


        // Vulnerability Paging SPs
        public const string GET_NEXT_PAGE_VULNERABILITY = "dbo.spGetNextPageVulnerability";
        public const string GET_PREVIOUS_PAGE_VULNERABILITY = "dbo.spGetPrevPageVulnerability";
        public const string GET_NEXT_PAGE_VULNERABILITY_COUNT = "dbo.spGetNextPageVulnerabilityCount";
        public const string GET_PREVIOUS_PAGE_VULNERABILITY_COUNT = "dbo.spGetPrevPageVulnerabilityCount";
        public const string GET_OFFSET_PAGE_VULNERABILITY = "dbo.spGetOffsetPageVulnerability";

        // CISA Vulnerability Paging SPs
        public const string GET_NEXT_PAGE_CISA_VULNERABILITY = "dbo.spGetNextPageCisaVulnerability";
        public const string GET_PREVIOUS_PAGE_CISA_VULNERABILITY = "dbo.spGetPrevPageCisaVulnerability";
        public const string GET_NEXT_PAGE_CISA_VULNERABILITY_COUNT = "dbo.spGetNextPageCisaVulnerabilityCount";
        public const string GET_PREVIOUS_PAGE_CISA_VULNERABILITY_COUNT = "dbo.spGetPrevPageCisaVulnerabilityCount";
        public const string GET_OFFSET_PAGE_CISA_VULNERABILITY = "dbo.spGetOffsetPageCisaVulnerability";

        // MISP Vulnerability Paging SPs
        public const string GET_NEXT_PAGE_MISP_VULNERABILITY = "dbo.spGetNextPageMispVulnerability";
        public const string GET_PREVIOUS_PAGE_MISP_VULNERABILITY = "dbo.spGetPrevPageMispVulnerability";
        public const string GET_NEXT_PAGE_MISP_VULNERABILITY_COUNT = "dbo.spGetNextPageMispVulnerabilityCount";
        public const string GET_PREVIOUS_PAGE_MISP_VULNERABILITY_COUNT = "dbo.spGetPrevPageMispVulnerabilityCount";
        public const string GET_OFFSET_PAGE_MISP_VULNERABILITY = "dbo.spGetOffsetPageMispVulnerability";

        // Mitigation Paging SPs
        public const string GET_NEXT_PAGE_MITIGATION = "dbo.spGetNextPageMitigation";
        public const string GET_PREVIOUS_PAGE_MITIGATION = "dbo.spGetPrevPageMitigation";
        public const string GET_NEXT_PAGE_MITIGATION_COUNT = "dbo.spGetNextPageMitigationCount";
        public const string GET_PREVIOUS_PAGE_MITIGATION_COUNT = "dbo.spGetPrevPageMitigationCount";
        public const string GET_OFFSET_PAGE_MITIGATION = "dbo.spGetOffsetPageMitigation";

        // Mitigation Archive Paging SPs
        public const string GET_NEXT_PAGE_MITIGATION_ARCHIVE = "dbo.spGetNextPageMitigationArchive";
        public const string GET_PREVIOUS_PAGE_MITIGATION_ARCHIVE = "dbo.spGetPrevPageMitigationArchive";
        public const string GET_NEXT_PAGE_MITIGATION_ARCHIVE_COUNT = "dbo.spGetNextPageMitigationArchiveCount";
        public const string GET_PREVIOUS_PAGE_MITIGATION_ARCHIVE_COUNT = "dbo.spGetPrevPageMitigationAchiveCount";
        public const string GET_OFFSET_PAGE_MITIGATION_ARCHIVE = "dbo.spGetOffsetPageMitigationArchive";

        // Defender
        public const string DEVICE_SCORE = "Score";
        public const string GET_DEFENDER_SCORE_URI = "https://api.securitycenter.microsoft.com/api/configurationScore";
        public const string GET_VULNERABILITY_URL = "https://api.securitycenter.microsoft.com/api/vulnerabilities/machinesVulnerabilities";
        public const string GET_MACHINE_URL = "https://api.securitycenter.microsoft.com/api/machines";
        public const string DEFENDER_AUTHORITY = "https://login.microsoftonline.com";
        public const string DEFENDER_AUDIENCE = "https://api.securitycenter.microsoft.com";

        // CISA HOME
        public const string CISA_HOME = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json";

        // MISP HOME
        public const string MISP_HOME = "https://feeds.ecrimelabs.net/data/metasploit-cve";

        // Mitre HOME
        public const string MITRE_HOME = "https://cveawg.mitre.org/api/cve/";

        // NIST HOME
        public const string NIST_HOME = "https://services.nvd.nist.gov/rest/json/cves/2.0?cveId=";

        // CVSS HOME
        public const string CVSS_HOME = "https://www.first.org/cvss/calculator/3.1#";

        // RedHat HOME
        public const string REDHAT_HOME = "https://access.redhat.com/hydra/rest/securitydata/cvrf.json";

        // Circl HOME
        public const string CIRCL_HOME = "https://cve.circl.lu/api/cve/";

        // Cvss Score Route
        public const string SCORE_ROUTE = VERSION_PATH + "/" + TYPE_SCORE + "/{vector}";
    }
}