﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using Dapper;


namespace tartarus.Common.Extensions
{
    public static class SqlConnectionExtension
    {
        public static Task<IEnumerable<dynamic>> ExecuteSqlCommandAsync(this SqlConnection sqlConnection,
            string sqlCommand,
            object parameters,
            CancellationToken cancellationToken)

        => sqlConnection.QueryAsync(command: new CommandDefinition(
                commandText: sqlCommand,
                commandType: System.Data.CommandType.Text,
                parameters: parameters,
                cancellationToken: cancellationToken));

    }
}

