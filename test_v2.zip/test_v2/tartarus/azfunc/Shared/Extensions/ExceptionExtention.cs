﻿using System;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Tartarus.Shared;

namespace tartarus.Shared.Extensions
{
    public static class ExceptionExtention
    {
        public static IActionResult ToActionResult(this Exception exception)
           => exception is ValidationException ? new BadRequestResult() :
              exception is SecurityTokenException ? new UnauthorizedResult() : new StatusCodeResult(statusCode: StatusCodes.Status500InternalServerError);


    }
}

