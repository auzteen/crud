﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using Tartarus.Shared;

namespace Tartarus.Misp.Model
{
    public class MispVulnerabilityData
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("attributes")]
        public Vulnerabilities attributes { get; set; }

        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public Links links { get; set; }

        [JsonIgnore]
        public int PageCount { get; set; }

        [JsonIgnore]
        public int TotalRecords { get; set; }
    }

    public class Vulnerabilities
    {
        public List<Vulnerability> mispVulnerabilityList { get; set; }
    }

    public class Vulnerability
    {
        public string cveID { get; set; }
    }

    public class MispData
    {
        public string CVEID { get; set; }
        public string title { get; set; }
        public string catalogVersion { get; set; }
        public string dateReleased { get; set; }
        public int count { get; set; }
        public List<Vulnerability> mispVulnerabilityList { get; set; }
    }
}