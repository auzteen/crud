﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using MModel = Tartarus.Misp.Model;
using VModel = Tartarus.Vulnerability.Model;
using System.Collections.Generic;
using Tartarus.Shared;
using System.Net.Http;

namespace Tartarus.Misp
{
    public interface IMispService
    {
        public List<MModel.MispVulnerabilityData> GetMispVulnerabilities();
        public void PutMispData(DataMessage<MModel.MispVulnerabilityData, string> messageData);
        public ObjectResult ManageGetRequest(HttpRequest req);
        public ObjectResult ManagePostRequest(HttpRequest req);
        public void ManagePostHttpRequestMessage(HttpRequestMessage request);
        public ObjectResult ManageDeleteRequest(string cveid);
    }
}