﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Tartarus.Misp.Model;
using Tartarus.Shared;
using MModel = Tartarus.Misp.Model;

namespace Tartarus.Misp
{
    public class MispService : IMispService
    {
        private readonly ILogger<MispService> _logger;
        private readonly IDatabaseService _dbservice;

        public MispService(ILogger<MispService> log, IDatabaseService dbservice)
        {
            _logger = log;
            _dbservice = dbservice;
        }

        // Get Metasploit Data
        public List<MModel.MispVulnerabilityData> GetMispVulnerabilities()
        {
            // Client
            HttpClient client = new HttpClient();

            // Get Url
            var getUrl = Constant.MISP_HOME;

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, getUrl);

            // Response
            var response = new HttpResponseMessage();
            try
            {
                response = client.SendAsync(request).Result;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogInformation(response.ReasonPhrase, response.StatusCode);
                throw new MISPDataCollectionException("Couldn't fetch updated Known Exploited Vulnerabilities from Metasploit");
            }

            // Content
            var content = response.Content.ReadAsStringAsync().Result;

            var arryList = content.Split('\n');
            List<MispVulnerabilityData> misVulnerability = new List<MispVulnerabilityData>();

            foreach (var arry in arryList)
            {
                misVulnerability.Add(new MispVulnerabilityData
                {
                    Id = Guid.NewGuid().ToString(),
                    attributes = new Vulnerabilities
                    {
                        mispVulnerabilityList = new List<MModel.Vulnerability> {
                        new MModel.Vulnerability{ cveID= arry }
                        }
                    }
                });
            }

            // Parse
            return misVulnerability;
        }

        public void PutMispData(DataMessage<MModel.MispVulnerabilityData, string> messageData)
        {
            // Client
            HttpClient client = new HttpClient();

            // Url
            var putUrl = Environment.GetEnvironmentVariable("TARTARUS_BASE_URI") + Constant.MISP_PUT_ROUTE;

            // Request
            var request = new HttpRequestMessage(HttpMethod.Put, putUrl);
            request.Content = new StringContent(JsonSerializer.Serialize<DataMessage<MModel.MispVulnerabilityData, string>>(messageData), Encoding.UTF8, "application/json");

            // Response
            var response = new HttpResponseMessage();
            try
            {
                //response = client.Send(request);

                /*
                 *
                 *
                 *  This uses a new method to do the put for us rather than using the API
                 *
                 *
                 */
                ManagePostHttpRequestMessage(request);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            if (!response.IsSuccessStatusCode)
            {
                throw new MISPDataCollectionException("Failed to post metasploit data to the database.");
            }
        }

        public void ManagePostHttpRequestMessage(HttpRequestMessage request)
        {
            var content = request.Content.ReadAsStringAsync().Result;
            var dataMessage = System.Text.Json.JsonSerializer.Deserialize<DataMessage<MModel.MispVulnerabilityData, List<ExpandoObject>>>(content);

            // Delete Vulnerabilities
            DeleteRecordsFromMispVulnerabilityTable();

            // Create Vulnerabilities
            foreach (var message in dataMessage.data)
            {
                foreach (var vulnerability in message.attributes.mispVulnerabilityList)
                {
                    InsertVulnerability(vulnerability);
                }
            }
        }

        public ObjectResult ManageGetRequest(HttpRequest req)
        {
            // Company Short
            var companyShortName = req.Headers["X-Company-Short"];

            // Response Data
            List<MModel.MispVulnerabilityData> mispVulnerabilityDataList = new List<MModel.MispVulnerabilityData>();
            Dictionary<string, int> counts = new Dictionary<string, int>();

            //Pagination
            string pageLimit = req.Query["page[limit]"];
            string pageOffset = req.Query["page[offset]"];
            string url = req.Path;

            pageLimit = pageLimit == null ? Constant.DEFAULT_VULNERABILITY_PAGE_SIZE : pageLimit;
            pageOffset = pageOffset == null ? Constant.DEFAULT_VULNERABILITY_PAGE_OFFSET : pageOffset;
            int calculatedOffset = (Int32.Parse(pageOffset) - 1) * (Int32.Parse(pageLimit));

            GetMispVulnerabilityPageMetaData(Int32.Parse(pageLimit), out int totalRecords, out int totalPageCount);

            // SQL
            SqlConnection conn = _dbservice.GetSqlConnection();

            SqlCommand comm = new SqlCommand(Constant.GET_OFFSET_PAGE_MISP_VULNERABILITY, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@PageLimit", SqlDbType.Int));
            comm.Parameters["@PageLimit"].Direction = ParameterDirection.Input;
            comm.Parameters["@PageLimit"].Value = Int32.Parse(pageLimit);

            comm.Parameters.Add(new SqlParameter("@PageOffset", SqlDbType.Int));
            comm.Parameters["@PageOffset"].Direction = ParameterDirection.Input;
            comm.Parameters["@PageOffset"].Value = calculatedOffset;

            // Containers
            MModel.Vulnerabilities mispVulnerabilities = new MModel.Vulnerabilities();
            List<MModel.Vulnerability> mispVulnerabilityList = new List<MModel.Vulnerability>();

            bool emptyMispVulnerability = true;
            MModel.MispVulnerabilityData mispVulnerabilityData;

            // Go
            try
            {
                conn.Open();
                using (SqlDataReader reader = comm.ExecuteReader())
                {
                    if (!reader.HasRows)
                        throw new NoRecordsFoundException("No Metasploit vulnerabilities found.");
                    else
                    {
                        mispVulnerabilityData = CreateNewMispVulnerabilityDataObject();
                        mispVulnerabilityData.PageCount = totalPageCount;
                        mispVulnerabilityData.TotalRecords = totalRecords;
                    }
                    while (reader.Read())
                    {
                        if (!emptyMispVulnerability)
                        {
                            mispVulnerabilityData.attributes = mispVulnerabilities;
                            mispVulnerabilityData.PageCount = totalPageCount;
                            mispVulnerabilityData.TotalRecords = totalRecords;
                            mispVulnerabilityDataList.Add(mispVulnerabilityData);
                            mispVulnerabilityData = CreateNewMispVulnerabilityDataObject();
                        }
                        mispVulnerabilities = new MModel.Vulnerabilities();
                        mispVulnerabilityList = new List<MModel.Vulnerability>();

                        // Vulerability
                        MModel.Vulnerability mispVulnerability = new MModel.Vulnerability();

                        // Load
                        for (var i = 0; i < reader.FieldCount; i++)
                        {
                            var fieldName = reader.GetName(i);

                            switch (fieldName)
                            {
                                case "CVEID":
                                    mispVulnerability.cveID = (string)reader[i];
                                    break;
                                default:
                                    break;
                            }
                        }

                        // Append
                        mispVulnerabilityList.Add(mispVulnerability);
                        mispVulnerabilities.mispVulnerabilityList = mispVulnerabilityList;
                        emptyMispVulnerability = false;

                    }
                    // Append
                    mispVulnerabilityData.attributes = mispVulnerabilities;
                    mispVulnerabilityDataList.Add(mispVulnerabilityData);
                }
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogInformation(e.Message + "No Metasploit records found.");
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }

            // Response
            DataMessage<MModel.MispVulnerabilityData, Dictionary<string, int>> responseMessage = new DataMessage<MModel.MispVulnerabilityData, Dictionary<string, int>>();

            // Vulnerability List
            responseMessage.data = mispVulnerabilityDataList;

            // Links
            Links links = BuildVulnerabilityLinks(req, Int32.Parse(pageLimit), Int32.Parse(pageOffset), responseMessage.data[0].PageCount, responseMessage.data[0].TotalRecords);
            responseMessage.links = links;

            // Counts
            counts["Page Count"] = responseMessage.data[0].PageCount;
            counts["Total Records"] = responseMessage.data[0].TotalRecords;

            // Results
            Meta<Dictionary<string, int>> meta = new Meta<Dictionary<string, int>>();
            responseMessage.meta = meta;
            responseMessage.meta.result = new Dictionary<string, int>();
            responseMessage.meta.result = counts;

            return Common.ReturnResponse(JsonSerializer.Serialize(responseMessage, new JsonSerializerOptions { WriteIndented = true }), 200, false);
        }

        public ObjectResult ManagePostRequest(HttpRequest req)
        {
            // Response
            ExpandoObject response = new ExpandoObject();

            // Read
            StreamReader streamReader = new StreamReader(req.Body);

            // Request
            var responseBody = streamReader.ReadToEnd();
            var dataMessage = System.Text.Json.JsonSerializer.Deserialize<DataMessage<MModel.MispVulnerabilityData, List<ExpandoObject>>>(responseBody);

            // Delete Vulnerabilities
            DeleteRecordsFromMispVulnerabilityTable();

            // Create Vulnerabilities
            foreach (var message in dataMessage.data)
            {
                foreach (var vulnerability in message.attributes.mispVulnerabilityList)
                {
                    InsertVulnerability(vulnerability);
                }
            }
            return new ObjectResult("Success");
        }

        public ObjectResult ManageDeleteRequest(string cveid)
        {

            var conn = _dbservice.GetSqlConnection();
            SqlCommand comm = new SqlCommand(Constant.DELETE_MISP_VULNERABILITY, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@CVEID", SqlDbType.NVarChar, 20));
            comm.Parameters["@CVEID"].Direction = ParameterDirection.Input;
            comm.Parameters["@CVEID"].Value = cveid;

            comm.Parameters.Add(new SqlParameter("@Msg", SqlDbType.NVarChar, 500));
            comm.Parameters["@Msg"].Direction = ParameterDirection.Output;

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }

            return new ObjectResult(JsonSerializer.Serialize($"Record with cvied, {cveid}, deleted.", new JsonSerializerOptions { WriteIndented = true }));
        }

        public void DeleteRecordsFromMispVulnerabilityTable()
        {
            var conn = _dbservice.GetSqlConnection();
            SqlCommand comm = new SqlCommand(Constant.DELETE_MISP_VULNERABILITIES, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@Msg", SqlDbType.NVarChar, 500));
            comm.Parameters["@Msg"].Direction = ParameterDirection.Output;

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public void InsertVulnerability(MModel.Vulnerability vulnerability)
        {
            var conn = _dbservice.GetSqlConnection();
            SqlCommand comm = new SqlCommand(Constant.CREATE_MISP_VULNERABILITY_RECORD, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@CVEID", SqlDbType.NVarChar, 20));
            comm.Parameters["@CVEID"].Direction = ParameterDirection.Input;
            comm.Parameters["@CVEID"].Value = vulnerability.cveID;

            comm.Parameters.Add(new SqlParameter("@Msg", SqlDbType.NVarChar, 500));
            comm.Parameters["@Msg"].Direction = ParameterDirection.Output;

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        private MModel.MispVulnerabilityData CreateNewMispVulnerabilityDataObject()
        {
            MModel.MispVulnerabilityData mispVulnerabilityData = new MModel.MispVulnerabilityData();
            mispVulnerabilityData.Id = Guid.NewGuid().ToString();
            return mispVulnerabilityData;
        }

        private void GetMispVulnerabilityPageMetaData(int pageSize, out int totalRecords, out int totalPageCount)
        {
            string sqlQuery = $"SELECT COUNT(*) FROM vwMispVulnerability";
            totalRecords = _dbservice.GetScalarValueFromQuery(sqlQuery);
            if (pageSize == 0)
                totalPageCount = 1;
            if ((totalRecords % pageSize) == 0)
                totalPageCount = (totalRecords / pageSize);
            else
                totalPageCount = ((totalRecords / pageSize) + 1);
        }

        private Links BuildVulnerabilityLinks(HttpRequest req, int pageLimit, int pageOffset, int pageCount, int totalRecords)
        {
            string url = req.Path;
            string displayUrl = req.GetDisplayUrl();
            string[] urlArray = displayUrl.Split(Constant.VERSION_PATH);

            Links links = new Links();
            links.self = $"/{Constant.VERSION_PATH}{urlArray[1]}";
            links.first = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]=1" : null;
            links.prev = pageOffset > 1 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset - 1}" : null;
            links.next = pageOffset < pageCount ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset + 1}" : null;
            links.last = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageCount}" : null;

            return links;
        }



    }

}