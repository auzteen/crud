using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Tartarus.Shared;
using System.Data.SqlClient;

namespace Tartarus.Misp
{
    public class Misp
    {
        private readonly ILogger<Misp> _logger;
        private readonly IMispService _mService;

        public Misp(ILogger<Misp> log, IMispService mService)
        {
            _logger = log;
            _mService = mService;
        }
        [FunctionName(Constant.MISP)]
        public async Task<IActionResult> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", "delete", Route = Constant.MISP_ROUTE)] HttpRequest req, string cveid)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string companyShortName = req.Headers["X-Company-Short"];

            string token = req.Headers["Authorization"];
            if (token == null)
                throw new UnauthorizedAccessException("Unauthorized access");
            else
                await Task.Run(() => Common.ValidateBearertokenAsync(token));

            try
            {
                switch (req.Method)
                {
                    case "GET":
                        return await Task.Run(() => _mService.ManageGetRequest(req));
                    case "POST":
                        return await Task.Run(() => _mService.ManagePostRequest(req));
                    case "DELETE":
                        return await Task.Run(() => _mService.ManageDeleteRequest(cveid));
                    default:
                        return new ObjectResult("Alabama, we have a problem");
                }
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogInformation(e.Message);
                return Common.ReturnResponse(e.Message, 200, true);
            }
            catch (System.Text.Json.JsonException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse("Invalid JSON request", "400");
            }
            catch (BadRequestException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "400");
            }
            catch (InvalidTokenException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "401");
            }
            catch (UnauthorizedAccessException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "401");
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "500");
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "500");
            }
        }
    }
}
