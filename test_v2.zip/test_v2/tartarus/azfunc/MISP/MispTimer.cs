﻿using System;
using System.Text.Json;
using System.Collections.Generic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Tartarus.Misp;
using Tartarus.Shared;
using MModel = Tartarus.Misp.Model;
using VModel = Tartarus.Vulnerability.Model;
using Tartarus.Cisa.Model;


namespace Tartarus.MISP
{
    public class MispTimer
    {

        private readonly ILogger<MispTimer> _logger;
        private readonly IMispService _mService;

        public MispTimer(ILogger<MispTimer> log, IMispService mService)
        {
            _logger = log;
            _mService = mService;
        }

        [FunctionName(Constant.MISP_TIMER)]
        public void Run([TimerTrigger("0 0 * * *")] TimerInfo myTimer, ILogger log)
        {
            _logger.LogInformation($"Metasploit Timer Function Started: {DateTime.Now}");

            // Data Message
            DataMessage<MModel.MispVulnerabilityData, string> messageData = new DataMessage<MModel.MispVulnerabilityData, string>();

            // Metasploit Vulnerabilities
            List<MModel.MispVulnerabilityData> mispData = _mService.GetMispVulnerabilities();

            // Assemble Message
            messageData.data = mispData;

            // Post Message
            _mService.PutMispData(messageData);
        }
    }
}