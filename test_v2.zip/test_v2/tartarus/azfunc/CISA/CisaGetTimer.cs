using System;
using System.Collections.Generic;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Tartarus.Cisa;
using Tartarus.Shared;
using CModel = Tartarus.Cisa.Model;
using VModel = Tartarus.Vulnerability.Model;

namespace Tartartus.Cisa
{
    public class CisaTimer
    {
        private readonly ILogger<CisaTimer> _logger;
        private readonly ICisaService _cService;

        public CisaTimer(ILogger<CisaTimer> log, ICisaService cService)
        {
            _logger = log;
            _cService = cService;
        }

        [FunctionName(Constant.CISA_GET_TIMER)]
        public void Run([TimerTrigger("0 0 * * *")] TimerInfo myTimer, ILogger log)
        {
            _logger.LogInformation($"Cisa Timer Function Started: {DateTime.Now}");

            // Data Message
            DataMessage<CModel.CisaData, string> messageData = new DataMessage<CModel.CisaData, string>();

            // Cisa Vulnerabilities
            CModel.CisaData cisaData = _cService.GetCisaVulnerabilities();

            // Assemble Message
            messageData.data = new List<CModel.CisaData>();
            messageData.data.Add(cisaData);

            // Post Message
            _cService.PutCisaData(messageData);
        }
    }
}
