using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using CModel = Tartarus.Cisa.Model;
using VModel = Tartarus.Vulnerability.Model;
using System.Collections.Generic;
using Tartarus.Shared;
using System.Net.Http;

namespace Tartarus.Cisa
{
    public interface ICisaService
    {
        public CModel.CisaData GetCisaVulnerabilities();
        public void PutCisaData(DataMessage<CModel.CisaData, string> messageData);
        public ObjectResult ManageGetRequest(HttpRequest req);
        public ObjectResult ManagePutRequest(HttpRequest req);
        public void ManagePutHttpRequestMessage(HttpRequestMessage request);
        public ObjectResult ManageDeleteRequest(string cveid);
        public void SyncCisa();
    }
}