using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Linq;
using Tartarus.Shared;
using CModel = Tartarus.Cisa.Model;
using Dapper;

namespace Tartarus.Cisa
{
    public class CisaService : ICisaService
    {
        private readonly ILogger<CisaService> _logger;
        private readonly IDatabaseService _dbservice;

        public CisaService(ILogger<CisaService> log, IDatabaseService dbservice)
        {
            _logger = log;
            _dbservice = dbservice;
        }

        // Get Cisa Data
        public CModel.CisaData GetCisaVulnerabilities()
        {
            // Client
            HttpClient client = new HttpClient();

            // Get Url
            var getUrl = Constant.CISA_HOME;

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, getUrl);

            // Response
            var response = new HttpResponseMessage();
            try
            {
                response = client.SendAsync(request).Result;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogInformation(response.ReasonPhrase, response.StatusCode);
                throw new CISADataCollectionException("Couldn't fetch updated Known Expointed Vulnerabilities from CISA");
            }

            // Content
            var content = response.Content.ReadAsStreamAsync().Result;

            // Parse
            return JsonSerializer.Deserialize<CModel.CisaData>(content);
        }
        public void PutCisaData(DataMessage<CModel.CisaData, string> messageData)
        {
            // Client
            HttpClient client = new HttpClient();

            // Url
            var putUrl = Environment.GetEnvironmentVariable("TARTARUS_BASE_URI") + Constant.CISA_PUT_ROUTE;

            // Request
            var request = new HttpRequestMessage(HttpMethod.Put, putUrl);
            request.Content = new StringContent(JsonSerializer.Serialize<DataMessage<CModel.CisaData, string>>(messageData), Encoding.UTF8, "application/json");

            // Response
            var response = new HttpResponseMessage();

            try
            {
                //response = client.Send(request);

                /*
                 *
                 *
                 *  This uses a new method to do the put for us rather than using the API
                 *
                 *
                 */
                ManagePutHttpRequestMessage(request);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            if (!response.IsSuccessStatusCode)
            {
                throw new CISADataCollectionException("Failed to post cisa data to the database.");
            }
        }

        public void ManagePutHttpRequestMessage(HttpRequestMessage request)
        {
            var content = request.Content.ReadAsStringAsync().Result;
            var dataMessage = System.Text.Json.JsonSerializer.Deserialize<DataMessage<CModel.CisaData, List<ExpandoObject>>>(content);

            // Create Vulnerabilities
            foreach (var message in dataMessage.data)
            {
                foreach (var vulnerability in message.vulnerabilities)
                {
                    if (CisaVulnerabilityRecordExists(vulnerability))
                    {
                        if (CisaRecordNeedsUpdating(vulnerability))
                        {
                            UpdateVulnerability(vulnerability);
                        }
                    }
                    else
                    {
                        InsertVulnerability(vulnerability);
                    }
                }
            }
        }

        public ObjectResult ManageGetRequest(HttpRequest req)
        {
            // Company Short
            var companyShortName = req.Headers["X-Company-Short"];

            // Response Data
            List<CModel.CisaVulnerabilityData> cisaVulnerabilityDataList = new List<CModel.CisaVulnerabilityData>();
            Dictionary<string, int> counts = new Dictionary<string, int>();

            //Pagination
            string pageLimit = req.Query["page[limit]"];
            string pageOffset = req.Query["page[offset]"];
            string url = req.Path;

            pageLimit = pageLimit == null ? Constant.DEFAULT_VULNERABILITY_PAGE_SIZE : pageLimit;
            pageOffset = pageOffset == null ? Constant.DEFAULT_VULNERABILITY_PAGE_OFFSET : pageOffset;
            int calculatedOffset = (Int32.Parse(pageOffset) - 1) * (Int32.Parse(pageLimit));

            GetCisaVulnerabilityPageMetaData(Int32.Parse(pageLimit), out int totalRecords, out int totalPageCount);

            // SQL
            SqlConnection conn = _dbservice.GetSqlConnection();

            SqlCommand comm = new SqlCommand(Constant.GET_OFFSET_PAGE_CISA_VULNERABILITY, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@PageLimit", SqlDbType.Int));
            comm.Parameters["@PageLimit"].Direction = ParameterDirection.Input;
            comm.Parameters["@PageLimit"].Value = Int32.Parse(pageLimit);

            comm.Parameters.Add(new SqlParameter("@PageOffset", SqlDbType.Int));
            comm.Parameters["@PageOffset"].Direction = ParameterDirection.Input;
            comm.Parameters["@PageOffset"].Value = calculatedOffset;

            // Containers
            CModel.Vulnerabilities cisaVulnerabilities = new CModel.Vulnerabilities();
            List<CModel.Vulnerability> cisaVulnerabilityList = new List<CModel.Vulnerability>();

            bool emptyCisaVulnerability = true;
            CModel.CisaVulnerabilityData cisaVulnerabilityData;

            // Go
            try
            {
                conn.Open();
                using (SqlDataReader reader = comm.ExecuteReader())
                {
                    if (!reader.HasRows)
                        throw new NoRecordsFoundException("No Cisa vulnerabilities found.");
                    else
                    {
                        cisaVulnerabilityData = CreateNewCisaVulnerabilityDataObject();
                        cisaVulnerabilityData.PageCount = totalPageCount;
                        cisaVulnerabilityData.TotalRecords = totalRecords;
                    }
                    while (reader.Read())
                    {
                        if (!emptyCisaVulnerability)
                        {
                            cisaVulnerabilityData.attributes = cisaVulnerabilities;
                            cisaVulnerabilityData.PageCount = totalPageCount;
                            cisaVulnerabilityData.TotalRecords = totalRecords;
                            cisaVulnerabilityDataList.Add(cisaVulnerabilityData);
                            cisaVulnerabilityData = CreateNewCisaVulnerabilityDataObject();
                        }
                        cisaVulnerabilities = new CModel.Vulnerabilities();
                        cisaVulnerabilityList = new List<CModel.Vulnerability>();

                        // Vulerability
                        CModel.Vulnerability cisaVulnerability = new CModel.Vulnerability();

                        // Load
                        for (var i = 0; i < reader.FieldCount; i++)
                        {
                            var fieldName = reader.GetName(i);

                            switch (fieldName)
                            {
                                case "CVEID":
                                    cisaVulnerability.cveID = (string)reader[i];
                                    break;
                                case "VendorProject":
                                    cisaVulnerability.vendorProject = (string)reader[i];
                                    break;
                                case "Product":
                                    cisaVulnerability.product = (string)reader[i];
                                    break;
                                case "VulnerabilityName":
                                    cisaVulnerability.vulnerabilityName = (string)reader[i];
                                    break;
                                case "DateAdded":
                                    cisaVulnerability.dateAdded = (DateTime)reader[i];
                                    break;
                                case "ShortDescription":
                                    cisaVulnerability.shortDescription = (string)reader[i];
                                    break;
                                case "RequiredAction":
                                    cisaVulnerability.requiredAction = (string)reader[i];
                                    break;
                                case "DueDate":
                                    cisaVulnerability.dueDate = (DateTime)reader[i];
                                    break;
                                case "Notes":
                                    cisaVulnerability.notes = (string)reader[i];
                                    break;
                                default:
                                    break;
                            }
                        }

                        // Append
                        cisaVulnerabilityList.Add(cisaVulnerability);
                        cisaVulnerabilities.cisaVulnerabilityList = cisaVulnerabilityList;
                        emptyCisaVulnerability = false;

                    }
                    // Append
                    cisaVulnerabilityData.attributes = cisaVulnerabilities;
                    cisaVulnerabilityDataList.Add(cisaVulnerabilityData);
                }
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogInformation(e.Message + "No CISA records found.");
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }

            // Response
            DataMessage<CModel.CisaVulnerabilityData, Dictionary<string, int>> responseMessage = new DataMessage<CModel.CisaVulnerabilityData, Dictionary<string, int>>();

            // Vulnerability List
            responseMessage.data = cisaVulnerabilityDataList;

            // Links
            Links links = BuildVulnerabilityLinks(req, Int32.Parse(pageLimit), Int32.Parse(pageOffset), responseMessage.data[0].PageCount, responseMessage.data[0].TotalRecords);
            responseMessage.links = links;

            // Counts
            counts["Page Count"] = responseMessage.data[0].PageCount;
            counts["Total Records"] = responseMessage.data[0].TotalRecords;

            // Results
            Meta<Dictionary<string, int>> meta = new Meta<Dictionary<string, int>>();
            responseMessage.meta = meta;
            responseMessage.meta.result = new Dictionary<string, int>();
            responseMessage.meta.result = counts;

            return Common.ReturnResponse(JsonSerializer.Serialize(responseMessage, new JsonSerializerOptions { WriteIndented = true }), 200, false);
        }

        public ObjectResult ManagePutRequest(HttpRequest req)
        {
            // Response
            ExpandoObject response = new ExpandoObject();

            // Response Counts
            int cisaRecordsProcessed = 0;
            int cisaRecordsCreated = 0;
            int cisaRecordsUpdated = 0;

            // Lists
            List<CModel.Vulnerability> createdList = new List<CModel.Vulnerability>();
            List<CModel.Vulnerability> updatedList = new List<CModel.Vulnerability>();

            // Read
            StreamReader streamReader = new StreamReader(req.Body);

            // Request
            var responseBody = streamReader.ReadToEnd();
            var dataMessage = System.Text.Json.JsonSerializer.Deserialize<DataMessage<CModel.CisaData, List<ExpandoObject>>>(responseBody);

            // Create Vulnerabilities
            foreach (var message in dataMessage.data)
            {
                foreach (var vulnerability in message.vulnerabilities)
                {
                    cisaRecordsProcessed++;
                    if (CisaVulnerabilityRecordExists(vulnerability))
                    {
                        if (CisaRecordNeedsUpdating(vulnerability))
                        {
                            cisaRecordsUpdated++;
                            updatedList.Add(vulnerability);
                            UpdateVulnerability(vulnerability);
                        }
                    }
                    else
                    {
                        cisaRecordsCreated++;
                        createdList.Add(vulnerability);
                        InsertVulnerability(vulnerability);
                    }
                }
            }

            // Tally
            response.TryAdd("Total Count of Cisa Records Processed", cisaRecordsProcessed);
            response.TryAdd("Count of Cisa Records Updated", cisaRecordsUpdated);
            response.TryAdd("Count of Cisa Records Created", cisaRecordsCreated);
            response.TryAdd("List of Cisa Records Updated", updatedList);
            response.TryAdd("List of Cisa Records Created", createdList);

            // Build Response
            DataMessage<CModel.CisaVulnerabilityData, List<ExpandoObject>> responseMessage = new DataMessage<CModel.CisaVulnerabilityData, List<ExpandoObject>>();
            responseMessage.data = null;
            responseMessage.links = null;
            responseMessage.jsonApi = null;
            responseMessage.meta = new Meta<List<ExpandoObject>>();
            responseMessage.meta.result = new List<ExpandoObject>();
            responseMessage.meta.result.Add(response);

            return Common.ReturnResponse(JsonSerializer.Serialize(responseMessage, new JsonSerializerOptions { WriteIndented = true }), 202, false);
        }

        public ObjectResult ManageDeleteRequest(string cveid)
        {

            var conn = _dbservice.GetSqlConnection();
            SqlCommand comm = new SqlCommand(Constant.DELETE_CISA_VULNERABILITY, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@CVEID", SqlDbType.NVarChar, 20));
            comm.Parameters["@CVEID"].Direction = ParameterDirection.Input;
            comm.Parameters["@CVEID"].Value = cveid;

            comm.Parameters.Add(new SqlParameter("@Msg", SqlDbType.NVarChar, 500));
            comm.Parameters["@Msg"].Direction = ParameterDirection.Output;

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }

            return new ObjectResult(JsonSerializer.Serialize($"Record with cvied, {cveid}, deleted.", new JsonSerializerOptions { WriteIndented = true }));
        }

        public bool CisaVulnerabilityRecordExists(CModel.Vulnerability vulnerability)
        {
            var conn = _dbservice.GetSqlConnection();
            SqlCommand comm = new SqlCommand(Constant.CISA_VULNERABILITY_RECORD_EXISTS, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@CVEID", SqlDbType.NVarChar, 20));
            comm.Parameters["@CVEID"].Direction = ParameterDirection.Input;
            comm.Parameters["@CVEID"].Value = vulnerability.cveID;

            comm.Parameters.Add(new SqlParameter("@Msg", SqlDbType.NVarChar, 500));
            comm.Parameters["@Msg"].Direction = ParameterDirection.Output;

            comm.Parameters.Add(new SqlParameter("@RecordCount", SqlDbType.Int, 10));
            comm.Parameters["@RecordCount"].Direction = ParameterDirection.Output;

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }

            var count = Convert.ToInt32(comm.Parameters["@RecordCount"].Value);
            return count == 0 ? false : true;
        }

        public bool CisaRecordNeedsUpdating(CModel.Vulnerability vulnerability)
        {
            var conn = _dbservice.GetSqlConnection();

            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@CVEID", vulnerability.cveID);
            dynamicParameters.Add("@Msg", "");

            try
            {
                conn.Open();

                // Get
                var dbCisaEnnumerable = conn.Query<CModel.Vulnerability>(Constant.GET_CISA_VULNERABILITY_RECORD, dynamicParameters, commandType: CommandType.StoredProcedure);
                var dbCisa = dbCisaEnnumerable.FirstOrDefault<CModel.Vulnerability>();

                // Simple Compare (Do we really care what changed?)
                var dbCisaSerialized = JsonSerializer.Serialize<CModel.Vulnerability>(dbCisa);
                var vulnerabilitySerialized = JsonSerializer.Serialize<CModel.Vulnerability>(vulnerability);

                return dbCisaSerialized != vulnerabilitySerialized;
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public void UpdateVulnerability(CModel.Vulnerability vulnerability)
        {
            var conn = _dbservice.GetSqlConnection();
            SqlCommand comm = new SqlCommand(Constant.UPDATE_CISA_VULNERABILITY_RECORD, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@CVEID", SqlDbType.NVarChar, 20));
            comm.Parameters["@CVEID"].Direction = ParameterDirection.Input;
            comm.Parameters["@CVEID"].Value = vulnerability.cveID;

            comm.Parameters.Add(new SqlParameter("@vendorProject", SqlDbType.NVarChar, 50));
            comm.Parameters["@vendorProject"].Direction = ParameterDirection.Input;
            comm.Parameters["@vendorProject"].Value = vulnerability.vendorProject;

            comm.Parameters.Add(new SqlParameter("@product", SqlDbType.NVarChar, 50));
            comm.Parameters["@product"].Direction = ParameterDirection.Input;
            comm.Parameters["@product"].Value = vulnerability.product;

            comm.Parameters.Add(new SqlParameter("@vulnerabilityName", SqlDbType.NVarChar, 100));
            comm.Parameters["@vulnerabilityName"].Direction = ParameterDirection.Input;
            comm.Parameters["@vulnerabilityName"].Value = vulnerability.vulnerabilityName;

            comm.Parameters.Add(new SqlParameter("@dateAdded", SqlDbType.DateTime, 50));
            comm.Parameters["@dateAdded"].Direction = ParameterDirection.Input;
            comm.Parameters["@dateAdded"].Value = vulnerability.dateAdded;

            comm.Parameters.Add(new SqlParameter("@shortDescription", SqlDbType.NVarChar, 1000));
            comm.Parameters["@shortDescription"].Direction = ParameterDirection.Input;
            comm.Parameters["@shortDescription"].Value = vulnerability.shortDescription;

            comm.Parameters.Add(new SqlParameter("@requiredAction", SqlDbType.NVarChar, 500));
            comm.Parameters["@requiredAction"].Direction = ParameterDirection.Input;
            comm.Parameters["@requiredAction"].Value = vulnerability.requiredAction;

            comm.Parameters.Add(new SqlParameter("@dueDate", SqlDbType.DateTime, 50));
            comm.Parameters["@dueDate"].Direction = ParameterDirection.Input;
            comm.Parameters["@dueDate"].Value = vulnerability.dueDate;

            comm.Parameters.Add(new SqlParameter("@notes", SqlDbType.NVarChar, 4000));
            comm.Parameters["@notes"].Direction = ParameterDirection.Input;
            comm.Parameters["@notes"].Value = vulnerability.notes;

            comm.Parameters.Add(new SqlParameter("@Msg", SqlDbType.NVarChar, 500));
            comm.Parameters["@Msg"].Direction = ParameterDirection.Output;

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        public void InsertVulnerability(CModel.Vulnerability vulnerability)
        {
            var conn = _dbservice.GetSqlConnection();
            SqlCommand comm = new SqlCommand(Constant.CREATE_CISA_VULNERABILITY_RECORD, conn);
            comm.CommandType = CommandType.StoredProcedure;

            comm.Parameters.Add(new SqlParameter("@CVEID", SqlDbType.NVarChar, 20));
            comm.Parameters["@CVEID"].Direction = ParameterDirection.Input;
            comm.Parameters["@CVEID"].Value = vulnerability.cveID;

            comm.Parameters.Add(new SqlParameter("@vendorProject", SqlDbType.NVarChar, 50));
            comm.Parameters["@vendorProject"].Direction = ParameterDirection.Input;
            comm.Parameters["@vendorProject"].Value = vulnerability.vendorProject;

            comm.Parameters.Add(new SqlParameter("@product", SqlDbType.NVarChar, 50));
            comm.Parameters["@product"].Direction = ParameterDirection.Input;
            comm.Parameters["@product"].Value = vulnerability.product;

            comm.Parameters.Add(new SqlParameter("@vulnerabilityName", SqlDbType.NVarChar, 100));
            comm.Parameters["@vulnerabilityName"].Direction = ParameterDirection.Input;
            comm.Parameters["@vulnerabilityName"].Value = vulnerability.vulnerabilityName;

            comm.Parameters.Add(new SqlParameter("@dateAdded", SqlDbType.DateTime, 50));
            comm.Parameters["@dateAdded"].Direction = ParameterDirection.Input;
            comm.Parameters["@dateAdded"].Value = vulnerability.dateAdded;

            comm.Parameters.Add(new SqlParameter("@shortDescription", SqlDbType.NVarChar, 1000));
            comm.Parameters["@shortDescription"].Direction = ParameterDirection.Input;
            comm.Parameters["@shortDescription"].Value = vulnerability.shortDescription;

            comm.Parameters.Add(new SqlParameter("@requiredAction", SqlDbType.NVarChar, 500));
            comm.Parameters["@requiredAction"].Direction = ParameterDirection.Input;
            comm.Parameters["@requiredAction"].Value = vulnerability.requiredAction;

            comm.Parameters.Add(new SqlParameter("@dueDate", SqlDbType.DateTime, 50));
            comm.Parameters["@dueDate"].Direction = ParameterDirection.Input;
            comm.Parameters["@dueDate"].Value = vulnerability.dueDate;

            comm.Parameters.Add(new SqlParameter("@notes", SqlDbType.NVarChar, 4000));
            comm.Parameters["@notes"].Direction = ParameterDirection.Input;
            comm.Parameters["@notes"].Value = vulnerability.notes;

            comm.Parameters.Add(new SqlParameter("@Msg", SqlDbType.NVarChar, 500));
            comm.Parameters["@Msg"].Direction = ParameterDirection.Output;

            try
            {
                conn.Open();
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }
        }

        private CModel.CisaVulnerabilityData CreateNewCisaVulnerabilityDataObject()
        {
            CModel.CisaVulnerabilityData cisaVulnerabilityData = new CModel.CisaVulnerabilityData();
            cisaVulnerabilityData.Id = Guid.NewGuid().ToString();
            return cisaVulnerabilityData;
        }

        private void GetCisaVulnerabilityPageMetaData(int pageSize, out int totalRecords, out int totalPageCount)
        {
            string sqlQuery = $"SELECT COUNT(*) FROM vwCisaVulnerability";
            totalRecords = _dbservice.GetScalarValueFromQuery(sqlQuery);
            if (pageSize == 0)
                totalPageCount = 1;
            if ((totalRecords % pageSize) == 0)
                totalPageCount = (totalRecords / pageSize);
            else
                totalPageCount = ((totalRecords / pageSize) + 1);
        }

        private Links BuildVulnerabilityLinks(HttpRequest req, int pageLimit, int pageOffset, int pageCount, int totalRecords)
        {
            string url = req.Path;
            string displayUrl = req.GetDisplayUrl();
            string[] urlArray = displayUrl.Split(Constant.VERSION_PATH);

            Links links = new Links();
            links.self = $"/{Constant.VERSION_PATH}{urlArray[1]}";
            links.first = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]=1" : null;
            links.prev = pageOffset > 1 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset - 1}" : null;
            links.next = pageOffset < pageCount ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset + 1}" : null;
            links.last = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageCount}" : null;

            return links;
        }

        public void SyncCisa()
        {
            // DB Cisa
            var conn = _dbservice.GetSqlConnection();
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@Msg", "");
            var dbCisaEnnumerable = conn.Query<CModel.Vulnerability>(Constant.GET_CISA_VULNERABILITY_RECORDS, dynamicParameters, commandType: CommandType.StoredProcedure);

            // Cisa Cisa
            var cisaData = GetCisaVulnerabilities();

            // Loop through and delete from db what doesn't exist in Cisa
            foreach (var dbVulnerability in dbCisaEnnumerable)
            {
                if (!cisaData.vulnerabilities.Any(x => x.cveID == dbVulnerability.cveID))
                {
                    // Not using the API because nowhere but here should a delete occur
                    ManageDeleteRequest(dbVulnerability.cveID);
                    // Notify
                }
            }
        }
    }
}