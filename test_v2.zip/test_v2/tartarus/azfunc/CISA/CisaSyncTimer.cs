using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Tartarus.Shared;

namespace Tartarus.Cisa
{
    public class CisaSyncTimer
    {
        private readonly ILogger<CisaSyncTimer> _logger;
        private readonly ICisaService _cService;
        public CisaSyncTimer(ILogger<CisaSyncTimer> log, ICisaService cService)
        {
            _logger = log;
            _cService = cService;
        }
        [FunctionName(Constant.CISA_SYNC_TIMER)]
        public void Run([TimerTrigger("0 1 * * *")] TimerInfo myTimer)
        {
            _logger.LogInformation($"Cisa Sync Timer: {DateTime.Now}");

            _cService.SyncCisa();
        }
    }
}
