using System;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using FluentValidation;
using Dapper.FluentMap;
using System.Data.SqlClient;

using Tartarus.Defender;
using Tartarus.Vulnerability;
using Tartarus.Mitigation;
using Tartarus.Shared;
using tartarus.Model.Mitigation;
using tartarus.Validators;
using tartarus.Repository;
using tartarus.Services;
using tartarus.Services.Interface;
using Tartarus.CVEIntelligence.Service;


[assembly: FunctionsStartup(typeof(Tartarus.Startup))]
namespace Tartarus
{
    public class Startup : FunctionsStartup
    {

        public override void ConfigureAppConfiguration(IFunctionsConfigurationBuilder builder)
        {
            // Configuration
            builder.ConfigurationBuilder
                   .SetBasePath(Environment.CurrentDirectory)
                   .AddJsonFile("local.settings.json", true)
                   .AddEnvironmentVariables()
                   .Build();
        }

        public override void Configure(IFunctionsHostBuilder builder)
        {
            // Services
            ConfigureServices(builder.Services, builder.GetContext().Configuration);
        }

        private void ConfigureServices(IServiceCollection services, IConfiguration configuration)
        {
            // SQL
            services.AddScoped(_ =>
            {
                return new SqlConnection(connectionString: Environment.GetEnvironmentVariable("CONNECTION_STRING"));
            });

            // Vulnerability & Mitigation
            services.AddScoped<IValidator<MitigationAction>, MitigationActionValidator>();
            services.AddTransient<IDatabaseService, DatabaseService>();
            services.AddTransient<IVulnerabilityService, VulnerabilityService>();
            services.AddTransient<IVulnerabilitiesService, VulnerabilitiesService>();
            services.AddTransient<IMitigationService, MitigationService>();
            services.AddTransient<IMitigationsService, MitigationsService>();
            services.AddTransient<IMitigationArchiveService, MitigationArchiveService>();
            services.AddTransient<IDefenderService, DefenderService>();
            services.AddTransient<Tartarus.Cisa.ICisaService, Tartarus.Cisa.CisaService>();
            services.AddTransient<IMitigationActionRepository, MitigationActionRepository>();
            services.AddTransient<IMitigationActionService, MitigationActionService>();

            // CVE Intelligence
            services.AddTransient<IUtilityService, UtilityService>();
            services.AddTransient<Tartarus.CVEIntelligence.Service.ICisaService, CisaService>();
            services.AddTransient<Tartarus.Misp.IMispService, Tartarus.Misp.MispService>();
            services.AddTransient<IMitreService, MitreService>();
            services.AddTransient<INistService, NistService>();
            services.AddTransient<IRedHatService, RedHatService>();
            services.AddTransient<ICirclService, CirclService>();

            // Logging
            services.AddLogging();
        }
    }
}