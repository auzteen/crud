-- TABLE Customer --
CREATE TABLE Customer
(
    [CompanyShortName] NVARCHAR(15) PRIMARY KEY NOT NULL,
    [CustomerName] NVARCHAR(255) NOT NULL
)
​GO

-- TABLE Asset --
CREATE TABLE Asset
(
    [AssetId] INT IDENTITY(1,1),
    [SourceId] NVARCHAR(200) NULL,
    [AssetName] NVARCHAR(50) NOT NULL,
    [AssetType] NVARCHAR(100) NULL,
    [CompanyShortName] NVARCHAR(15) NOT NULL,
    [AssetTier] NVARCHAR(10) NULL,
    [Domain] NVARCHAR(50) NULL,
    [IPAddress] NVARCHAR(60) NULL,
    [LastExternalIpAddress]  NVARCHAR(60) NULL,
    [IPLocation] NVARCHAR(50) NULL,
    [Manufacturer] VARCHAR(50) NULL,
    [OS] NVARCHAR(50) NULL,
    [OsBuild] NVARCHAR(20) NULL,
    [OsVersion] NVARCHAR(20) NULL,
    [OsArchitecture] NVARCHAR(10) NULL,
    [HealthStatus] NVARCHAR(20) NULL,
    [DeviceValue] NVARCHAR(20) NULL,
    [RbacGroupId] NVARCHAR(60) NULL,
    [RbacGroupName] NVARCHAR(100) NULL,
    [RiskScore] NVARCHAR(20) NULL,
    [ExposureLevel] NVARCHAR(20) NULL,
    [IsAadJoined] BIT NOT NULL DEFAULT 0,
    [AadDeviceId] NVARCHAR(200) NULL,
    [Comment] NVARCHAR(100) NULL,
    [CriticalityStatus] NVARCHAR(20) NULL,
    [CriticalityScore] INT NULL,
    [AgentVersion] NVARCHAR(30) NULL,
    PRIMARY KEY (AssetName, CompanyShortName)
)
GO

ALTER TABLE Asset
ADD CONSTRAINT FK_CustomerAsset
FOREIGN KEY (CompanyShortName) REFERENCES Customer(CompanyShortName);
GO

-- TABLE AssetToolInfo --
CREATE TABLE AssetToolInfo
(
    [Id] INT IDENTITY(1,1) PRIMARY KEY,
    [CompanyShortName] NVARCHAR(15) NOT NULL,
    [Category] NVARCHAR(200) NOT NULL,
    [ReqInfoQuestion] NVARCHAR(max) NOT NULL,
    [ReqInfoAnswer] NVARCHAR(max) NULL,
    [AdditionalInfo] NVARCHAR(max) NULL,
    [AdditionalInfoExample] NVARCHAR(max) NULL
)
GO

ALTER TABLE AssetToolInfo
ADD CONSTRAINT FK_CustomerAssetToolInfo
FOREIGN KEY (CompanyShortName) REFERENCES Customer(CompanyShortName);
GO

-- VIEW vwAssets --
CREATE VIEW [dbo].[vwAssets]
AS
    SELECT REPLACE(AssetType, ' ', '') + REPLACE(AssetName, ' ', '') AS [Cursor], *
    FROM Asset
GO

-- TABLE Vulnerability --
CREATE TABLE Vulnerability
(
    [VID] INT IDENTITY(1,1),
    [MID] INT,
    [Status] NVARCHAR(20) NOT NULL DEFAULT 'Pending',
    [InCisa] BIT NOT NULL DEFAULT 0,
    [InMisp] BIT NOT NULL DEFAULT 0,
    [Assignee] NVARCHAR(30) NOT NULL DEFAULT 'Unassigned',
    [AssetName] NVARCHAR(50) NOT NULL,
    [AssetType] NVARCHAR(100) NOT NULL,
    [CompanyShortName] NVARCHAR(15) NOT NULL,
    [Source] NVARCHAR(50) NOT NULL,
    [SourceId] NVARCHAR(200) NOT NULL,
    [OS] NVARCHAR(200) NULL,
    [VendorName] NVARCHAR(50) NULL,
    [ProductName] NVARCHAR(100) NULL,
    [ProductVersion] NVARCHAR(50) NULL,
    [CVEID] NVARCHAR(500) NOT NULL,
    [IPAddress] NVARCHAR(60) NOT NULL,
    [FQDN] NVARCHAR(200) NULL,
    [Severity] NVARCHAR(15) NULL,
    [Immutability] BIT NOT NULL DEFAULT 0,
    [Created] DATETIME NOT NULL DEFAULT GETDATE(),
    [Modified] DATETIME NOT NULL DEFAULT GETDATE()
)
GO

ALTER TABLE Vulnerability
ADD CONSTRAINT FK_VulnerabilityAsset
FOREIGN KEY ("AssetName", "CompanyShortName") REFERENCES Asset("AssetName", "CompanyShortName");
GO

-- VIEW vwVulnerability --
CREATE VIEW [dbo].[vwVulnerability]
AS
    SELECT REPLACE(AssetType, ' ', '') + REPLACE(AssetName, ' ', '') AS [Cursor], *
    FROM Vulnerability
GO

-- TABLE: Mitigation --
CREATE TABLE Mitigation
(
    [MID] INT IDENTITY(1,1),
    [Status] NVARCHAR(20) DEFAULT 'Pending',
    [InCisa] BIT NOT NULL DEFAULT 0,
    [InMisp] BIT NOT NULL DEFAULT 0,
    [Assignee] NVARCHAR(30) NOT NULL DEFAULT 'Unassigned',
    [Actions] NVARCHAR(max) NOT NULL DEFAULT '*** Nothing has be done ***',
    [AssetName] NVARCHAR(50) NOT NULL,
    [AssetType] NVARCHAR(100) NOT NULL,
    [CompanyShortName] NVARCHAR(15) NOT NULL,
    [Source] NVARCHAR(50) NOT NULL,
    [SourceId] NVARCHAR(200) NOT NULL,
    [OS] NVARCHAR(200) NULL,
    [VendorName] NVARCHAR(50) NULL,
    [ProductName] NVARCHAR(100) NULL,
    [ProductVersion] NVARCHAR(50) NULL,
    [CVEID] NVARCHAR(500) NULL,
    [IPAddress] NVARCHAR(60) NOT NULL,
    [FQDN] NVARCHAR(200) NULL,
    [Severity] NVARCHAR(15) NULL,
    [Immutability] BIT DEFAULT 0,
    [Created] DATETIME NOT NULL DEFAULT GETDATE(),
    [Modified] DATETIME NOT NULL DEFAULT GETDATE()
    PRIMARY KEY (MID)
)
GO

-- VIEW vwMitigation --
CREATE VIEW [dbo].[vwMitigation]
AS
    SELECT REPLACE(AssetType, ' ', '') + REPLACE(AssetName, ' ', '') AS [Cursor], *
    FROM Mitigation
GO

ALTER TABLE Mitigation
ADD CONSTRAINT FK_MitigationAsset
FOREIGN KEY ("AssetName", "CompanyShortName") REFERENCES Asset("AssetName", "CompanyShortName");
GO

-- TABLE: MitigationAction --
CREATE TABLE [dbo].[MitigationAction] (
    [ActionId]          INT IDENTITY (1, 1) NOT NULL,
    [MitigationId]      INT NOT NULL,
    [Assignee]          NVARCHAR (50)  NOT NULL,
    [ActionDescription] NVARCHAR (500) NOT NULL,
    [Status]            NVARCHAR (20)  NOT NULL,
    [CreatedUTC]        DATETIME2 (7)  NOT NULL,
    [ModifiedUTC]       DATETIME2 (7)  NOT NULL,
    CONSTRAINT [PK_MitigationAction] PRIMARY KEY CLUSTERED ([ActionId] ASC),
    CONSTRAINT [FK_MitigationAction_Mitigation] FOREIGN KEY ([MitigationId]) REFERENCES [dbo].[Mitigation] ([MID]) ON DELETE CASCADE
);
GO

CREATE NONCLUSTERED INDEX [IX_MitigationAction_MitigationId]
    ON [dbo].[MitigationAction]([MitigationId] ASC);
GO

-- TABLE: Mitigation Archive --
CREATE TABLE MitigationArchive
(
    [MAID] INT IDENTITY(1,1),
    [Status] NVARCHAR(20),
    [InCisa] BIT NOT NULL DEFAULT 0,
    [InMisp] BIT NOT NULL DEFAULT 0,
    [Assignee] NVARCHAR(30) NOT NULL,
    [Actions] NVARCHAR(max) NOT NULL,
    [AssetName] NVARCHAR(50) NOT NULL,
    [AssetType] NVARCHAR(100) NOT NULL,
    [CompanyShortName] NVARCHAR(15) NOT NULL,
    [Source] NVARCHAR(50) NOT NULL,
    [SourceId] NVARCHAR(200) NOT NULL,
    [OS] NVARCHAR(200) NULL,
    [VendorName] NVARCHAR(50) NULL,
    [ProductName] NVARCHAR(100) NULL,
    [ProductVersion] NVARCHAR(50) NULL,
    [CVEID] NVARCHAR(500) NULL,
    [IPAddress] NVARCHAR(60) NOT NULL,
    [FQDN] NVARCHAR(200) NULL,
    [Severity] NVARCHAR(15) NULL,
    [Created] DATETIME NOT NULL DEFAULT GETDATE(),
)
GO

CREATE VIEW [dbo].[vwMitigationArchive]
AS
    SELECT REPLACE(AssetType, ' ', '') + REPLACE(AssetName, ' ', '') AS [Cursor], *
    FROM MitigationArchive
GO

-- TABLE: Cisa Vulnerability --
CREATE TABLE CisaVulnerability
(
    [CVID] INT IDENTITY(1,1),
    [CVEID] NVARCHAR(20),
    [VendorProject] NVARCHAR(50) NOT NULL,
    [Product] NVARCHAR(50) NOT NULL,
    [VulnerabilityName] NVARCHAR(100) NOT NULL,
    [DateAdded] DATETIME NOT NULL,
    [ShortDescription] NVARCHAR(1000) NOT NULL,
    [RequiredAction] NVARCHAR(500) NOT NULL,
    [DueDate] DATETIME NOT NULL,
    [Notes] NVARCHAR(4000) NULL,
    [Modified] DATETIME NOT NULL DEFAULT GETDATE(),
    [Created] DATETIME NOT NULL DEFAULT GETDATE(),
)
GO

CREATE VIEW [dbo].[vwCisaVulnerability]
AS
    SELECT REPLACE(CVEID, ' ', '') + REPLACE(VendorProject, ' ', '') AS [Cursor], *
    FROM CisaVulnerability
GO


-- GENERIC PROCEDURES --
-- STORED PROCEDURE: spAssetRecordExists --
CREATE PROCEDURE [dbo].[spAssetRecordExists]
(
	@RecordCount AS INT OUTPUT,
    @Msg AS NVARCHAR(500) OUTPUT,
    @AssetName AS NVARCHAR(50),
	@CompanyShortName AS NVARCHAR(15)
)
AS
BEGIN TRY

	SELECT
		*
	FROM
		Asset
	WHERE
		AssetName = @AssetName
		AND CompanyShortName = @CompanyShortName

	SET @RecordCount = @@ROWCOUNT

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spCreateCisaVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spCreateCisaVulnerabilityRecord]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(50),
    @VendorProject NVARCHAR(50),
    @Product NVARCHAR(50),
    @VulnerabilityName NVARCHAR(100),
    @DateAdded DATETIME,
    @ShortDescription NVARCHAR(1000),
    @RequiredAction NVARCHAR(500),
    @DueDate DATETIME,
    @Notes NVARCHAR(4000)
)
AS
BEGIN TRY

	INSERT INTO
		CisaVulnerability (CVEID, VendorProject, Product, VulnerabilityName, DateAdded, ShortDescription, RequiredAction, DueDate, Notes)
	VALUES
		(@CVEID, @VendorProject, @Product, @VulnerabilityName, @DateAdded, @ShortDescription, @RequiredAction, @DueDate, @Notes)

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spDeleteCisaVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spDeleteCisaVulnerabilityRecord]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(50)
)
AS
BEGIN TRY

    DELETE FROM CisaVulnerability WHERE CVEID = @CVEID
    RETURN

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spUpdateCisaVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spDeleteCisaVulnerabilityRecords]
(
    @Msg AS NVARCHAR(500) OUTPUT
)
AS
BEGIN TRY

	DELETE FROM CisaVulnerability
    RETURN

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spCisaVulnerabilityRecordExists --
CREATE PROCEDURE [dbo].[spCisaVulnerabilityRecordExists]
(
	@RecordCount AS INT OUTPUT,
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(20)
)
AS
BEGIN TRY

	SELECT
		CVEID
	FROM
		CisaVulnerability
	WHERE
		CVEID = @CVEID

	SET @RecordCount = @@ROWCOUNT

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spGetCisaVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spGetCisaVulnerabilityRecord]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(20)
)
AS
BEGIN TRY

	SELECT
		*
	FROM
		CisaVulnerability
	WHERE
		CVEID = @CVEID

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spGetCisaVulnerabilityRecords --
CREATE PROCEDURE [dbo].[spGetCisaVulnerabilityRecords]
(
    @Msg AS NVARCHAR(500) OUTPUT
)
AS
BEGIN TRY

	SELECT
		*
	FROM
		CisaVulnerability

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spUpdateCisaVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spUpdateCisaVulnerabilityRecord]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(50),
    @VendorProject NVARCHAR(50),
    @Product NVARCHAR(50),
    @VulnerabilityName NVARCHAR(100),
    @DateAdded DATETIME,
    @ShortDescription NVARCHAR(1000),
    @RequiredAction NVARCHAR(500),
    @DueDate DATETIME,
    @Notes NVARCHAR(4000)
)
AS
BEGIN TRY

	UPDATE CisaVulnerability
    SET
        CVEID = @CVEID,
        VendorProject = @VendorProject,
        Product = @Product,
        VulnerabilityName = @VulnerabilityName,
        DateAdded = @DateAdded,
        ShortDescription = @ShortDescription,
        RequiredAction = @RequiredAction,
        DueDate = @DueDate,
        Notes = @notes
	WHERE
		CVEID = @CVEID

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spVulnerabilityRecordExists --
CREATE PROCEDURE [dbo].[spVulnerabilityRecordExists]
(
	@RecordCount AS INT OUTPUT,
    @Msg AS NVARCHAR(500) OUTPUT,
    @AssetName AS NVARCHAR(50),
	@CompanyShortName AS NVARCHAR(15),
    @CVEID AS NVARCHAR(500),
    @Source AS NVARCHAR(50),
    @SourceId AS NVARCHAR(200),
    @VendorName AS NVARCHAR(50),
    @ProductName AS NVARCHAR(100),
    @ProductVersion AS NVARCHAR(50)
)
AS
BEGIN TRY

	SELECT
		*
	FROM
		Vulnerability
	WHERE
		AssetName = @AssetName
		AND CompanyShortName = @CompanyShortName
        AND CVEID = @CVEID
        AND Source = @Source
        AND SourceId = @SourceId
        AND VendorName = @VendorName
        AND ProductName = @ProductName
        AND ProductVersion = @ProductVersion

	SET @RecordCount = @@ROWCOUNT

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spMitigationRecordExists --
CREATE PROCEDURE [dbo].[spMitigationRecordExists]
(
	@RecordCount AS INT OUTPUT,
    @MID AS INT OUTPUT,
    @Msg AS NVARCHAR(500) OUTPUT,
    @AssetName AS NVARCHAR(50),
    @SourceId AS NVARCHAR(200),
    @CVEID AS NVARCHAR(500),
	@CompanyShortName AS NVARCHAR(15)
)
AS
BEGIN TRY
    DECLARE @Count INT

    SELECT @Count = (
        SELECT
            COUNT(*)
        FROM
            Mitigation
        WHERE
            AssetName = @AssetName
            AND CompanyShortName = @CompanyShortName
            AND SourceId = @SourceId
            AND CVEID = @CVEID
    )

    IF @Count <> 0
    BEGIN
        SELECT @MID = (
            SELECT
                MID
            FROM
                Mitigation
            WHERE
                AssetName = @AssetName
                AND CompanyShortName = @CompanyShortName
                AND SourceId = @SourceId
                AND CVEID = @CVEID
        )
    END
	SET @RecordCount = @Count

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- ASSET PROCEDURES: PAGING --
-- STORED PROCEDURE spGetNextPageAssets --
CREATE PROCEDURE [dbo].[spGetNextPageAssets]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT AssetId, SourceId, AssetName, AssetType, CompanyShortName, AssetTier, Domain,
               IPAddress, LastExternalIpAddress, IPLocation, Manufacturer, OS, OsBuild, OsVersion,
               OsArchitecture, HealthStatus, DeviceValue, RbacGroupId, RbacGroupName, RiskScore,
               ExposureLevel, IsAadJoined, AadDeviceId, Comment, CriticalityStatus, CriticalityScore,
               AgentVersion, [Cursor]
        from vwAssets
        WHERE CompanyShortName = @CompanyShortName
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        select top (@Limit)
                AssetId, SourceId, AssetName, AssetType, CompanyShortName, AssetTier, Domain,
                IPAddress, LastExternalIpAddress, IPLocation, Manufacturer, OS, OsBuild, OsVersion,
                OsArchitecture, HealthStatus, DeviceValue, RbacGroupId, RbacGroupName, RiskScore,
                ExposureLevel, IsAadJoined, AadDeviceId, Comment, CriticalityStatus, CriticalityScore,
                AgentVersion, [Cursor]
        from vwAssets
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetPrevPageAssets --
CREATE PROCEDURE [dbo].[spGetPrevPageAssets]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
                AssetId, SourceId, AssetName, AssetType, CompanyShortName, AssetTier, Domain,
                IPAddress, LastExternalIpAddress, IPLocation, Manufacturer, OS, OsBuild, OsVersion,
                OsArchitecture, HealthStatus, DeviceValue, RbacGroupId, RbacGroupName, RiskScore,
                ExposureLevel, IsAadJoined, AadDeviceId, Comment, CriticalityStatus, CriticalityScore,
                AgentVersion, [Cursor]
        from vwAssets
        WHERE CompanyShortName = @CompanyShortName
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        SELECT
                AssetId, SourceId, AssetName, AssetType, CompanyShortName, AssetTier, Domain,
                IPAddress, LastExternalIpAddress, IPLocation, Manufacturer, OS, OsBuild, OsVersion,
                OsArchitecture, HealthStatus, DeviceValue, RbacGroupId, RbacGroupName, RiskScore,
                ExposureLevel, IsAadJoined, AadDeviceId, Comment, CriticalityStatus, CriticalityScore,
                AgentVersion, [Cursor]
        FROM (select top (@Limit)
                *
            from vwAssets
            WHERE CompanyShortName = @CompanyShortName AND [Cursor] < @CursorVal
            ORDER BY [Cursor] DESC) AS t
        ORDER BY t.[Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetNextPageAssetCount --
CREATE PROCEDURE [dbo].[spGetNextPageAssetCount]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    DECLARE @returnVal INT

    SELECT @returnVal = COUNT(*)
    FROM
        (select top (@Limit)
            *
        from vwAssets
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC) as t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetPrevPageAssetCount --
CREATE PROCEDURE [dbo].[spGetPrevPageAssetCount]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    DECLARE @returnVal INT
    SELECT @returnVal = count(*)
    FROM (select top (@Limit)
            *
        from vwAssets
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] < @CursorVal
        ORDER BY [Cursor] DESC) AS t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetOffsetPageAssets
CREATE PROCEDURE [dbo].[spGetOffsetPageAssets] @PageLimit INT, @PageOffset INT, @CompanyShortName NVARCHAR(15), @Sort NVARCHAR(200), @Filter NVARCHAR(200)
AS
BEGIN
    DECLARE @QueryString NVARCHAR(1000)
    DECLARE @SortString NVARCHAR(200)
    DECLARE @FilterString NVARCHAR(200)
    SET @SortString = CASE isnull(@Sort, '') WHEN '' THEN '[Cursor]' ELSE @Sort END
    SET @FilterString = CASE isnull(@Filter, '') WHEN '' THEN '' ELSE ' AND '+@Filter END
    SET @QueryString = 'SELECT
        AssetId, SourceId, AssetName, AssetType, CompanyShortName, AssetTier, Domain,
        IPAddress, LastExternalIpAddress, IPLocation, Manufacturer, OS, OsBuild, OsVersion,
        OsArchitecture, HealthStatus, DeviceValue, RbacGroupId, RbacGroupName, RiskScore,
        ExposureLevel, IsAadJoined, AadDeviceId, Comment, CriticalityStatus, CriticalityScore,
        AgentVersion, [Cursor]
    FROM vwAssets WHERE CompanyShortName = @CompanyShortName'+@FilterString+' ORDER BY '+@SortString +' offset @PageOffset ROWS FETCH NEXT @PageLimit ROWS ONLY'
    EXEC sp_executesql @QueryString,
         N'@CompanyShortName NVARCHAR(15), @PageLimit INT, @PageOffset INT, @SortString NVARCHAR(200)',
         @CompanyShortName, @PageLimit, @PageOffset, @SortString
END
GO

-- MITIGATION PROCEDURES: PAGING --
-- STORED PROCEDURE spGetNextPageMitigation --
CREATE PROCEDURE [dbo].[spGetNextPageMitigation]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            MID,
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Immutability,
            Created,
            Modified,
            [Cursor]
        from vwMitigation
        WHERE CompanyShortName = @CompanyShortName
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        select top (@Limit)
            MID,
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Immutability,
            Created,
            Modified,
            [Cursor]
        from vwMitigation
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetPrevPageMitigation --
CREATE PROCEDURE [dbo].[spGetPrevPageMitigation]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            MID,
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Immutability,
            Created,
            Modified,
            [Cursor]
        from vwMitigation
        WHERE CompanyShortName = @CompanyShortName
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        SELECT
            MID,
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Immutability,
            Created,
            Modified,
            [Cursor]
        FROM (select top (@Limit)
                *
            from vwMitigation
            WHERE CompanyShortName = @CompanyShortName AND [Cursor] < @CursorVal
            ORDER BY [Cursor] DESC) AS t
        ORDER BY t.[Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetNextPageMitigationCount --
CREATE PROCEDURE [dbo].[spGetNextPageMitigationCount]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    DECLARE @returnVal INT

    SELECT @returnVal = COUNT(*)
    FROM
        (select top (@Limit)
            *
        from vwMitigation
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC) as t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetPrevPageMitigationCount --
CREATE PROCEDURE [dbo].[spGetPrevPageMitigationCount]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    DECLARE @returnVal INT
    SELECT @returnVal = count(*)
    FROM (select top (@Limit)
            *
        from vwMitigation
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] < @CursorVal
        ORDER BY [Cursor] DESC) AS t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetOffsetPageMitigation
CREATE PROCEDURE [dbo].[spGetOffsetPageMitigation] @PageLimit INT, @PageOffset INT, @CompanyShortName NVARCHAR(15)
AS
BEGIN
    SELECT
        MID,
        [Status],
        InCisa,
        InMisp,
        Assignee,
        AssetName,
        AssetType,
        CompanyShortName,
        [Source],
        SourceId,
        OS,
        VendorName,
        ProductName,
        ProductVersion,
        CVEID,
        IPAddress,
        FQDN,
        Severity,
        Immutability,
        Created,
        Modified,
        [Cursor]
    FROM
        vwMitigation
    WHERE
        CompanyShortName = @CompanyShortName
    ORDER BY [Cursor] offset @PageOffset ROWS FETCH NEXT @PageLimit ROWS ONLY
END
GO

-- MITIGATION ARCHIVE PROCEDURES: PAGING --
-- STORED PROCEDURE spGetNextPageMitigationArchive --
CREATE PROCEDURE [dbo].[spGetNextPageMitigationArchive]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Created,
            [Cursor]
        from vwMitigationArchive
        WHERE CompanyShortName = @CompanyShortName
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        select top (@Limit)
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Created,
            [Cursor]
        from vwMitigation
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetPrevPageMitigationArchive --
CREATE PROCEDURE [dbo].[spGetPrevPageMitigationArchive]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Created,
            [Cursor]
        from vwMitigation
        WHERE CompanyShortName = @CompanyShortName
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        SELECT
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Created
        FROM (select top (@Limit)
                *
            from vwMitigationArchive
            WHERE CompanyShortName = @CompanyShortName AND [Cursor] < @CursorVal
            ORDER BY [Cursor] DESC) AS t
        ORDER BY t.[Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetNextPageMitigationArchiveCount --
CREATE PROCEDURE [dbo].[spGetNextPageMitigationArchiveCount]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    DECLARE @returnVal INT

    SELECT @returnVal = COUNT(*)
    FROM
        (select top (@Limit)
            *
        from vwMitigationArchive
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC) as t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetPrevPageMitigationArchiveCount --
CREATE PROCEDURE [dbo].[spGetPrevPageMitigationArchiveCount]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    DECLARE @returnVal INT
    SELECT @returnVal = count(*)
    FROM (select top (@Limit)
            *
        from vwMitigationArchive
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] < @CursorVal
        ORDER BY [Cursor] DESC) AS t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetOffsetPageMitigationArchive
CREATE PROCEDURE [dbo].[spGetOffsetPageMitigationArchive] @PageLimit INT, @PageOffset INT, @CompanyShortName NVARCHAR(15)
AS
BEGIN
    SELECT
        [Status],
        InCisa,
        InMisp,
        Assignee,
        AssetName,
        AssetType,
        CompanyShortName,
        [Source],
        SourceId,
        OS,
        VendorName,
        ProductName,
        ProductVersion,
        CVEID,
        IPAddress,
        FQDN,
        Severity,
        Created,
        [Cursor]
    FROM
        vwMitigationArchive
    WHERE
        CompanyShortName = @CompanyShortName
    ORDER BY [Cursor] offset @PageOffset ROWS FETCH NEXT @PageLimit ROWS ONLY
END
GO

-- VULNERABILITY PROCEDURES: PAGING --
-- STORED PROCEDURE spGetNextPageVulnerability --
CREATE PROCEDURE [dbo].[spGetNextPageVulnerability]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            VID,
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Immutability,
            Created,
            Modified,
            [Cursor]
        from vwVulnerability
        WHERE CompanyShortName = @CompanyShortName
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        select top (@Limit)
            VID,
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Immutability,
            Created,
            Modified,
            [Cursor]
        from vwVulnerability
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetPrevPageVulnerability --
CREATE PROCEDURE [dbo].[spGetPrevPageVulnerability]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            VID,
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Immutability,
            Created,
            Modified,
            [Cursor]
        from vwVulnerability
        WHERE CompanyShortName = @CompanyShortName
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        SELECT
            VID,
            [Status],
            InCisa,
            InMisp,
            Assignee,
            AssetName,
            AssetType,
            CompanyShortName,
            [Source],
            SourceId,
            OS,
            VendorName,
            ProductName,
            ProductVersion,
            CVEID,
            IPAddress,
            FQDN,
            Severity,
            Immutability,
            Created,
            Modified,
            [Cursor]
        FROM (select top (@Limit)
                *
            from vwVulnerability
            WHERE CompanyShortName = @CompanyShortName AND [Cursor] < @CursorVal
            ORDER BY [Cursor] DESC) AS t
        ORDER BY t.[Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetNextPageVulnerabilityCount --
CREATE PROCEDURE [dbo].[spGetNextPageVulnerabilityCount]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    DECLARE @returnVal INT

    SELECT @returnVal = COUNT(*)
    FROM
        (select top (@Limit)
            *
        from vwVulnerability
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC) as t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetPrevPageVulnerabilityCount --
CREATE PROCEDURE [dbo].[spGetPrevPageVulnerabilityCount]
    @Limit INT,
    @CursorVal NVARCHAR(100),
    @CompanyShortName NVARCHAR(15)
AS
BEGIN
    DECLARE @returnVal INT
    SELECT @returnVal = count(*)
    FROM (select top (@Limit)
            *
        from vwVulnerability
        WHERE CompanyShortName = @CompanyShortName AND [Cursor] < @CursorVal
        ORDER BY [Cursor] DESC) AS t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetOffsetPageVulnerability
CREATE PROCEDURE [dbo].[spGetOffsetPageVulnerability] @PageLimit INT, @PageOffset INT, @CompanyShortName NVARCHAR(15)
AS
BEGIN
    SELECT
        VID,
        [Status],
        InCisa,
        InMisp,
        Assignee,
        AssetName,
        AssetType,
        CompanyShortName,
        [Source],
        SourceId,
        OS,
        VendorName,
        ProductName,
        ProductVersion,
        CVEID,
        IPAddress,
        FQDN,
        Severity,
        Immutability,
        Created,
        Modified,
        [Cursor]
    FROM
        vwVulnerability
    WHERE
        CompanyShortName = @CompanyShortName
    ORDER BY [Cursor] offset @PageOffset ROWS FETCH NEXT @PageLimit ROWS ONLY
END
GO

-- CISA VULNERABILITY PROCEDURES: PAGING --
-- STORED PROCEDURE spGetNextPageCisaVulnerability --
CREATE PROCEDURE [dbo].[spGetNextPageCisaVulnerability]
    @Limit INT,
    @CursorVal NVARCHAR(100)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            CVID,
            CVEID,
            VendorProject,
            Product,
            VulnerabilityName,
            DateAdded,
            ShortDescription,
            RequiredAction,
            DueDate,
            Notes,
            Modified,
            Created
            [Cursor]
        from vwCisaVulnerability
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        select top (@Limit)
            CVID,
            CVEID,
            VendorProject,
            Product,
            VulnerabilityName,
            DateAdded,
            ShortDescription,
            RequiredAction,
            DueDate,
            Notes,
            Modified,
            Created
            [Cursor]
        from vwCisaVulnerability
        WHERE [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetPrevPageCisaVulnerability --
CREATE PROCEDURE [dbo].[spGetPrevPageCisaVulnerability]
    @Limit INT,
    @CursorVal NVARCHAR(100)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            CVID,
            CVEID,
            VendorProject,
            Product,
            VulnerabilityName,
            DateAdded,
            ShortDescription,
            RequiredAction,
            DueDate,
            Notes,
            Modified,
            Created
            [Cursor]
        from vwCisaVulnerability
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        SELECT
            CVID,
            CVEID,
            VendorProject,
            Product,
            VulnerabilityName,
            DateAdded,
            ShortDescription,
            RequiredAction,
            DueDate,
            Notes,
            Modified,
            Created
            [Cursor]
        FROM (select top (@Limit)
                *
            from vwCisaVulnerability
            WHERE [Cursor] < @CursorVal
            ORDER BY [Cursor] DESC) AS t
        ORDER BY t.[Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetNextPageCisaVulnerabilityCount --
CREATE PROCEDURE [dbo].[spGetNextPageCisaVulnerabilityCount]
    @Limit INT,
    @CursorVal NVARCHAR(100)
AS
BEGIN
    DECLARE @returnVal INT

    SELECT @returnVal = COUNT(*)
    FROM
        (select top (@Limit)
            *
        from vwCisaVulnerability
        WHERE [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC) as t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetPrevPageCisaVulnerabilityCount --
CREATE PROCEDURE [dbo].[spGetPrevPageCisaVulnerabilityCount]
    @Limit INT,
    @CursorVal NVARCHAR(100)
AS
BEGIN
    DECLARE @returnVal INT
    SELECT @returnVal = count(*)
    FROM (select top (@Limit)
            *
        from vwCisaVulnerability
        WHERE [Cursor] < @CursorVal
        ORDER BY [Cursor] DESC) AS t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetOffsetPageCisaVulnerability
CREATE PROCEDURE [dbo].[spGetOffsetPageCisaVulnerability] @PageLimit INT, @PageOffset INT
AS
BEGIN
    SELECT
            CVID,
            CVEID,
            VendorProject,
            Product,
            VulnerabilityName,
            DateAdded,
            ShortDescription,
            RequiredAction,
            DueDate,
            Notes,
            Modified,
            Created
            [Cursor]
    FROM
        vwCisaVulnerability
    ORDER BY [Cursor] offset @PageOffset ROWS FETCH NEXT @PageLimit ROWS ONLY
END
GO

-- TABLE: Metasploit Vulnerability --
CREATE TABLE MispVulnerability
(
    [MVID] INT IDENTITY(1,1),
    [CVEID] NVARCHAR(20),
    [Created] DATETIME NOT NULL DEFAULT GETDATE()
)
GO

CREATE VIEW [dbo].[vwMispVulnerability]
AS
    SELECT REPLACE(CVEID, ' ', '') + REPLACE(Created, ' ', '') AS [Cursor], *
    FROM MispVulnerability
GO

-- STORED PROCEDURE: spCreateMispVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spCreateMispVulnerabilityRecord]
(
    @Msg AS NVARCHAR(500),
    @CVEID AS NVARCHAR(50)
)
AS
BEGIN TRY

	INSERT INTO
		MispVulnerability (CVEID)
	VALUES
		(@CVEID)

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spDeleteMispVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spDeleteMispVulnerabilityRecord]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(50)
)
AS
BEGIN TRY

    DELETE FROM MispVulnerability WHERE CVEID = @CVEID
    RETURN

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spUpdateMispVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spUpdateMispVulnerabilityRecord]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(50)
)
AS

BEGIN TRY

	UPDATE MispVulnerability
    SET
        CVEID = @CVEID
	WHERE
		CVEID = @CVEID

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spDeleteMispVulnerabilityRecords --
CREATE PROCEDURE [dbo].[spDeleteMispVulnerabilityRecords]
(
    @Msg AS NVARCHAR(500) OUTPUT
)
AS
BEGIN TRY

	DELETE FROM MispVulnerability
    RETURN

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spGetMispVulnerabilityRecord --
CREATE PROCEDURE [dbo].[spGetMispVulnerabilityRecord]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(20)
)
AS
BEGIN TRY

	SELECT
		*
	FROM
		MispVulnerability
	WHERE
		CVEID = @CVEID

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spGetMispVulnerabilityRecords --
CREATE PROCEDURE [dbo].[spGetMispVulnerabilityRecords]
(
    @Msg AS NVARCHAR(500) OUTPUT
)
AS
BEGIN TRY

	SELECT
		*
	FROM
		MispVulnerability

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spMispVulnerabilityRecordExists --
CREATE PROCEDURE [dbo].[spMispVulnerabilityRecordExists]
(
	@RecordCount AS INT OUTPUT,
    @Msg AS NVARCHAR(500) OUTPUT,
    @CVEID AS NVARCHAR(20)
)
AS
BEGIN TRY

	SELECT
		CVEID
	FROM
		MispVulnerability
	WHERE
		CVEID = @CVEID

	SET @RecordCount = @@ROWCOUNT

    RETURN
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE spGetPrevPageMispVulnerabilityCount --
CREATE PROCEDURE [dbo].[spGetPrevPageMispVulnerabilityCount]
    @Limit INT,
    @CursorVal NVARCHAR(100)
AS
BEGIN
    DECLARE @returnVal INT
    SELECT @returnVal = count(*)
    FROM (select top (@Limit)
            *
        from vwMispVulnerability
        WHERE [Cursor] < @CursorVal
        ORDER BY [Cursor] DESC) AS t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetPrevPageMispVulnerability --
CREATE PROCEDURE [dbo].[spGetPrevPageMispVulnerability]
    @Limit INT,
    @CursorVal NVARCHAR(100)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            MVID,
            CVEID
            [Cursor]
        from vwMispVulnerability
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        SELECT
            MVID,
            CVEID
            [Cursor]
        FROM (select top (@Limit)
                *
            from vwMispVulnerability
            WHERE [Cursor] < @CursorVal
            ORDER BY [Cursor] DESC) AS t
        ORDER BY t.[Cursor] ASC
    END
END
GO

-- STORED PROCEDURE spGetOffsetPageMispVulnerability
CREATE PROCEDURE [dbo].[spGetOffsetPageMispVulnerability] @PageLimit INT, @PageOffset INT
AS
BEGIN
    SELECT
            CVEID,
            [Cursor]
    FROM
        vwMispVulnerability
    ORDER BY [Cursor] offset @PageOffset ROWS FETCH NEXT @PageLimit ROWS ONLY
END
GO

-- STORED PROCEDURE spGetNextPageMispVulnerabilityCount --
CREATE PROCEDURE [dbo].[spGetNextPageMispVulnerabilityCount]
    @Limit INT,
    @CursorVal NVARCHAR(100)
AS
BEGIN
    DECLARE @returnVal INT

    SELECT @returnVal = COUNT(*)
    FROM
        (select top (@Limit)
            *
        from vwMispVulnerability
        WHERE [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC) as t
    RETURN @returnVal
END
GO

-- STORED PROCEDURE spGetNextPageMispVulnerability --
CREATE PROCEDURE [dbo].[spGetNextPageMispVulnerability]
    @Limit INT,
    @CursorVal NVARCHAR(100)
AS
BEGIN
    IF (@Limit IS NULL)
    BEGIN
        SELECT
            MVID,
            CVEID
            [Cursor]
        from vwMispVulnerability
        ORDER BY [Cursor] ASC
    END
    ELSE
    BEGIN
        select top (@Limit)
            MVID,
            CVEID
            [Cursor]
        from vwMispVulnerability
        WHERE [Cursor] > @CursorVal
        ORDER BY [Cursor] ASC
    END
END
GO
-- End Misp --

-- Delete From Vulnerability Table
CREATE PROCEDURE [dbo].[spDeleteFromVulnerabilityTable]
AS
BEGIN TRY
    DECLARE @Msg NVARCHAR

    DELETE FROM Vulnerability

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- Managed Found Active Mitigation --
CREATE PROCEDURE [dbo].[spManageFoundActiveMitigation]
(
    @Msg NVARCHAR(500) OUTPUT,
	@MID AS INT,
	@VID AS INT
)
AS
BEGIN TRY
	DECLARE @AssetName NVARCHAR(50)
	DECLARE @AssetType NVARCHAR(100)
	DECLARE @CompanyShortName NVARCHAR(15)
	DECLARE @CurrentMitigationStatus NVARCHAR(20)
	DECLARE @CurrentMitigationAssignee NVARCHAR(30)

	SELECT @AssetName = ( SELECT AssetName FROM Vulnerability WHERE VID = @VID )
	SELECT @AssetType = ( SELECT AssetType FROM Vulnerability WHERE VID = @VID )
	SELECT @CompanyShortName = ( SELECT CompanyShortName FROM Vulnerability WHERE VID = @VID )

	SELECT @CurrentMitigationStatus = ( SELECT [Status] FROM Mitigation WHERE MID = @MID AND AssetName = @AssetName AND CompanyShortName = @CompanyShortName )
	SELECT @CurrentMitigationAssignee = ( SELECT Assignee FROM Mitigation WHERE MID = @MID AND AssetName = @AssetName AND CompanyShortName = @CompanyShortName )

	IF(@CurrentMitigationStatus = 'Completed')
	BEGIN
		UPDATE Mitigation
		SET [Status] = 'Re-Opened', [Immutability] = 1
		WHERE MID = @MID AND AssetName = @AssetName AND AssetType = @AssetType AND CompanyShortName = @CompanyShortName
	END

	Update Vulnerability
	SET [Status] = 'Mitigation', Assignee = @CurrentMitigationAssignee, [MID] = @MID
	WHERE VID = @VID AND AssetName = @AssetName AND AssetType = @AssetType AND CompanyShortName = @CompanyShortName

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE:spUPdateMitigation --
CREATE PROCEDURE[dbo].[spUpdateMitigation]
(
    @MID AS INT,
    @Status AS NVARCHAR(20),
    @Assignee AS NVARCHAR(30),
    @Actions AS NVARCHAR(max)
)
WITH RECOMPILE
AS
BEGIN TRY
    DECLARE @Msg NVARCHAR(200)
    UPDATE
            Mitigation
    SET
            [Status] = @Status,
            [Assignee] = @Assignee,
            [Actions] = @Actions,
            [Modified] = GETDATE()
    WHERE
            MID = @MID

    UPDATE
            Vulnerability
    SET
            [Assignee] = @Assignee
    WHERE
            MID = @MID

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE: spUpdateVulnerabilityInsertMitigation --
CREATE PROCEDURE[dbo].[spUpdateVulnerabilityInsertMitigation]
(
    @Msg NVARCHAR(500) OUTPUT,
    @VID AS INT,
    @Status AS NVARCHAR(20),
    @Assignee AS NVARCHAR(30)
)
AS
BEGIN TRY
    DECLARE @MID INT
    DECLARE @Immutable BIT

    SELECT @Immutable = ( SELECT Immutability FROM Vulnerability WHERE VID = @VID)

    IF @Immutable = 0
    BEGIN
        UPDATE
            Vulnerability
        SET
            [Status] = @Status,
            [Assignee] = @Assignee,
            [Immutability] = 1,
            [Modified] = GETDATE()
        WHERE
            VID = @VID

        INSERT INTO Mitigation ( [Status], InCisa, InMisp, Assignee, AssetName, AssetType, CompanyShortName, [Source], SourceId, Os,
                                VendorName, ProductName, ProductVersion, CVEID, IPAddress, FQDN,
                                Severity, Immutability )
        SELECT
                                [Status], InCisa, InMisp, Assignee, AssetName, AssetType, CompanyShortName, [Source], SourceId, Os,
                                VendorName, ProductName, ProductVersion, CVEID, IPAddress, FQDN,
                                Severity, Immutability
        From Vulnerability
        WHERE VID = @VID

        SET @MID = @@IDENTITY

        UPDATE Mitigation
        SET [Status] = 'Pending'
        WHERE MID = @MID

        UPDATE Vulnerability
        SET [MID] = @MID
        WHERE VID = @VID
    END

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- Vulnerability Insert --
CREATE PROCEDURE [dbo].[spInsertNewVulnerabilityRecord]
(
    @NewId INT OUTPUT,
    @Msg NVARCHAR(500) OUTPUT,
    @Status NVARCHAR(20),
    @InCisa BIT,
    @InMisp BIT,
    @Assignee NVARCHAR(30),
    @AssetName NVARCHAR(50),
    @AssetType NVARCHAR(100),
    @CompanyShortName NVARCHAR(15),
    @Source NVARCHAR(50),
    @SourceId NVARCHAR(200),
    @OS NVARCHAR(200),
    @VendorName NVARCHAR(50),
    @ProductName NVARCHAR(100),
    @ProductVersion NVARCHAR(50),
    @CVEID NVARCHAR(500),
    @IPAddress NVARCHAR(15),
    @FQDN NVARCHAR(200),
    @Severity NVARCHAR(15)
)
AS
BEGIN TRY
    INSERT INTO Vulnerability
	(
        [Status],
        InCisa,
        InMisp,
        Assignee,
	    AssetName,
        AssetType,
        CompanyShortName,
        [Source],
        SourceId,
        OS,
        VendorName,
        ProductName,
        ProductVersion,
        CVEID,
        IPAddress,
    	FQDN,
        Severity
	)
    VALUES
    (
        @Status,
        @InCisa,
        @InMisp,
        @Assignee,
        @AssetName,
        @AssetType,
        @CompanyShortName,
        @Source,
        @SourceId,
        @OS,
        @VendorName,
        @ProductName,
        @ProductVersion,
        @CVEID,
        @IPAddress,
        @FQDN,
        @Severity
    )

    SELECT @NewId = @@IDENTITY;

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE -- Get Vulnerability -- spGetVulnerability
CREATE PROCEDURE [dbo].[spGetVulnerability]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @VID AS INT
)
AS
BEGIN TRY

    SELECT *
    FROM Vulnerability
    WHERE VID = @VID

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE -- Mitigation Insert -- spInsertNewMitigationRecord
CREATE PROCEDURE [dbo].[spInsertNewMitigationRecord]
(
    @VID INT,
	@Status NVARCHAR(20),
    @InCisa BIT,
    @InMisp BIT,
    @Assignee NVARCHAR(30),
    @AssetName NVARCHAR(50),
    @AssetType NVARCHAR(100),
    @CompanyShortName NVARCHAR(15),
    @Source NVARCHAR(50),
    @SourceId NVARCHAR(200),
    @OS NVARCHAR(200),
    @VendorName NVARCHAR(50),
    @ProductName NVARCHAR(100),
    @ProductVersion NVARCHAR(50),
    @CVEID NVARCHAR(500),
    @IPAddress NVARCHAR(15),
    @FQDN NVARCHAR(200),
    @Severity NVARCHAR(15)
)
AS
BEGIN TRY
    DECLARE @Msg NVARCHAR
    INSERT INTO Mitigation
	(
        [Status],
        InCisa,
        InMisp,
        Assignee,
		AssetName,
		AssetType,
		CompanyShortName,
		[Source],
		SourceId,
		OS,
		VendorName,
        ProductName,
        ProductVersion,
        CVEID,
        IPAddress,
        FQDN,
        Severity
	)
    VALUES
    (
        @Status,
        @InCisa,
        @InMisp,
        @Assignee,
        @AssetName,
        @AssetType,
        @CompanyShortName,
        @Source,
        @SourceId,
        @OS,
        @VendorName,
        @ProductName,
        @ProductVersion,
        @CVEID,
        @IPAddress,
        @FQDN,
        @Severity
    )
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- STORED PROCEDURE -- Get Mitigation -- spGetMitigation
CREATE PROCEDURE [dbo].[spGetMitigation]
(
    @Msg AS NVARCHAR(500) OUTPUT,
    @MID AS INT
)
AS
BEGIN TRY

    SELECT *
    FROM Mitigation
    WHERE MID = @MID

END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO

-- Mitigation Archive Insert --
CREATE PROCEDURE [dbo].[spInsertNewMitigationArchiveRecord]
(
    @Status NVARCHAR(20),
    @InCisa BIT,
    @InMisp BIT,
    @Assignee NVARCHAR(30),
    @Actions NVARCHAR(max),
    @AssetName NVARCHAR(50),
    @AssetType NVARCHAR(100),
    @CompanyShortName NVARCHAR(15),
    @Source NVARCHAR(50),
    @SourceId NVARCHAR(200),
    @OS NVARCHAR(200),
    @VendorName NVARCHAR(50),
    @ProductName NVARCHAR(100),
    @ProductVersion NVARCHAR(50),
    @CVEID NVARCHAR(500),
    @IPAddress NVARCHAR(15),
    @FQDN NVARCHAR(200),
    @Severity NVARCHAR(15)
)
AS
BEGIN TRY
    DECLARE @Msg NVARCHAR
    INSERT INTO Mitigation
	(
        [Status],
        InCisa,
        InMisp,
        Assignee,
        Actions,
        AssetName,
        AssetType,
        CompanyShortName,
        [Source],
        SourceId,
        OS,
        VendorName,
        ProductName,
        ProductVersion,
        CVEID,
        IPAddress,
        FQDN,
        Severity
	)
    VALUES
    (
        @Status,
        @InCisa,
        @InMisp,
        @Assignee,
        @Actions,
        @AssetName,
        @AssetType,
        @CompanyShortName,
        @Source,
        @SourceId,
        @OS,
        @VendorName,
        @ProductName,
        @ProductVersion,
        @CVEID,
        @IPAddress,
        @FQDN,
        @Severity
    )
END TRY
BEGIN CATCH
    SET @Msg = ERROR_MESSAGE()
END CATCH
GO


-- Vulnerability Jobs -- Azure SQL jobs functionality must be managed by creating a new SQL DB resource and configuring itas a jobs DB
--USE msdb ;
--GO
--EXEC dbo.sp_add_jobb
--     @job_name = N'Purge Mitigation Table. Modified Greater Than 30 Days'
--GO
--EXEC dbo.sp_add_jobstep
--     @job_name = N'Purge Mitigation Table. Modified Greater Than 30 Days'
--     @step_name = N'Move Records to MiticationArchive',
--     @subsystem = N'TSQL',
--     @command = N'
--        DECLARE @StartCnt INT = 1;
--        DECLARE @EndCnt INT = 0;
--
--        SELECT @EndCnt = COUNT(*) FROM Mitigation;
--
--        IF(@EndCount != 0)
--        BEGIN
--            WHILE @StartCnt <= @EndCnt
--            BEGIN
--                DECLARE @ReferenceTime DATETIME;
--                DECLARE @RowDateTime DATETIME;
--                SELECT @RowDateTime = (
--                    SELECT m.Modified
--                    FROM Mitigation m
--                    INNER JOIN inserted i
--                    ON i.MID = m.MID
--                )
--
--                SET @ReferenceTime = DATEADD(day, -30, GETDATE())
--                IF(@ReferenceTIme > @RowDateTime)
--                BEGIN
--                    INSERT INTO MitigationArchive ( "Status", "Action" "AssetName", "AssetType", "CompanyShortName",
--                                                    "Source", "SourceId", "OS", "VendorName",
--                                                    "ProductName", "ProductVersion", "CVEID", "IPAddress", "FQDN",
--                                                    "Severity" )
--                    SELECT v.Status, v.Action, v.AssetName, v.AssetType, v.CompanyShortName,  v.Source, v.SourceId, v.OS,
--                           v.VendorName, v.ProductName, v.ProductVersion, v.CVEID,
--                           v.IPAddress, v.FQDN, v.Severity
--                    FROM Mitigation AS m
--                    INNER JOIN inserted AS i
--                    ON m.MID = i.MID;
--
--                    DELETE FROM Mitigation m
--                    INNER JOIN inserted i
--                    ON i.MID = m.MID
--                END
--            END
--        END
--
--     ',
--     @retry_attempts = 5,
--     @retry_interval = 5 ;
--GO
--EXEC dbo.sp_add_schedule
--    @schedule_name = N'RunDaily',
--    @freq_type = 4,
--    @active_start_time = 000000 ;
--    GO
--EXEC sp_attach_schedule
--   @job_name = N'Purge Mitigation Table. Modified Greater Than 30 Days',
--   @schedule_name = N'RunDaily';
--GO
--EXEC dbo.sp_add_jobserver
--    @job_name = N'Purge Mitigation Table. Modified Greater Than 30 Days';
--GO

-- HELPERS --
-- List all stored procedures in a SQL Server DB --
/*
    SELECT
        SCHEMA_NAME(schema_id) AS [Schema],
        name
    FROM
        sys.objects
    WHERE
        type = 'P';
*/

-- List all triggers in a SQL Server DB
/*
    SELECT
        sysobjects.name AS trigger_name
        ,USER_NAME(sysobjects.uid) AS trigger_owner
        ,s.name AS table_schema
        ,OBJECT_NAME(parent_obj) AS table_name
        ,OBJECTPROPERTY( id, 'ExecIsUpdateTrigger') AS isupdate
        ,OBJECTPROPERTY( id, 'ExecIsDeleteTrigger') AS isdelete
        ,OBJECTPROPERTY( id, 'ExecIsInsertTrigger') AS isinsert
        ,OBJECTPROPERTY( id, 'ExecIsAfterTrigger') AS isafter
        ,OBJECTPROPERTY( id, 'ExecIsInsteadOfTrigger') AS isinsteadof
        ,OBJECTPROPERTY(id, 'ExecIsTriggerDisabled') AS [disabled]
    FROM sysobjects
    INNER JOIN sys.tables t
        ON sysobjects.parent_obj = t.object_id
    INNER JOIN sys.schemas s
        ON t.schema_id = s.schema_id
    WHERE sysobjects.type = 'TR'
*/

-- LIST ALL PROCEDURES WHEREcabd_login_rw has EXECUTE PERMISSIONS ON
/*
    SELECT [name]
    FROM sys.objects obj
    INNER JOIN sys.database_permissions dp ON dp.major_id = obj.object_id
    WHERE obj.[type] = 'P' -- stored procedure
    AND dp.permission_name = 'EXECUTE'
    AND dp.state IN ('G', 'W') -- GRANT or GRANT WITH GRANT
    AND dp.grantee_principal_id =
    (SELECT principal_id FROM sys.database_principals WHERE [name] = 'cadb_login_rw')
*/


-- -- GO INSERT STATEMENTS ON ASSET TABLE
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'qwerty13p03', 'Audit / Scan Servers', 'open', '', '', '10.123.0.3', 'DC', '', 'XXX', 'ABC'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12345', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.1', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12346', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.2', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12347', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.3', '002 - GVA Network', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12348', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.4', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12349', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.5', '000 - NEU Network', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12350', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.6', '009 - ZUR Network', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12351', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.7', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12352', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.8', '012 - PHL Network', 'Microsoft Corporation', 'Win 2019', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12353', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.9', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12354', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.10', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12355', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.11', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12356', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.12', '008 - ISR Network', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'SCCM123QWE', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.5', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'SCCM'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'AD12345ASD', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.6', 'DC LIVE', 'Microsoft Corporation', 'Win 2016', 'Azure AD Connect'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12345', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.7', '000 - NEU Network', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12346', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.8', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12347', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.9', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12348', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.10', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12349', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.11', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12350', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.12', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12351', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.13', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12352', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.14', 'DC LIVE', 'Xen', 'Win 2019', 'Citrix ITTS'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12353', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.15', 'DC LIVE', 'Xen', 'Win 2019', 'Citrix ITTS'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12354', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.16', 'DC LIVE', 'Xen', 'Win 2019', 'Citrix ITTS'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12355', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.17', 'DC LIVE', 'Xen', 'Win 2019', 'Citrix ITTS'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12345A', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.1', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'File Server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12345', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.2', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'File Server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12346', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '', '', '', 'CentOS', 'Splunk'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12347', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '', '', '', 'CentOS', 'Splunk'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12348', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '', '', '', 'CentOS', 'Splunk'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12349', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '', '', '', 'CentOS', 'Splunk'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12350', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.7', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12351', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.8', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12352', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.9', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12353', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.10', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12354', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.11', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12355', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.12', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12356', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.13', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12357', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.14', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12358', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.15', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12359', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.16', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12360', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.17', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12361', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.18', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12362', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.19', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12363', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.20', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12364', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.21', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12365', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.22', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12366', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.23', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A2', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.10', 'DC A13', 'Microsoft Corporation', 'Win 2012 R2', 'SQL'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A3', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.11', 'DC A14', 'Microsoft Corporation', 'Win 2012 R2', 'SQL'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A4', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.12', 'DC A15', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A5', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.13', 'DC A16', 'Microsoft Corporation', 'Win 2019', 'SQL'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A6', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.14', 'DC A17', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO
-- INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A7', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.15', 'DC A18', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A8', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.16', 'DC A19', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A9', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.17', 'DC A20', 'VMware, Inc.', 'Win 2019', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A10', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.18', 'DC A21', 'VMware, Inc.', 'Win 2019', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A11', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.19', 'DC A22', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'qwerty13p01', 'Audit / Scan Servers', 'open', '', '', '10.123.0.1', 'DC', '', 'XXX', 'ABC'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'qwerty13p02', 'Audit / Scan Servers', 'open', '', '', '10.123.0.2', 'DC', '', 'XXX', 'ABC'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'qwerty13p03', 'Audit / Scan Servers', 'open', '', '', '10.123.0.3', 'DC', '', 'XXX', 'ABC'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12345', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.1', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12346', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.2', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12347', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.3', '002 - GVA Network', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12348', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.4', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12349', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.5', '000 - NEU Network', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12350', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.6', '009 - ZUR Network', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12351', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.7', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12352', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.8', '012 - PHL Network', 'Microsoft Corporation', 'Win 2019', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12353', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.9', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12354', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.10', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12355', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.11', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'XXXABC12356', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.0.0.12', '008 - ISR Network', 'VMware, Inc.', 'Win 2012 R2', 'Domain Controller'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'SCCM123QWE', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.5', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'SCCM'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'AD12345ASD', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.6', 'DC LIVE', 'Microsoft Corporation', 'Win 2016', 'Azure AD Connect'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12345', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.7', '000 - NEU Network', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12346', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.8', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12347', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.9', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12348', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.10', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12349', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.11', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12350', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.12', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12351', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.13', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'PKI'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12352', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.14', 'DC LIVE', 'Xen', 'Win 2019', 'Citrix ITTS'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12353', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.15', 'DC LIVE', 'Xen', 'Win 2019', 'Citrix ITTS'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12354', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.16', 'DC LIVE', 'Xen', 'Win 2019', 'Citrix ITTS'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'ASD12355', 'Domain Controllers', 'open', 'Tier 0', 'MYDOMAIN', '10.3.4.17', 'DC LIVE', 'Xen', 'Win 2019', 'Citrix ITTS'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12345A', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.1', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'File Server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12345', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.2', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'File Server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12346', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '', '', '', 'CentOS', 'Splunk'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12347', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '', '', '', 'CentOS', 'Splunk'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12348', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '', '', '', 'CentOS', 'Splunk'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12349', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '', '', '', 'CentOS', 'Splunk'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12350', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.7', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12351', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.8', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12352', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.9', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12353', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.10', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12354', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.11', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12355', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.12', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12356', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.13', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12357', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.14', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12358', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.15', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12359', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.16', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12360', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.17', 'DC LIVE', 'Microsoft Corporation', 'Win 2019', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12361', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.18', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12362', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.19', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12363', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.20', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12364', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.21', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12365', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.22', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'HHH12366', 'High Value Servers', 'open', 'Tier 1', 'MYDOMAIN', '10.24.0.23', 'DC LIVE', 'VMware, Inc.', 'Win 2012 R2', 'NPS server'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A2', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.10', 'DC A13', 'Microsoft Corporation', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A3', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.11', 'DC A14', 'Microsoft Corporation', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A4', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.12', 'DC A15', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A5', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.13', 'DC A16', 'Microsoft Corporation', 'Win 2019', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A6', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.14', 'DC A17', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A7', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.15', 'DC A18', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A8', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.16', 'DC A19', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A9', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.17', 'DC A20', 'VMware, Inc.', 'Win 2019', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A10', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.18', 'DC A21', 'VMware, Inc.', 'Win 2019', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'PRO999A11', 'Other Important Systems', 'open', '', 'YOURDOMAIN', '10.10.10.19', 'DC A22', 'VMware, Inc.', 'Win 2012 R2', 'SQL'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'qwerty13p01', 'Audit / Scan Servers', 'open', '', '', '10.123.0.1', 'DC', '', 'XXX', 'ABC'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'qwerty13p02', 'Audit / Scan Servers', 'open', '', '', '10.123.0.2', 'DC', '', 'XXX', 'ABC'
-- GO INSERT INTO Asset
--     (AssetName, AssetType, CompanyShortName, AssetTier, Domain, IPAddress, IPLocation, Manufacturer, OS, Comment)
-- SELECT 'qwerty13p03', 'Audit / Scan Servers', 'open', '', '', '10.123.0.3', 'DC', '', 'XXX', 'ABC'
-- GO


-- -- INSERT STATEMENTS -- Asset Info
-- INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'High level design of the networks', 'See Network documentation in Upload folder', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide information about your high level network design (network diagrams, if available).', 'High Level Network Diagrams are attached.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Most critical business applications', 'Business Central
-- Laserfiche (DMS)
-- Advent (Investment system)
-- Investran (Investment system)
-- Datawarehouse
-- Moxtra (SF Connect) - Hosted in Azure', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a list of your most critical business applications (hostname, IP address, administrative access).

-- If you have an asset inventory, and you have prioritized your applications based on value of information assets, revenue generating, business continuity, or other factors, it''s best to use that list.

-- This helps MDR/Sentinel alert logic to focus and to better carve-out anomalies.

-- Recommendation: tag most critical application servers in Defender if possible.', 'O365, IDEA, Salesforce

-- List of servers for the applications is attached (hostname, IP address, administrative access).', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Further commonly used internal applications', 'AX
-- Sharepoint
-- JobStream
-- Lawman
-- RiskScreen', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please list further internal applications you are most commonly using for your business (with servers and IP details where the apps are hosted).', 'Idea Soft Mindworks (ISM) and FLILabs are core business applications used by more than 40% of the employees.

-- List of servers for the applications is attached (hostname, IP address, administrative access).', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Naming Convention for servers', 'aabbbxxxy##
-- aa: server type (ap: application, nm: network monitoring, ad: AD related)
-- bbb: description (ex: dom: DC, BUC: Business Central, etc.
-- xxx: Site number (101, 102, 103: Datacenter prod, 104: Datacenter dev, 105 Datacenter UAT, 000-030: Branches)
-- y: Environment (P:Prod, U: UAT, D:Dev)
-- ##: server number

-- See also attached files: G1x - Standard Codes and Naming Standards', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide the naming convention for servers, if any.', 'Naming convention: s-server, p-d-u prod/dev/uat, xyz -location short, abc- custom location text, 12-appid abbreviation, defgh-custom text, 1-incremental

-- Examples: spazueuw73redis1, sdnycman90flidb2', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Naming Conventions user endpoints (workstations, laptop, etc.)', 'Workstation/laptops:
-- SHAZxxx####
-- xxx: Site number
-- ####: machine number

-- Or
-- SHAZ####
-- ####: machine number

-- Citrix:
-- XED####xxxP##: Shared Citrix server (several users per machine)
-- XEV####xxxP##: VDI (Windows 10)
-- ##: number
-- xxx: Site number', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide your naming convention for endpoints (workstations, laptops, etc.), if any.', 'Naming convention: w-workstation / l-laptop / m-macbook / p-printer  xyz -location short, abc- custom location text

-- Example: pphighq (Printer at the Philippines global HQ)', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Naming Convention for user accounts', 'Standard user:
-- - samacocuntname: <first letter of first name><name>

-- - some legacy users with <firstname>.<lastname>
-- - UPN: email address
--    ', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide your naming convention for users, if any.', 'Naming convention: u(user)+incremental number.

-- Example: u124', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Naming Convention for administrator accounts', 'Migration in progress:
-- old model:
-- - xxxoper (admin account for daily admin tasks)
-- - xxxadmin (admin account for action requiring tickets or change)
-- with xxx: user initials

-- New model:
-- - <samaccountname>.oper (admin account for daily admin tasks)
-- - <samaccountname>.admin (admin account for action requiring tickets or change)
-- ', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide your naming convention for admins, if any.', 'Naming convention: adm-<lastname, emp ID>

-- Example: adm-doe124', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Naming Conventions for service accounts', 'In general:
-- svc*
-- Some legacy accounts with: *svc
-- SQL accounts:
-- sql*', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide your naming convention for service accounts, if any.', 'Naming convention: svc+application+incremental number

-- Example: svc-fli453', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Domain Controllers', 'MFOGROUP:
-- ADDOMxxxPxx

-- Group.local
-- aaADDOM##YYY
-- aa: Forest location (ST=Datacenter, UK=uk.group.local, etc)
-- ##: server number
-- YYY: Site

-- See full list in Asset list', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of DCs. Recommendation: tag in Defender if possible.', 'spazudc10azudc1-12, speurdc10azarc1-4, spnycdc10azarc1-20', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'High value Servers', 'See Asset list tab', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of HV servers. Recommendation: tag in Defender if possible.', 'High value server list attached', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'High value user endpoints', 'See Asset list tab (Citrix ITTS)', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of HV workstations, laptops, tablets etc. Recommendation: tag in Defender if possible.', 'VIP workstation list attached', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Administrator accounts', 'Local admin is SrvAdmin', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of administration accounts.', 'adm-doe124, adm-smi13', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Service Accounts', 'See file List of Service Accounts.xlsx', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of service accounts.
-- ', 'List attached', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Backup servers', 'C015-back-01.sthmgnt', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of backup servers. Recommendation: tag in Defender if possible.', 'List of backup servers attached.

-- We are also using an in-house developed solution called IdeaTree.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'DNS Servers', 'Domain controllers (See asset list)', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of DNS servers with DNS and NTP IPs. Recommendation: tag in Defender if possible.', 'List attached', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Internet facing Servers', 'All system with IP 192.168.* are in DMZ', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of internet facing servers, such as Web Servers, WAF Servers, Email Relays, or Proxy Servers for example.', 'Network Diagram Attached for the DMZ, and list attached. Naming convention contains w for web', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Jumphosts', 'See Citrix ITTS machines in asset list', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of all jumphosts (names and IPs), if jumphosts are used.', 'List attached. We are planning to adopt a Zero Trust Network Access approach and migrate away from the current Jumphosts.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Admin groups and privileged access management (PAM) approach', 'The following groups give more permissions when you have higher Tier (Tier 3 > Tier 2)
-- RBA Information Technology - Tier 1
-- RBA Information Technology - Tier 2
-- RBA Information Technology - Tier 3
-- RBA Information Technology - Tier 4
-- RBA Information Technology - Tier 5
-- RBA Information Technology - Tier 6

-- Tier 5 and 6 are used on a ticket basis.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of your admin groups (incl. Security Identifiers (SID)) and explain the PAM approach/structure used in your company.', 'We have X groups of administrators, with different level of access:
-- - Desktop Admin (list attached, local administrator rights for workstations)
-- - Domain Admins (list attached, 7 administrators for AD and DC administrative tasks)
-- - Windows Server Admins (list attached, dedicated Win Srv admin group, working closely with the Application Administrators)

-- All admin access is through CyberArk PIM solution, sessions are recorded and log is available of all commands/scripts executed.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Special groups', 'RBR FS Inf NavOne Bottomline ', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Please provide a full list of special groups (group names, user names in groups, Security Identifiers (SID)).

-- Special groups can be any high privileged or sensitive groups you are monitoring, which are not necessarily admin users (e.g., users belonging to C-Level, HR, Finance, guest account groups, or similar).', 'Application and DB admins (list attached, dedicated to 1-3 applications per administrator and access to a limited number of servers).', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'External resources', 'LombardOdier direct connection
-- BottomLine: MPLS connection
-- Bloomberg: Bloomberg routers
-- Calastone: VPN connection
-- James Brealey: VPN connection
-- Moxtra', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Any external trusted IT interconnectivity, important external partnerships (e.g. IT Infrastructure Providers, Administrators, Contractor, external Payroll), or acquired companies which aren''t fully integrated. List of main ISPs (Internet Service Providers).', 'We have an extranet with BigMindInc, a company currently being acquired by us.

-- Our main ISPs are Vodafone and Swisscom among small ISP lines in branches.

-- We outsource Payroll to PayYourPeopleNow Inc.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Other important systems', 'Sage (Salesforce)
-- Anaplan
-- Power BI Service (in our tenant)', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'If you can think of any other technical assets not listed in questions above, please add here.

-- e.g. Cloud systems, legacy applications, more', 'None', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Critical Servers and Systems', 'Other important accounts', 'Honeypot account: sthsuperadmin
-- Executives people:
-- <list of names>', 'If you can think of any accounts not listed in questions above, please add here.

-- e.g. key members of staff, generic service accounts.', 'None'
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'External exceptions', 'External exceptions answer', 'Please list sites, applications or similar which are whitelisted as they fall outside of normal behaviour in your IT environment.', 'IDEA SecLab site is out of scope for security monitoring, as it is a product security testing lab.'
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Admin tools exceptions', '<your answer>', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Please list admin tools which are allowed in your IT environment, e.g. sysinternal suite.', 'Putty, Ansible, Chef', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Scan servers exceptions', 'Nessus (Tenable.sc)', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Please list scan server exceptions, e.g. vulnerability scanners.', 'We use external scanners quarterly on internet facing servers.
-- List attached.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Timing admin tasks', 'No specific timing', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Please list administrative access related tasks that you might schedule (for example according to ITIL Change Management processes), and whether you differentiate between different groups (servers, applications, workstations, BYOD etc. for the software updates, AD Group Policy changes, Server and Workstation patching, Webserver updates) or other scheduled change windows when admin accounts are more active than usual, and other automated/timed tasks are running (automated backups, stress tests, configuration scripts etc.).', 'Every 2nd weekend of the month, we have scheduled changes, including patch release to test group, release of tested patches to all Windows servers, subsequently application updates, and any AD updates.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Predefined whitelists', 'No defined whitelist', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Please provide a list of whitelists you might have for e.g., Proxy, EDR, …', 'Managed by IT Provider, list attached.

-- Examples of proxy whitelist items:
-- - intranet.idea.com*
-- - partner-connect.idea.com*
-- - seclab.idealabs.com*
-- - extranet.idea.com*
-- - ...

-- Examples of EDR whitelist items:
-- - SHA256: 275a021bbfb6489e54d471899f7db-9d1663fc695ec2fe2a2c4538aabf651fd0f
-- - Process: wsus.exe
-- - ...', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Predefined app whitelists', 'No defined whitelist', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Please provide a list of approved software applications or executable files that are permitted.', 'McAfee had some problems with our internal apps on IDEA, therefore, whitelists exists for all the services in the folders. Whitelist attached.

-- Example of app whitelists:
-- - Folder: C:\Program Files (x86)\IDEA Software\lib  (all workstations)
-- - Folder: C:\Program Files (x86)\IDEA Software\bin  (all workstations)
-- - Process: idealabs.exe
-- - ...', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Remote control tools allowed', 'RoyalTS, TeamViewer (Workstations only)', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'We would like to understand what remote control tools like TeamViewer, AnyDesk, or similar you are using in your environment.', 'VNC, RDP, Teamviewer, Putty, SSH to linux servers', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'TOR usage in your network', 'Prohibited.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Is TOR (The Onion Router) allowed/prohibited in your environment?', 'Prohibited.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Authorized cloud storage', 'Difficult to answer: None except DocVault (docvault.clienthub.stonehagefleming.com/)
-- Several users are using cloud storage as exceptions in our proxy', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'What cloud storage (e.g., Dropbox, OneDrive, GoogleDrive, or similar) is authorized to be used by your users.', 'Only OneDrive', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'GitHub/GitLab usage', 'No. Some users are using a company BitBucket hosted in Azure', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Is your company using GitHub/Git Lab (yes/no)? If so, please identify users expected to use Git.

-- Are you using CI/CD(Continuous Integration/Continuous Deployment) systems to deploy source code changes to production systems?', 'We maintain our own old SVN Server, but the Cloud team is using GilHub for Azure workloads', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Powershell', 'Allowed to admins (no technical restrictions in place). Our DBA is using it extensively.
-- What would be your recommendations on this?', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Is Powershell enabled on some/all your Windows machines? Do you log Powershell? What is it used for?', 'Powershell 7.2 enabled and is being logged on all workstations and servers.

-- We have a dozen IT maintenance scripts run by the external service provider for maintaining health and reporting.', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Creation of user account', 'Accounts are created by our Service Delivery team (for standard users) or by security team for service accounts and privileged accounts', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'We are interested to know who can create users (e.g., special service account)? What is the standard process of creating users?', 'Through IT Support, only Team leads can create users. List of accounts attached (e.g., adm-doe124).', '', ''
-- GO INSERT INTO AssetToolInfo
--     (CompanyShortName, Category, ReqInfoQuestion, ReqInfoAnswer, AdditionalInfo, AdditionalInfoExample)
-- SELECT 'open', 'Special Hosts, Tools and Exceptions', 'Others', '<your answer>', '', ''
-- GO

-- -- GRANT PRIVILEGES
-- --GRANT EXECUTE ON spGetNextPageAssets to citadb_sbx_login_rw
-- --GRANT EXECUTE ON spGetPrevPageAssets to citadb_sbx_login_rw
-- --GRANT EXECUTE ON spGetNextPageAssetCount to citadb_sbx_login_rw
-- --GRANT EXECUTE ON spGetPrevPageAssetCount to citadb_sbx_login_rw

-- --GRANT EXECUTE ON spAssetRecordExists to cadb_login_rw
-- --GRANT EXECUTE ON spMitigationRecordExists to cadb_login_rw
-- --GRANT EXECUTE ON spInsertNewVulnerabilityRecord to cadb_login_rw
-- --GRANT EXECUTE ON spInsertNewMitigationrecord to cadb_login_rw
-- --GRANT EXECUTE ON spInsertNewMitigationArchiveRecord to cadb_login_rw
