using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Text.Json;
using Citadel.Model.Asset;
using Citadel.Model.Root;
using Citadel.Services;

namespace Citadel
{
    public class CitadelGetAssets
    {

        // set up dependency injection
        // make sure the object is registered in the startup
        private readonly ILogger<CitadelGetAssets> _logger;
        private readonly IAssetService _asset;

        public CitadelGetAssets(ILogger<CitadelGetAssets> log, IAssetService asset)
        {
            _logger = log;
            _asset = asset;
        }

        [FunctionName(Constant.GET_ASSET)]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = Constant.ASSETS_ROUTE)] HttpRequest req,
            ILogger _logger, string id)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            string response;
            try
            {

                string token = req.Headers["Authorization"];
                if (token == null)
                {
                    throw new UnauthorizedAccessException("Unauthorized access");
                }
                else
                {
                    await Task.Run(() => Common.ValidateBearertokenAsync(token));
                }

                string companyShortName = id;
                string headerCompanyShort = req.Headers["X-Company-Short"];
                Common.ValidateCompanyShorts(headerCompanyShort, companyShortName);

                string pageLimit = req.Query["page[limit]"];
                string pageOffset = req.Query["page[offset]"];
                string url = req.Path;

                pageLimit = pageLimit == null ? Constant.DEFAULT_ASSET_PAGE_LIMIT : pageLimit;
                pageOffset = pageOffset == null ? Constant.DEFAULT_ASSET_PAGE_OFFSET : pageOffset;
                int calculatedOffset = (Int32.Parse(pageOffset) - 1) * (Int32.Parse(pageLimit));

                List<AssetData> data = await Task.Run(() => _asset.GetCustomerAssets(companyShortName, pageLimit, calculatedOffset, req.Query["sort"], req.Query["filter"]));
                int pageCount = data.Count > 0 ? data[0].PageCount : 0;
                int totalRecords = data.Count > 0 ? data[0].TotalRecords : 0;
                Dictionary<string, int> counts = new Dictionary<string, int>();
                DataMessage<AssetData, Dictionary<string, int>> dataMessage = new DataMessage<AssetData, Dictionary<string, int>>();
                dataMessage.data = data;

                //Links links = BuildAssetLinks(req, Int32.Parse(pageLimit), Int32.Parse(pageOffset), pageCount, totalRecords);
                Links links = BuildAssetLinks(req, Int32.Parse(pageLimit), Int32.Parse(pageOffset), pageCount, totalRecords);
                Citadel.Model.Root.Meta<Dictionary<string, int>> meta = new Citadel.Model.Root.Meta<Dictionary<string, int>>();
                counts["Page Count"] = pageCount;
                counts["Total Records"] = totalRecords;

                meta.result = new Dictionary<string, int>();
                meta.result = counts;
                dataMessage.meta = meta;
                dataMessage.links = links;

                response = JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true });
                return new OkObjectResult(response);
            }
            catch (BadRequestException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "400");
            }
            catch (UnauthorizedAccessException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "401");
            }
            catch (ForbiddenException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "403");
            }
            catch (RangePaginationException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "400");
            }
            catch (NoRecordsFoundException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "404");
            }
            catch (InvalidSqlParamsException e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "400");
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                return Common.ReturnErrorResponse(e.Message, "500");
            }

        }

        private Links BuildAssetLinks(HttpRequest req, int pageLimit, int pageOffset, int pageCount, int totalRecords)
        {
            string url = req.Path;
            string displayUrl = req.GetDisplayUrl();
            string[] urlArray = displayUrl.Split(Constant.VERSION_PATH);

            var (sort, filter) = (req.Query["sort"].ToString(), req.Query["filter"].ToString());
            var sortFilter = $"{(!string.IsNullOrWhiteSpace(sort) ? $"&sort={sort}" : "")}{(!string.IsNullOrWhiteSpace(filter) ? $"&filter={filter}" : "")}";

            Links links = new Links();
            links.self = $"/{Constant.VERSION_PATH}{urlArray[1]}";
            links.first = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]=1{sortFilter}" : null;
            links.prev = pageOffset > 1 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset - 1}{sortFilter}" : null;
            links.next = pageOffset < pageCount ? $"{url}?page[limit]={pageLimit}&page[offset]={pageOffset + 1}{sortFilter}" : null;
            links.last = totalRecords > 0 ? $"{url}?page[limit]={pageLimit}&page[offset]={pageCount}{sortFilter}" : null;

            return links;
        }

    }

}
