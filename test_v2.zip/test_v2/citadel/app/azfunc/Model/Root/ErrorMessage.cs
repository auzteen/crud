namespace Citadel.Model.Root
{
    public class ErrorMessage
    {
        public string statusCode { get; set; }
        public string message { get; set; }
    }
}