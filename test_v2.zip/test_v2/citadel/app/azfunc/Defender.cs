﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Net.Http;
using Citadel.Model.Defender;
using Citadel.Services;
using System.Text.Json;

namespace Citadel
{
    public class Defender
    {
        private readonly ILogger<Defender> _logger;
        private static HttpClient httpClient = new HttpClient();
        private readonly IDefenderService _dService;
        public Defender(ILogger<Defender> log, IDefenderService dService)
        {
            _logger = log;
            _dService = dService;
        }

        [FunctionName(Constant.DEFENDER)]
        public void Run([TimerTrigger("0 0 * * *")] TimerInfo myTimer)
        {
            _logger.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

            try
            {
                List<Dictionary<string, string>> customers = _dService.GetCustomers();
                customers.Add(new Dictionary<string, string>()
                {
                    { "name", "open" }
                });

                foreach (var customer in customers)
                {
                    // Data
                    List<Asset> defenderAssets = new List<Asset>();

                    // Assets
                    defenderAssets = _dService.GetAssets(Constant.GET_MACHINE_URL, customer);

                    // Map
                    var assets = _dService.MapToModel(defenderAssets, customer);

                    // Asset Data
                    var assetData = _dService.GetAssetData(assets);

                    // Post
                    HttpResponseMessage response = _dService.PostAssetData(assetData, customer);
                }
            }
            catch (DefenderAssetScanException e)
            {
                _logger.LogError(e.Message);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
            }
        }
    }
}