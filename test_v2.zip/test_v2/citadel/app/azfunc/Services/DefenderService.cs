using System;
using Microsoft.Identity.Client;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using Citadel.Model.Defender;
using Citadel.Model.Root;
using System.Net.Http;
using System.Text.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Text;
using System.Net;

namespace Citadel.Services
{
    public class DefenderService : IDefenderService
    {

        private readonly ILogger<IDefenderService> _logger;
        public DefenderService(ILogger<IDefenderService> log)
        {
            _logger = log;
        }

        // Customers
        public List<Dictionary<string, string>> GetCustomers()
        {
            // Stub: To Do: Fetch...
            return new List<Dictionary<string, string>>();
        }

        // Assets
        public List<Asset> GetAssets(string url, Dictionary<string, string> customer)
        {
            try
            {
                var token = GetToken(customer);
                return GetAssetData(url, token);
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw new DefenderAssetScanException($"Defender asset scan failed: {DateTime.Now}");
            }
        }

        private List<Asset> GetAssetData(string url, string token)
        {
            // Asset Data
            List<Asset> defenderAssets = new List<Asset>();

            // Client
            var client = new HttpClient();

            // Request
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("Authorization", $"bearer {token}");

            // Reponse
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = client.SendAsync(request).Result;

                // Content
                var content = response.Content.ReadAsStringAsync().Result;

                // Assets
                var jObject = JObject.Parse(content);
                var jToken = jObject.SelectToken("value");
                var jArray = JArray.Parse(jToken.ToString());
                var assets = JsonConvert.DeserializeObject<List<Asset>>(jArray.ToString());

                // Asset Data
                defenderAssets = assets;
            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }

            return defenderAssets;
        }

        public Citadel.Model.Asset.Assets MapToModel(List<Asset> defenderAssets, Dictionary<string, string> customer)
        {
            //_logger.LogInformation(System.Text.Json.JsonSerializer.Serialize(defenderAssets, new JsonSerializerOptions {WriteIndented = true}));

            // Model: Assets
            Citadel.Model.Asset.Assets assets = new Citadel.Model.Asset.Assets();
            // Model: Asset List
            List<Citadel.Model.Asset.Asset> assetList = new List<Citadel.Model.Asset.Asset>();

            try
            {
                foreach (var dAsset in defenderAssets)
                {
                    var mAsset = new Citadel.Model.Asset.Asset();
                    mAsset.SourceId = dAsset.Id;
                    mAsset.AssetName = dAsset.ComputerDnsName;
                    mAsset.CompanyShortName = customer["name"];
                    mAsset.IPAddress = dAsset.LastIpAddress;
                    mAsset.LastExternalIpAddress = dAsset.LastExternalIpAddress;
                    mAsset.OS = dAsset.OsPlatform;
                    mAsset.OsBuild = dAsset.OsBuild;
                    mAsset.OsVersion = dAsset.OsVersion;
                    mAsset.OsArchitecture = dAsset.OsArchitecture;
                    mAsset.HealthStatus = dAsset.HealthStatus;
                    mAsset.DeviceValue = dAsset.DeviceValue;
                    mAsset.RbacGroupId = dAsset.RbacGroupId;
                    mAsset.RbacGroupName = dAsset.RbacGroupName;
                    mAsset.RiskScore = dAsset.RiskScore;
                    mAsset.ExposureLevel = dAsset.ExposureLevel;
                    mAsset.IsAadJoined = Convert.ToBoolean(dAsset.IsAadJoined);
                    mAsset.AadDeviceId = dAsset.AadDeviceId;
                    mAsset.AgentVersion = dAsset.AgentVersion;
                    assetList.Add(mAsset);
                }
                assets.assetType = "*** Unknown: Defender Scan ***";
                assets.assetList = assetList;
                return assets;
            }
            catch (Exception e)
            {
                _logger.LogInformation(e.Message);
                throw;
            }
        }

        public Citadel.Model.Asset.AssetData GetAssetData(Citadel.Model.Asset.Assets assets)
        {
            // Model
            Citadel.Model.Asset.AssetData assetData = new Citadel.Model.Asset.AssetData();
            assetData.type = "assets";
            assetData.id = Guid.NewGuid().ToString();
            assetData.attributes = assets;

            //_logger.LogInformation(System.Text.Json.JsonSerializer.Serialize(assetData, new JsonSerializerOptions {WriteIndented = true}));
            return assetData;
        }

        public HttpResponseMessage PostAssetData(Citadel.Model.Asset.AssetData assetData, Dictionary<string, string> customer)
        {
            // Token
            var token = GetToken(customer);

            // Message
            Citadel.Model.Root.DataMessage<Citadel.Model.Asset.AssetData, string> dataMessage = new Citadel.Model.Root.DataMessage<Citadel.Model.Asset.AssetData, string>();
            dataMessage.data = new List<Citadel.Model.Asset.AssetData>();
            dataMessage.data.Add(assetData);
            _logger.LogInformation(System.Text.Json.JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true }));

            // Client
            var client = new HttpClient();

            // Request
            // NB: Customer id (CShort) is hard coded to 'open' in both URL and HEADER
            var putUrl = $"{Environment.GetEnvironmentVariable("CITADEL_BASE_URI")}{Constant.VERSION_PATH}/{Constant.TYPE_CUSTOMERS}/open/{Constant.TYPE_ASSETS}/";
            var request = new HttpRequestMessage(HttpMethod.Put, putUrl);
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("X-Company-Short", $"{customer["name"]}");
            request.Headers.Add("Authorization", $"bearer {token}");
            request.Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(dataMessage, new JsonSerializerOptions { WriteIndented = true }), Encoding.UTF8, "application/json");

            // Reponse
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = client.SendAsync(request).Result;

                // Content
                var content = response.Content.ReadAsStringAsync().Result;

                // Result
                var result = System.Text.Json.JsonSerializer.Deserialize<object>(content);
                _logger.LogInformation(result.ToString());

                // Message
                HttpResponseMessage message = new HttpResponseMessage();
                message.Content = new StringContent(result.ToString(), Encoding.UTF8, "application/json");
                message.StatusCode = HttpStatusCode.OK;

                return message;

            }
            catch (Exception e)
            {
                _logger.LogError(e.Message);
                throw;
            }
        }

        // Tokens
        // Need to get a token from each env
        // Pass Tenant Id for each tenant get token
        public string GetToken(Dictionary<string, string> customer)
        {

            // To Do
            // Get bearer token from MS Auth endpoint with customer tenant details

            string tenantId = Environment.GetEnvironmentVariable("TENANT_ID");
            string appId = Environment.GetEnvironmentVariable("CLIENT_ID");
            string appSecret = Environment.GetEnvironmentVariable("DEFENDER_SECRET");

            const string authority = Constant.DEFENDER_AUTHORITY;
            const string audience = Constant.DEFENDER_AUDIENCE;

            IConfidentialClientApplication myApp = ConfidentialClientApplicationBuilder.Create(appId).WithClientSecret(appSecret).WithAuthority($"{authority}/{tenantId}").Build();
            List<string> scopes = new List<string>() { $"{audience}/.default" };
            AuthenticationResult authResult = myApp.AcquireTokenForClient(scopes).ExecuteAsync().GetAwaiter().GetResult();
            return authResult.AccessToken;
        }
    }
}