using Citadel.Model.Asset;
using Citadel.Model.Qualys;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.Dynamic;

namespace Citadel.Services
{
    public interface IAssetService
    {
        List<AssetData> GetCustomerAssets(string companyShortName, string pageLimit, int pageOffset, string sort, string filter);
        public bool NeedToUpdate(string asset_id, Asset asset, out dynamic fields);
        public List<ExpandoObject> PutCustomerAssets(List<AssetData> dataMessage, string companyShortName);
        public bool UpdateAsset(Asset asset, string companyShortName, int assetId);
        List<AssetData> MapQualysToAssetData(QualysData data);
    }
}