using System;
using System.Collections.Generic;
using System.Net.Http;
using Citadel.Model.Defender;
using Citadel.Model.Root;

namespace Citadel.Services
{
    public interface IDefenderService
    {
        // Customer
        public List<Dictionary<string, string>> GetCustomers();

        // Token
        public string GetToken(Dictionary<string, string> customer);

        // Asset
        public List<Asset> GetAssets(string url, Dictionary<string, string> customer);
        public Citadel.Model.Asset.Assets MapToModel(List<Asset> defenderAssets, Dictionary<string, string> customer);
        public Citadel.Model.Asset.AssetData GetAssetData(Citadel.Model.Asset.Assets assets);
        public HttpResponseMessage PostAssetData(Citadel.Model.Asset.AssetData assetData, Dictionary<string, string> customer);

    }
}