using System;
using Citadel.Model.Asset;
using Citadel.Model.Qualys;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Citadel.Services.Data;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Dynamic;
using System.Reflection;

namespace Citadel.Services
{
    public class AssetService : IAssetService
    {
        private readonly ILogger<IAssetService> _log;
        private readonly IDatabaseService _dbservice;
        private readonly ICustomerService _customerService;

        public AssetService(ILogger<IAssetService> log, IDatabaseService dbservice, ICustomerService customerService)
        {
            _log = log;
            _dbservice = dbservice;
            _customerService = customerService;
        }

        public List<AssetData> GetCustomerAssets(string companyShortName, string pageLimit, int pageOffset, string sort, string filter)
        {
            List<AssetData> assetDataList = new List<AssetData>();
            string filterString = ConvertFilterParam(filter);
            this.GetPageMetaData(companyShortName, Int32.Parse(pageLimit), filterString, out int totalRecords, out int totalPageCount);

            try
            {
                SqlConnection conn = _dbservice.GetSqlConnection();
                conn.Open();

                SqlCommand comm = new SqlCommand("spGetOffsetPageAssets", conn);
                comm.CommandType = CommandType.StoredProcedure;
                SqlParameter paramPageLimit = new SqlParameter("@PageLimit", SqlDbType.Int);
                paramPageLimit.Value = Int32.Parse(pageLimit);
                comm.Parameters.Add(paramPageLimit);

                SqlParameter paramPageOffset = new SqlParameter("@PageOffset", SqlDbType.Int);
                paramPageOffset.Value = pageOffset;
                comm.Parameters.Add(paramPageOffset);

                SqlParameter paramCompanyShort = new SqlParameter("@CompanyShortName", SqlDbType.NVarChar, 15);
                paramCompanyShort.Value = companyShortName;
                comm.Parameters.Add(paramCompanyShort);

                SqlParameter paramSort = new SqlParameter("@Sort", SqlDbType.NVarChar, 200);
                paramSort.Value = ConvertSortParam(sort);
                comm.Parameters.Add(paramSort);

                SqlParameter paramFilter = new SqlParameter("@Filter", SqlDbType.NVarChar, 200);
                paramFilter.Value = filterString;
                comm.Parameters.Add(paramFilter);

                string strAssetType = "";
                Assets assets = new Assets();
                List<Asset> assetList = new List<Asset>();
                bool emptyAsset = true;
                AssetData assetData;
                using (SqlDataReader reader = comm.ExecuteReader())
                {
                    if (!reader.HasRows)
                        throw new NoRecordsFoundException();
                    else
                    {
                        assetData = CreateNewAssetDataObject();
                        assetData.PageCount = totalPageCount;
                        assetData.TotalRecords = totalRecords;
                    }
                    while (reader.Read())
                    {
                        var val = reader.GetValue(0);
                        if (strAssetType != reader.GetString(3))
                        {
                            if (!emptyAsset)
                            {
                                assetData.attributes = assets;
                                assetData.PageCount = totalPageCount;
                                assetData.TotalRecords = totalRecords;
                                assetDataList.Add(assetData);
                                assetData = CreateNewAssetDataObject();
                            }
                            assets = new Assets();
                            strAssetType = reader.GetString(3);
                            assets.assetType = strAssetType;
                            assetList = new List<Asset>();
                        }

                        AssetCriticality ac = new AssetCriticality();
                        ac.status = reader.IsDBNull(24) ? null : reader.GetString(24);
                        ac.score = reader.IsDBNull(25) ? null : reader.GetInt32(25);

                        Asset asset = new Asset()
                        {
                            AssetId = reader.GetInt32(0),
                            SourceId = reader.IsDBNull(1) ? null : reader.GetString(1),
                            AssetName = reader.GetString(2),
                            CompanyShortName = reader.IsDBNull(4) ? null : reader.GetString(4),
                            AssetTier = reader.IsDBNull(5) ? null : reader.GetString(5),
                            Domain = reader.IsDBNull(6) ? null : reader.GetString(6),
                            IPAddress = reader.IsDBNull(7) ? null : reader.GetString(7),
                            LastExternalIpAddress = reader.IsDBNull(8) ? null : reader.GetString(8),
                            IPLocation = reader.IsDBNull(9) ? null : reader.GetString(9),
                            Manufacturer = reader.IsDBNull(10) ? null : reader.GetString(10),
                            OS = reader.IsDBNull(11) ? null : reader.GetString(11),
                            OsBuild = reader.IsDBNull(12) ? null : reader.GetString(12),
                            OsVersion = reader.IsDBNull(13) ? null : reader.GetString(13),
                            OsArchitecture = reader.IsDBNull(14) ? null : reader.GetString(14),
                            HealthStatus = reader.IsDBNull(15) ? null : reader.GetString(15),
                            DeviceValue = reader.IsDBNull(16) ? null : reader.GetString(16),
                            RbacGroupId = reader.IsDBNull(17) ? null : reader.GetString(17),
                            RbacGroupName = reader.IsDBNull(18) ? null : reader.GetString(18),
                            RiskScore = reader.IsDBNull(19) ? null : reader.GetString(19),
                            ExposureLevel = reader.IsDBNull(20) ? null : reader.GetString(20),
                            IsAadJoined = reader.GetBoolean(21),
                            AadDeviceId = reader.IsDBNull(22) ? null : reader.GetString(22),
                            Comment = reader.IsDBNull(23) ? null : reader.GetString(23),
                            assetCriticality = ac,
                            AgentVersion = reader.IsDBNull(26) ? null : reader.GetString(26)
                        };

                        assetList.Add(asset);
                        assets.assetList = assetList;
                        emptyAsset = false;

                    }
                    assetData.attributes = assets;
                    assetDataList.Add(assetData);
                }
                //assetDataList.Add(assetData);
                conn.Close();

            }
            catch (NoRecordsFoundException e)
            {
                _log.LogError(e.Message);
                return assetDataList;
            }
            catch (Exception e)
            {
                _log.LogError(e.Message);
                throw;
            }
            return assetDataList;
        }

        private AssetData CreateNewAssetDataObject()
        {
            AssetData assetData = new AssetData();
            assetData.type = Constant.TYPE_ASSETS;
            assetData.id = Guid.NewGuid().ToString();
            return assetData;
        }

        private void GetPageMetaData(string companyShortName, int pageSize, string filter, out int totalRecords, out int totalPageCount)
        {
            string filterString = string.IsNullOrWhiteSpace(filter) ? String.Empty : $" AND {filter}";
            string sqlQuery = $"SELECT COUNT(*) FROM vwAssets WHERE CompanyShortName = '{companyShortName}'{filterString}";
            totalRecords = _dbservice.GetScalarValueFromQuery(sqlQuery);
            if (pageSize == 0)
                totalPageCount = 1;
            if ((totalRecords % pageSize) == 0)
                totalPageCount = (totalRecords / pageSize);
            else
                totalPageCount = ((totalRecords / pageSize) + 1);
        }

        private int GetNextPageCount(string companyShortName, string pageSize, string cursorVal)
        {
            return GetCursorPageCount(companyShortName, pageSize, cursorVal, "dbo.spGetNextPageAssetCount");
        }

        private int GetPrevPageCount(string companyShortName, string pageSize, string cursorVal)
        {
            return GetCursorPageCount(companyShortName, pageSize, cursorVal, "dbo.spGetPrevPageAssetCount");
        }

        private int GetCursorPageCount(string companyShortName, string pageSize, string cursorVal, string spName)
        {
            SqlConnection conn = _dbservice.GetSqlConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand(spName, conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("Limit", pageSize);
            cmd.Parameters.AddWithValue("CursorVal", cursorVal);
            cmd.Parameters.AddWithValue("CompanyShortName", companyShortName);
            var returnVal = cmd.Parameters.Add("@returnVal", SqlDbType.Int);
            returnVal.Direction = ParameterDirection.ReturnValue;
            cmd.ExecuteNonQuery();
            var result = returnVal.Value;
            conn.Close();
            return (int)result;
        }

        public List<ExpandoObject> PutCustomerAssets(List<AssetData> dataMessage, string companyShortName)
        {
            List<ExpandoObject> responseList = new List<ExpandoObject>();
            try
            {
                // Response
                dynamic response = null;

                // Add customer if not exists customer
                _customerService.AddCustomer(companyShortName);
                foreach (AssetData data in dataMessage)
                {
                    // Dynamic Object
                    response = new ExpandoObject();

                    // Counts
                    response.totalAssetCount = 0;
                    response.addedAssetCount = 0;
                    response.updatedAssetCount = 0;

                    // Asset Types
                    response.assetType = data.attributes.assetType;

                    // Assets (No Added..)
                    response.updatedAssets = new List<dynamic>();

                    // Assets
                    foreach (Asset asset in data.attributes.assetList)
                    {
                        try
                        {
                            if (String.IsNullOrEmpty(asset.AssetName))
                                throw new BadRequestException("Bad request format - missing asset name");

                            if (!AssetExists(asset, companyShortName, out int assetId))
                            {
                                AddAsset(asset, companyShortName, data.attributes.assetType);
                                if (!AssetExists(asset, companyShortName, out assetId))
                                    throw new FailedToUpdateAssetException("Failed to create asset");
                                else
                                {
                                    response.totalAssetCount++;
                                    response.addedAssetCount++;
                                }
                            }
                            else
                            {
                                string assetUpdateResponse = string.Empty;
                                if (NeedToUpdate(assetId.ToString(), asset, out dynamic fields))
                                {
                                    if (UpdateAsset(asset, companyShortName, assetId))
                                    {
                                        var updateList = new List<dynamic>();

                                        foreach (var field in fields)
                                        {
                                            updateList.Add($"{field.Key.ToString()}: {field.Value.ToString()}");
                                        }

                                        dynamic[] updateArray = updateList.ToArray();
                                        var updatedAssetDictionary = new Dictionary<int, dynamic>();
                                        updatedAssetDictionary.Add(assetId, updateArray);
                                        response.updatedAssets.Add(updatedAssetDictionary);
                                        response.totalAssetCount++;
                                        response.updatedAssetCount++;
                                    }
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            _log.LogError(e.Message);
                            throw;
                        }
                    }

                    // No Counts for this asset
                    if (response.addedAssetCount != 0 || response.updatedAssetCount != 0)
                    {
                        IDictionary<string, object> map = response;
                        if (response.addedAssetCount == 0)
                            map.Remove("addedAssetCount");

                        if (response.updatedAssetCount == 0)
                            map.Remove("updatedAssetCount");

                        if (response.totalAssetCount == 0)
                            map.Remove("totalAssetCount");

                        responseList.Add(response);
                    }
                }
            }
            catch (Exception e)
            {
                _log.LogError(e.Message);
                throw;
            }

            return responseList;

        }

        private bool AssetExists(Asset asset, string companyShortName, out int assetId)
        {
            SqlConnection conn = _dbservice.GetSqlConnection();
            string query = $"SELECT Top(1) AssetID from Asset WHERE AssetName = '{asset.AssetName}' and CompanyShortName = '{companyShortName}'";

            try
            {
                int ord = -1;
                int asset_id = -1;

                conn.Open();
                SqlCommand comm = new SqlCommand(query, conn);
                var reader = comm.ExecuteReader();

                if (reader.Read())
                {
                    ord = reader.GetOrdinal("AssetId");
                    asset_id = reader.GetInt32(ord);

                    if (asset_id > 0)
                    {
                        assetId = asset_id;
                        comm.Dispose();
                        return true;
                    }
                    else
                    {
                        assetId = asset_id;
                        comm.Dispose();
                        return false;
                    }
                }
                else
                {
                    assetId = asset_id;
                    comm.Dispose();
                    return false;
                }
            }
            catch (SqlException e)
            {
                _log.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _log.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Dispose();
            }

        }

        private bool AddAsset(Asset asset, string companyShortName, string assetType)
        {
            // Sql
            string baseSqlQuery = @"INSERT INTO Asset ( SourceId, AssetName, AssetType, CompanyShortName, AssetTier, Domain,
                                                        IPAddress, LastExternalIpAddress, IPLocation, Manufacturer, OS, OsBuild,
                                                        OsVersion, OsArchitecture, HealthStatus, DeviceValue, RbacGroupId,
                                                        RbacGroupName, RiskScore, ExposureLevel, IsAadJoined, AadDeviceId, Comment,
                                                        CriticalityStatus, CriticalityScore, AgentVersion) VALUES ";
            string sqlQuery = "";
            SqlConnection conn = _dbservice.GetSqlConnection();

            // Criticality
            string criticalityStatus = string.Empty;
            int? criticalityScore = null;

            try
            {
                conn.Open();

                if (asset.assetCriticality != null)
                {
                    criticalityStatus = asset.assetCriticality.status;
                    criticalityScore = asset.assetCriticality.score;
                }

                sqlQuery = baseSqlQuery + @$"('{asset.SourceId}', '{asset.AssetName}', '{assetType}', '{companyShortName}', '{asset.AssetTier}',
                                              '{asset.Domain}', '{asset.IPAddress}', '{asset.LastExternalIpAddress}', '{asset.IPLocation}',
                                              '{asset.Manufacturer}', '{asset.OS}', '{asset.OsBuild}', '{asset.OsVersion}', '{asset.OsArchitecture}',
                                              '{asset.HealthStatus}', '{asset.DeviceValue}', '{asset.RbacGroupId}', '{asset.RbacGroupName}',
                                              '{asset.RiskScore}', '{asset.ExposureLevel}', '{asset.IsAadJoined}', '{asset.AadDeviceId}',
                                              '{asset.Comment}', '{criticalityStatus}', '{criticalityScore}', '{asset.AgentVersion}')";
                SqlCommand comm = new SqlCommand(sqlQuery, conn);
                comm.ExecuteNonQuery();
                comm.Dispose();

                return true;

            }
            catch (SqlException e)
            {
                _log.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _log.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Dispose();
            }
        }

        public bool UpdateAsset(Asset asset, string companyShortName, int assetId)
        {
            // Sql
            SqlConnection conn = _dbservice.GetSqlConnection();
            conn.Open();
            string query = "UPDATE Asset Set ";

            // Asset Type
            //query += $" AssetType='{assetType}',";

            // Company Short Name
            query += $" CompanyShortName='{companyShortName}',";

            try
            {
                var assetSerialized = JsonConvert.SerializeObject(asset);
                JObject keyValuePairs = JObject.Parse(assetSerialized.ToString());
                foreach (var pair in keyValuePairs)
                {
                    // Asset Id
                    if (pair.Key != "AssetId")
                    {
                        if (pair.Key != "CompanyShortName")
                        {
                            if (pair.Key != "assetCriticality")
                            {
                                query += $" {pair.Key.ToString()}='{pair.Value.ToString()}',";
                            }
                            else if (pair.Key.ToString() == "assetCriticality" && pair.Value.ToString() != "")
                            {
                                JObject kvPairs = JObject.Parse(pair.Value.ToString());
                                foreach (var pr in kvPairs)
                                {
                                    if (pr.Key.ToString() == "status")
                                    {
                                        query += $" CriticalityStatus='{pr.Value.ToString()}',";
                                    }
                                    else
                                    {
                                        var val = int.TryParse(pr.Value.ToString(), out var intVal) ? (int?)intVal : null;
                                        if (val == null)
                                        {
                                            query += $" CriticalityScore='{null}',";
                                        }
                                        else if (val >= 0 || val <= 10)
                                        {
                                            query += $" CriticalityScore='{pr.Value.ToString()}',";
                                        }
                                        else
                                        {
                                            throw new BadRequestException("Criticality score must be a valid number 0 through 10 inclusive!");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                query = query.TrimEnd(',');
                query += $" WHERE AssetId = '{assetId}'";

                // Setup
                SqlCommand comm = new SqlCommand(query, conn);

                // Execute
                comm.ExecuteNonQuery();
                conn.Close();

                return true;

            }
            catch (SqlException e)
            {
                _log.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _log.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Dispose();
            }
        }

        public bool NeedToUpdate(string asset_id, Asset asset, out dynamic fields)
        {
            // Flag
            bool needToUpdate = false;

            // Fields
            ExpandoObject fieldList = new ExpandoObject();

            // Connection
            SqlConnection conn = _dbservice.GetSqlConnection();
            conn.Open();

            // Query
            string sqlQuery = $"SELECT TOP(1) * FROM Asset WHERE AssetId = {asset_id} ";

            // Command
            SqlCommand comm = new SqlCommand(sqlQuery, conn);

            try
            {
                // Execute
                SqlDataReader reader = comm.ExecuteReader();

                // Read
                while (reader.Read())
                {
                    var assetSerialized = String.Empty;
                    JObject assetKeyValuePairs = new JObject();

                    assetSerialized = JsonConvert.SerializeObject(asset);
                    assetKeyValuePairs = JObject.Parse(assetSerialized);

                    foreach (var pair in assetKeyValuePairs)
                    {
                        int ord;

                        // Ignore
                        if (pair.Key != "AssetId")
                        {
                            if (pair.Key != "CompanyShortName")
                            {
                                if (pair.Key != "assetCriticality")
                                {
                                    ord = reader.GetOrdinal(pair.Key);
                                    if (pair.Key != "IsAadJoined")
                                    {
                                        if (!reader.IsDBNull(ord) && reader.GetString(ord) != pair.Value.ToString())
                                        {
                                            fieldList.TryAdd(pair.Key.ToString(), pair.Value.ToString());
                                            needToUpdate = true;
                                        }
                                    }
                                    else
                                    {
                                        if (!reader.IsDBNull(ord) && reader.GetBoolean(ord) != Convert.ToBoolean(pair.Value))
                                        {
                                            fieldList.TryAdd(pair.Key.ToString(), Convert.ToBoolean(pair.Value));
                                            needToUpdate = true;
                                        }
                                    }
                                }
                                else
                                {
                                    if (pair.Value.ToString() != string.Empty)
                                    {
                                        JObject keyValuePairs = JObject.Parse(pair.Value.ToString());
                                        foreach (var pr in keyValuePairs)
                                        {
                                            if (pr.Key.ToString() == "status")
                                            {
                                                ord = reader.GetOrdinal("CriticalityStatus");
                                                if ((reader.IsDBNull(ord) && pr.Value != null) || (reader.GetString(ord) != pr.Value.ToString()))
                                                {
                                                    fieldList.TryAdd(pr.Key.ToString(), pr.Value.ToString());
                                                    needToUpdate = true;
                                                }
                                            }
                                            else
                                            {
                                                if (!int.TryParse(pr.Value.ToString(), out int val1))
                                                {
                                                    ord = reader.GetOrdinal("CriticalityScore");
                                                    if ((reader.IsDBNull(ord) && pr.Value != null) || (reader.GetInt32(ord) != val1))
                                                    {
                                                        fieldList.TryAdd(pr.Key.ToString(), pr.Value.ToString());
                                                        needToUpdate = true;
                                                    }
                                                }
                                                else if (int.TryParse(pr.Value.ToString(), out int val2) && (val2 >= 0 && val2 <= 10))
                                                {
                                                    ord = reader.GetOrdinal("CriticalityScore");
                                                    if ((reader.IsDBNull(ord) && pr.Value != null) || (reader.GetInt32(ord) != val1))
                                                    {
                                                        fieldList.TryAdd(pr.Key.ToString(), pr.Value.ToString());
                                                        needToUpdate = true;
                                                    }
                                                }
                                                else
                                                {
                                                    throw new BadRequestException($"Criticality score, {pr.Value}, invalid.  Criticality score must be a valid number 0 through 10 inclusive!");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException e)
            {
                _log.LogError(e.Message);
                throw;
            }
            catch (KeyNotFoundException e)
            {
                _log.LogError(e.Message);
                throw;
            }
            catch (Exception e)
            {
                _log.LogError(e.Message);
                throw;
            }
            finally
            {
                conn.Close();
            }
            fields = fieldList;
            return needToUpdate;
        }

        public List<AssetData> MapQualysToAssetData(QualysData data)
        {
            AssetData assetData = new AssetData();
            assetData.type = Constant.TYPE_ASSETS;
            assetData.id = null;
            Assets assets = new Assets();
            assets.assetType = "Qualys Assets";
            List<Asset> assetList = new List<Asset>();

            List<Host> hostList = data.response.hostList.host;
            foreach (Host host in hostList)
            {
                Asset newAsset = new Asset();
                AssetCriticality ac = new AssetCriticality();
                newAsset.IPAddress = host.ip;
                newAsset.Domain = host?.dnsData?.domain == null ? null : host.dnsData.domain;
                newAsset.AssetName = host?.dnsData?.hostname == null ? $"asset_name: {host.ip}" : host.dnsData.hostname;
                newAsset.Comment = $"Qualys ID: {host.id}";
                newAsset.OS = host?.os == null ? null : host.os;

                // null values
                newAsset.AssetTier = null;
                newAsset.IPLocation = null;
                newAsset.Manufacturer = null;
                ac.status = "";
                ac.score = 0;
                newAsset.assetCriticality = ac;

                assetList.Add(newAsset);
            }
            assets.assetList = assetList;
            assetData.attributes = assets;
            List<AssetData> returnData = new List<AssetData>();
            returnData.Add(assetData);
            return returnData;
        }

        private string ConvertSortParam(string sortParam)
        {
            if (string.IsNullOrWhiteSpace(sortParam))
            {
                return string.Empty;
            }

            try
            {
                var sqlSortParam = string.Empty;
                var sortParamArr = sortParam.Replace("_", "").Split(",");

                foreach (var param in sortParamArr)
                {
                    var isDescDirection = param.StartsWith("-");
                    var propertyName = this.GetPropertyName(isDescDirection ? param.Substring(1) : param);

                    sqlSortParam = $"{sqlSortParam}{propertyName}{(isDescDirection ? " desc" : "")},";
                }

                return sqlSortParam.Substring(0, sqlSortParam.Length - 1);
            }
            catch (Exception e)
            {
                throw new InvalidSqlParamsException("Invalid sort parameters", e);
            }
        }

        private string ConvertFilterParam(string filterParam)
        {
            if (string.IsNullOrWhiteSpace(filterParam))
            {
                return string.Empty;
            }

            var sqlFilterBuilder = new Dictionary<string, Func<string, string, string>>(StringComparer.OrdinalIgnoreCase)
            {
                {"equals", (property, constant) => $"{property}='{constant}'"},
                {"lessThan", (property, constant) => $"{property}<'{constant}'"},
                {"lessOrEqual", (property, constant) => $"{property}<='{constant}'"},
                {"greaterThan", (property, constant) => $"{property}>'{constant}'"},
                {"greaterOrEqual", (property, constant) => $"{property}>='{constant}'"},
                {"contains", (property, constant) => $"{property} LIKE '%{constant}%'"},
                {"startsWith", (property, constant) => $"{property} LIKE '{constant}%'"},
                {"endsWith", (property, constant) => $"{property} LIKE '%{constant}'"}
            };

            try
            {
                var (filterFunction, filterMember, filterConstant) = (
                    filterParam.Split("(")[0].Trim(),
                    filterParam.Split("(")[1].Split(",")[0].Trim(),
                    filterParam.Split("(")[1].Split(",")[1].Split("'")[1]);

                return sqlFilterBuilder[filterFunction].Invoke(this.GetPropertyName(filterMember.Replace("_", "")), filterConstant);
            }
            catch (Exception e)
            {
                throw new InvalidSqlParamsException("Invalid filter parameters", e);
            }

        }

        private string GetPropertyName(string member) =>
            member.ToLower() switch
            {
                "criticalitystatus" => "CriticalityStatus",
                "criticalityscore" => "CriticalityScore",
                "assettype" => "AssetType",
                _ => typeof(Asset).GetProperty(name: member, bindingAttr: BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance).Name
            };
    }
}